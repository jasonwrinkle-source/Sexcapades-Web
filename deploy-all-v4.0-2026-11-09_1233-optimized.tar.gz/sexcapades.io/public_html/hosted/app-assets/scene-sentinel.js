
/* ---- module: scene-sentinel ---- */
__sxInit(function () {
/* Scene Sentinel: a top-level view (a dialog, like Popularity List)
   holding the safe signal, check-in timer, emergency contacts, pre-scene
   checklist, and post-scene check-in; all of its data lives in localStorage
   in this browser only. This module was split out of the old combined
   view-nav + Scene Sentinel block with no behavior change: same state key,
   same check-in phases and grace period, same notification and vibrate
   call sites; its timers run through SexcapadesRuntime.TimerManager.
   Everything runs inside boot(), gated on DOMContentLoaded through the
   shared __sxInit queue, and every listener attachment is null-guarded.
   The navigation module opens this dialog; window.__sxSentinelRenderAll
   (published below) is how it asks this module to render after opening,
   and window.__sxSentinelNotifInit is published for it here. */
(function () {
  function boot() {
  var closeDialog = window.__sxDialog.close;
  function syncBtn() { if (typeof window.__sxSyncViewButton === "function") window.__sxSyncViewButton(); }

  var safetyDlg = SexcapadesRuntime.DOM.byId("safetyDialog");
  var LS_KEY = "sexcapades_sentinel_v1";
  var GRACE_MS = 120000;
  function nowMs() { return Date.now(); }
  function fmtTime(ts) {
    try { return new Date(ts).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }); }
    catch (e) { return new Date(ts).toLocaleString(); }
  }
  function fmtTimeSec(ts) {
    try { return new Date(ts).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit", second: "2-digit" }); }
    catch (e) { return fmtTime(ts); }
  }
  function fmtDur(ms) {
    if (ms < 0) ms = 0;
    var s = Math.ceil(ms / 1000), m = Math.floor(s / 60), r = s % 60;
    return m + ":" + (r < 10 ? "0" : "") + r;
  }
  function vibrate(pattern) { try { if (navigator.vibrate) navigator.vibrate(pattern); } catch (e) { __sxErrLog("vibrate", e); } }
  var NOTIF_ASKED_KEY = 'sexcapades_sentinel_notif_asked';
  function notifSupported() {
    try { return ('Notification' in window) && ('serviceWorker' in navigator); } catch (e) { return false; }
  }
  function sentinelNotify(kind) {
    try {
      if (!notifSupported()) return;
      if (Notification.permission !== 'granted') return;
      navigator.serviceWorker.ready.then(function (reg) {
        var isMissed = kind === 'missed';
        var title = isMissed ? 'Scene Sentinel — MISSED CHECK-IN' : 'Scene Sentinel — Check-in due';
        var opts = {
          body: isMissed ? 'Check-in missed! Tap to open Scene Sentinel.' : "Check-in due — tap to confirm you're OK.",
          tag: isMissed ? 'sentinel-missed' : 'sentinel-due',
          icon: '/icons/icon-192.png',
          vibrate: isMissed ? [300, 80, 300, 80, 300] : [180, 80, 180, 80, 180]
        };
        if (isMissed) opts.requireInteraction = true;
        reg.showNotification(title, opts).catch(function (e) { __sxErrLog("notification-show", e); });
      }).catch(function (e) { __sxErrLog("notification-show", e); });
    } catch (e) { __sxErrLog("notification", e); }
  }
  function initNotifPermission() {
    try {
      if (!notifSupported()) return;
      if (Notification.permission === 'granted' || Notification.permission === 'denied') return;
      var asked = false;
      try { asked = localStorage.getItem(NOTIF_ASKED_KEY) === '1'; } catch (e) { __sxErrLog("notif-storage", e); }
      if (asked) return;
      try { localStorage.setItem(NOTIF_ASKED_KEY, '1'); } catch (e) { __sxErrLog("notification-show", e); }
      Notification.requestPermission().catch(function (e) { __sxErrLog("notification-show", e); });
    } catch (e) { __sxErrLog("notification-show", e); }
  }
  window.__sxSentinelNotifInit = initNotifPermission;
  var notifBtn = SexcapadesRuntime.DOM.byId("safetyNotifEnable"), notifHint = SexcapadesRuntime.DOM.byId("safetyNotifHint");
  function renderNotifHint() {
    try {
      if (!notifHint) return;
      if (!notifSupported()) { notifHint.hidden = true; return; }
      if (Notification.permission === 'granted') { notifHint.textContent = 'Check-in alerts enabled — they reach you even with the phone locked.'; return; }
      if (Notification.permission === 'denied') { notifHint.textContent = 'Check-in alerts are blocked in browser settings.'; return; }
    } catch (e) { __sxErrLog("notification", e); }
  }
  if (notifBtn) notifBtn.addEventListener("click", function () {
    try {
      if (!notifSupported()) return;
      try { localStorage.setItem(NOTIF_ASKED_KEY, '1'); } catch (e) { __sxErrLog("notif-storage", e); }
      Notification.requestPermission().then(function () { renderNotifHint(); }).catch(function (e) { __sxErrLog("notification-permission", e); });
    } catch (e) { __sxErrLog("notification-permission", e); }
  });

  /* ---------------- Scene Sentinel state (localStorage) ---------------- */
  function defaultState() {
    return {
      signals: [],
      contacts: [],
      pre: { limits: { c: false, t: "" }, words: { c: false, t: "" }, care: { c: false, t: "" } },
      checkin: { intervalMin: 15, phase: "idle", nextDue: 0, dueAt: 0 },
      post: { dueAt: 0, log: [] },
      journal: [],
      guide: { text: "", steps: [], pulseMin: 5, queuedAt: 0 }
    };
  }
  var state = defaultState();
  function load() {
    try {
      var raw = window.localStorage.getItem(LS_KEY);
      if (!raw) return;
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return;
      var d = defaultState();
      if (Array.isArray(parsed.signals)) d.signals = parsed.signals;
      if (Array.isArray(parsed.contacts)) d.contacts = parsed.contacts;
      if (parsed.pre) { for (var k in d.pre) { if (parsed.pre[k]) { d.pre[k].c = !!parsed.pre[k].c; d.pre[k].t = String(parsed.pre[k].t || ""); } } }
      if (parsed.checkin) { d.checkin.intervalMin = +parsed.checkin.intervalMin || 15; d.checkin.phase = String(parsed.checkin.phase || "idle"); d.checkin.nextDue = +parsed.checkin.nextDue || 0; d.checkin.dueAt = +parsed.checkin.dueAt || 0; }
      if (parsed.post) { d.post.dueAt = +parsed.post.dueAt || 0; if (Array.isArray(parsed.post.log)) d.post.log = parsed.post.log; }
      if (Array.isArray(parsed.journal)) d.journal = parsed.journal.filter(function (e) { return e && typeof e === "object" && e.code; }).map(function (e) { return { id: String(e.id || ""), t: +e.t || 0, code: String(e.code), metric: e.metric ? String(e.metric) : "", value: (e.value === null || e.value === undefined) ? null : +e.value, source: String(e.source || "watch"), activity: String(e.activity || ""), sched: String(e.sched || ""), domEnjoy: (e.domEnjoy === null || e.domEnjoy === undefined) ? null : +e.domEnjoy, domAt: +e.domAt || 0, profileId: String(e.profileId || "") }; });
      if (parsed.guide && typeof parsed.guide === "object") { d.guide.text = String(parsed.guide.text || ""); d.guide.pulseMin = +parsed.guide.pulseMin || 5; d.guide.queuedAt = +parsed.guide.queuedAt || 0; if (Array.isArray(parsed.guide.steps)) d.guide.steps = parsed.guide.steps.filter(function (st) { return st && isFinite(+st.start); }).map(function (st) { return { start: +st.start, end: (st.end === null || st.end === undefined) ? null : +st.end, activity: String(st.activity || ""), note: String(st.note || "") }; }); }
      state = d;
    } catch (e) { __sxErrLog("sentinel-parse", e); }
  }
  function save() { try { window.localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) { __sxErrLog("sentinel-storage", e); } }

  /* ---------------- Safe signal ---------------- */
  var signalBtn = SexcapadesRuntime.DOM.byId("safetySignalButton"), signalMain = SexcapadesRuntime.DOM.byId("safetySignalMain"),
      signalSub = SexcapadesRuntime.DOM.byId("safetySignalSub"), signalLogEl = SexcapadesRuntime.DOM.byId("safetySignalLog"),
      signalEmpty = SexcapadesRuntime.DOM.byId("safetySignalEmpty");
  var SIGNAL_META = {
    checkin: { state: "green", main: "Check-in — all good", label: "Check-in (all good)", vibe: [45] },
    slow: { state: "yellow", main: "Slow down", label: "Slow down", vibe: [80, 40, 80] },
    stop: { state: "red", main: "STOP", label: "Stop", vibe: [220, 60, 220, 60, 220] }
  };
  function fireSignal(kind) {
    var meta = SIGNAL_META[kind]; if (!meta) return;
    var t = nowMs();
    state.signals.unshift({ t: t, kind: kind });
    if (state.signals.length > 100) state.signals.length = 100;
    save();
    if (signalBtn) signalBtn.setAttribute("data-state", meta.state);
    if (signalMain) signalMain.textContent = meta.main;
    if (signalSub) signalSub.textContent = "Logged " + fmtTimeSec(t);
    vibrate(meta.vibe);
    renderSignals();
  }
  function renderSignals() {
    if (!signalLogEl) return;
    signalLogEl.innerHTML = "";
    state.signals.forEach(function (entry) {
      var meta = SIGNAL_META[entry.kind] || SIGNAL_META.checkin;
      var li = document.createElement("li");
      var dot = document.createElement("span"); dot.className = "safety-dot"; dot.setAttribute("data-kind", entry.kind);
      var lab = document.createElement("span"); lab.textContent = meta.label;
      var tm = document.createElement("time"); tm.textContent = fmtTimeSec(entry.t);
      li.appendChild(dot); li.appendChild(lab); li.appendChild(tm);
      signalLogEl.appendChild(li);
    });
    if (signalEmpty) signalEmpty.hidden = state.signals.length > 0;
  }
  if (signalBtn) {
    var holdTimer = 0, holdFired = false, lastTap = 0, tapTimer = 0, lastPointerUp = 0;
    function tapLogic() {
      var n = nowMs();
      if (lastTap && n - lastTap < 350) { lastTap = 0; SexcapadesRuntime.TimerManager.clear(tapTimer); fireSignal("stop"); }
      else { lastTap = n; tapTimer = SexcapadesRuntime.TimerManager.setTimeout(function () { lastTap = 0; fireSignal("checkin"); }, 360); }
    }
    signalBtn.addEventListener("pointerdown", function () {
      holdFired = false;
      SexcapadesRuntime.TimerManager.clear(holdTimer);
      holdTimer = SexcapadesRuntime.TimerManager.setTimeout(function () { holdFired = true; fireSignal("slow"); }, 550);
    });
    signalBtn.addEventListener("pointerup", function () {
      SexcapadesRuntime.TimerManager.clear(holdTimer);
      lastPointerUp = nowMs();
      if (holdFired) { holdFired = false; return; }
      tapLogic();
    });
    signalBtn.addEventListener("pointercancel", function () { SexcapadesRuntime.TimerManager.clear(holdTimer); });
    signalBtn.addEventListener("contextmenu", function (ev) { ev.preventDefault(); });
    signalBtn.addEventListener("click", function () {
      if (nowMs() - lastPointerUp < 120) return; /* pointer path already handled it */
      tapLogic();
    });
  }
  var signalClear = SexcapadesRuntime.DOM.byId("safetySignalClear");
  if (signalClear) signalClear.addEventListener("click", function () {
    state.signals = []; save(); renderSignals();
    if (signalBtn) signalBtn.setAttribute("data-state", "idle");
    if (signalMain) signalMain.textContent = "Safe signal";
    if (signalSub) signalSub.textContent = "Tap · hold · double-tap";
  });

  /* ---------------- Emergency contacts ---------------- */
  var contactList = SexcapadesRuntime.DOM.byId("safetyContactList"), contactEmpty = SexcapadesRuntime.DOM.byId("safetyContactEmpty");
  /* tel:/sms: capability detection (Build 2026-10-19_0048): ChromeOS and most
     desktops have no phone dialer or SMS app, and firing a tel:/sms: link
     there crashed/closed the tab on a Chromebook Plus. Only devices whose
     user agent looks like a phone/tablet get tel:/sms: links; on every
     other device NO tel:/sms: link is ever created — the number is shown
     as visible text with a Copy number button instead. */
  var CAN_TEL = (function () {
    try {
      var ua = String(navigator.userAgent || "");
      if (/CrOS/i.test(ua)) return false;
      return /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini|Mobile/i.test(ua);
    } catch (e) { __sxErrLog("sentinel-tel-detect", e); return false; }
  })();
  function telHref(phone) { return "tel:" + String(phone || "").replace(/[^+\d]/g, ""); }
  function smsHref(phone) { return "sms:" + String(phone || "").replace(/[^+\d]/g, ""); }
  function copyPhoneNumber(phone, btn) {
    var num = String(phone || "");
    var done = function () {
      if (!btn) return;
      var old = btn.getAttribute("data-copy-label") || "Copy number";
      btn.textContent = "Copied!";
      SexcapadesRuntime.TimerManager.setTimeout(function () { btn.textContent = old; }, 1600);
    };
    var fallback = function () {
      try {
        var ta = document.createElement("textarea");
        ta.value = num; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select();
        try { document.execCommand("copy"); } catch (e) { __sxErrLog("sentinel-copy", e); }
        document.body.removeChild(ta);
      } catch (e) { __sxErrLog("sentinel-copy", e); }
      done();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(num).then(done, fallback);
    } else fallback();
  }
  function copyNumberButton(phone, className, label) {
    var b = document.createElement("button");
    b.type = "button"; b.className = className; b.textContent = label;
    b.setAttribute("data-copy-label", label);
    b.addEventListener("click", function () { copyPhoneNumber(phone, b); });
    return b;
  }
  var contactsHint = SexcapadesRuntime.DOM.byId("safetyContactsHint");
  if (contactsHint && !CAN_TEL) contactsHint.textContent = "This device can't place calls or send texts, so each number is shown with a Copy number button — copy it and dial or text from your phone. The first contact is the escalation target for a missed check-in.";
  function contactRow(contact, idx) {
    var li = document.createElement("li");
    var name = document.createElement("span"); name.className = "safety-contact-name"; name.textContent = contact.name;
    var phone = document.createElement("span"); phone.className = "safety-contact-phone"; phone.textContent = contact.phone;
    var actions = document.createElement("span"); actions.className = "safety-contact-actions";
    if (CAN_TEL) {
      var call = document.createElement("a"); call.className = "action-btn safety-mini-btn"; call.href = telHref(contact.phone); call.textContent = "Call";
      var text = document.createElement("a"); text.className = "action-btn safety-mini-btn"; text.href = smsHref(contact.phone); text.textContent = "Text";
      actions.appendChild(call); actions.appendChild(text);
    } else {
      actions.appendChild(copyNumberButton(contact.phone, "action-btn safety-mini-btn", "Copy number"));
    }
    var rm = document.createElement("button"); rm.type = "button"; rm.className = "action-btn safety-mini-btn"; rm.textContent = "Remove"; rm.setAttribute("data-remove-contact", String(idx));
    actions.appendChild(rm);
    li.appendChild(name); li.appendChild(phone); li.appendChild(actions);
    return li;
  }
  function renderContacts() {
    if (!contactList) return;
    contactList.innerHTML = "";
    state.contacts.forEach(function (c, i) { contactList.appendChild(contactRow(c, i)); });
    if (contactEmpty) contactEmpty.hidden = state.contacts.length > 0;
    renderAlertActions();
  }
  if (contactList) contactList.addEventListener("click", function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest("[data-remove-contact]") : null;
    if (!t) return;
    var idx = +t.getAttribute("data-remove-contact");
    if (idx >= 0 && idx < state.contacts.length) { state.contacts.splice(idx, 1); save(); renderContacts(); }
  });
  var contactAdd = SexcapadesRuntime.DOM.byId("safetyContactAdd");
  if (contactAdd) contactAdd.addEventListener("click", function () {
    var nameEl = SexcapadesRuntime.DOM.byId("safetyContactName"), phoneEl = SexcapadesRuntime.DOM.byId("safetyContactPhone");
    var name = nameEl ? nameEl.value.trim() : "", phone = phoneEl ? phoneEl.value.trim() : "";
    if (!name || !phone) return;
    state.contacts.push({ name: name, phone: phone });
    save(); renderContacts();
    if (nameEl) nameEl.value = "";
    if (phoneEl) phoneEl.value = "";
  });
  function renderAlertActions() {
    var box = SexcapadesRuntime.DOM.byId("safetyAlertActions"); if (!box) return;
    box.innerHTML = "";
    if (!state.contacts.length) {
      var none = document.createElement("span"); none.textContent = "Add an emergency contact below so a missed check-in has someone to alert.";
      box.appendChild(none); return;
    }
    state.contacts.forEach(function (c) {
      if (CAN_TEL) {
        var call = document.createElement("a"); call.className = "action-btn"; call.href = telHref(c.phone); call.textContent = "Call " + c.name;
        var text = document.createElement("a"); text.className = "action-btn"; text.href = smsHref(c.phone); text.textContent = "Text " + c.name;
        box.appendChild(call); box.appendChild(text);
      } else {
        var lab = document.createElement("span"); lab.textContent = c.name + ": " + c.phone;
        box.appendChild(lab);
        box.appendChild(copyNumberButton(c.phone, "action-btn", "Copy number"));
      }
    });
  }

  /* ---------------- Pre-scene checklist ---------------- */
  var PRE_KEYS = [
    { key: "limits", check: "safetyPreLimitsCheck", text: "safetyPreLimitsText" },
    { key: "words", check: "safetyPreWordsCheck", text: "safetyPreWordsText" },
    { key: "care", check: "safetyPreCareCheck", text: "safetyPreCareText" }
  ];
  function renderPreReady() {
    var el = SexcapadesRuntime.DOM.byId("safetyPreReady"); if (!el) return;
    var all = PRE_KEYS.every(function (p) { return state.pre[p.key].c; });
    el.setAttribute("data-ready", all ? "true" : "false");
    el.textContent = all
      ? "Ready — hard limits reviewed, safe words agreed, aftercare planned."
      : "Not ready yet — confirm all three before the scene starts.";
  }
  function hydratePre() {
    PRE_KEYS.forEach(function (p) {
      var c = SexcapadesRuntime.DOM.byId(p.check), t = SexcapadesRuntime.DOM.byId(p.text);
      if (c) c.checked = !!state.pre[p.key].c;
      if (t) t.value = state.pre[p.key].t || "";
    });
    renderPreReady();
  }
  PRE_KEYS.forEach(function (p) {
    var c = SexcapadesRuntime.DOM.byId(p.check), t = SexcapadesRuntime.DOM.byId(p.text);
    if (c) c.addEventListener("change", function () { state.pre[p.key].c = c.checked; save(); renderPreReady(); });
    if (t) t.addEventListener("input", function () { state.pre[p.key].t = t.value; save(); });
  });

  /* ---------------- Check-in timer ---------------- */
  var checkinToggle = SexcapadesRuntime.DOM.byId("safetyCheckinToggle"), checkinStatus = SexcapadesRuntime.DOM.byId("safetyCheckinStatus"),
      checkinDue = SexcapadesRuntime.DOM.byId("safetyCheckinDue"), checkinMissed = SexcapadesRuntime.DOM.byId("safetyCheckinMissed"),
      checkinInterval = SexcapadesRuntime.DOM.byId("safetyCheckinInterval");
  function renderCheckin() {
    var ci = state.checkin, n = nowMs();
    if (checkinInterval && document.activeElement !== checkinInterval) checkinInterval.value = String(ci.intervalMin);
    if (!checkinStatus) return;
    if (ci.phase === "running") {
      checkinStatus.textContent = "Check-ins running — next check-in in " + fmtDur(ci.nextDue - n) + ".";
      if (checkinToggle) checkinToggle.textContent = "Stop check-ins";
      if (checkinDue) checkinDue.hidden = true;
      if (checkinMissed) checkinMissed.hidden = true;
    } else if (ci.phase === "due") {
      checkinStatus.textContent = "Check-in due — if nobody confirms within " + fmtDur(ci.dueAt + GRACE_MS - n) + ", it escalates to a missed check-in.";
      if (checkinToggle) checkinToggle.textContent = "Stop check-ins";
      if (checkinDue) checkinDue.hidden = false;
      if (checkinMissed) checkinMissed.hidden = true;
    } else if (ci.phase === "missed") {
      checkinStatus.textContent = "A check-in was missed and not confirmed.";
      if (checkinToggle) checkinToggle.textContent = "Stop check-ins";
      if (checkinDue) checkinDue.hidden = true;
      if (checkinMissed) checkinMissed.hidden = false;
    } else {
      checkinStatus.textContent = "Check-ins are off.";
      if (checkinToggle) checkinToggle.textContent = "Start check-ins";
      if (checkinDue) checkinDue.hidden = true;
      if (checkinMissed) checkinMissed.hidden = true;
    }
  }
  function startCheckins() {
    state.checkin.phase = "running";
    state.checkin.nextDue = nowMs() + state.checkin.intervalMin * 60000;
    state.checkin.dueAt = 0;
    save(); renderCheckin();
  }
  function stopCheckins() {
    state.checkin.phase = "idle"; state.checkin.nextDue = 0; state.checkin.dueAt = 0;
    save(); renderCheckin();
  }
  if (checkinToggle) checkinToggle.addEventListener("click", function () {
    if (state.checkin.phase === "idle") startCheckins(); else stopCheckins();
  });
  if (checkinInterval) checkinInterval.addEventListener("change", function () {
    state.checkin.intervalMin = +checkinInterval.value || 15;
    if (state.checkin.phase === "running") state.checkin.nextDue = nowMs() + state.checkin.intervalMin * 60000;
    save(); renderCheckin();
  });
  var checkinOk = SexcapadesRuntime.DOM.byId("safetyCheckinOk"), checkinAck = SexcapadesRuntime.DOM.byId("safetyCheckinAck");
  if (checkinOk) checkinOk.addEventListener("click", startCheckins);
  if (checkinAck) checkinAck.addEventListener("click", startCheckins);

  /* ---------------- Post-scene check-in ---------------- */
  var postStatus = SexcapadesRuntime.DOM.byId("safetyPostStatus"), postMoods = SexcapadesRuntime.DOM.byId("safetyPostMoods"),
      postLogEl = SexcapadesRuntime.DOM.byId("safetyPostLog"), postEmpty = SexcapadesRuntime.DOM.byId("safetyPostEmpty"),
      postPrompt = SexcapadesRuntime.DOM.byId("safetyPostMoodPrompt");
  var postPromptOpen = false;
  function renderPost() {
    if (!postStatus) return;
    var due = state.post.dueAt, n = nowMs();
    if (due && due > n) {
      postStatus.textContent = "Follow-up scheduled for " + fmtTime(due) + ".";
      if (!postPromptOpen && postMoods) postMoods.hidden = true;
    } else if (due && due <= n) {
      postStatus.textContent = "Your post-scene follow-up is due now.";
      if (postMoods) { postMoods.hidden = false; if (postPrompt) postPrompt.textContent = "Your follow-up is due — how are you feeling?"; }
    } else {
      postStatus.textContent = "No follow-up scheduled.";
      if (!postPromptOpen && postMoods) postMoods.hidden = true;
    }
    renderPostLog();
  }
  function renderPostLog() {
    if (!postLogEl) return;
    postLogEl.innerHTML = "";
    state.post.log.forEach(function (entry) {
      var li = document.createElement("li");
      var dot = document.createElement("span"); dot.className = "safety-dot"; dot.setAttribute("data-kind", "mood");
      var lab = document.createElement("span"); lab.textContent = "Feeling: " + entry.mood;
      var tm = document.createElement("time"); tm.textContent = fmtTime(entry.t);
      li.appendChild(dot); li.appendChild(lab); li.appendChild(tm);
      postLogEl.appendChild(li);
    });
    if (postEmpty) postEmpty.hidden = state.post.log.length > 0;
  }
  var postSchedule = SexcapadesRuntime.DOM.byId("safetyPostSchedule");
  if (postSchedule) postSchedule.addEventListener("click", function () {
    var delayEl = SexcapadesRuntime.DOM.byId("safetyPostDelay");
    var mins = delayEl ? (+delayEl.value || 120) : 120;
    state.post.dueAt = nowMs() + mins * 60000;
    postPromptOpen = false;
    save(); renderPost();
  });
  var postNow = SexcapadesRuntime.DOM.byId("safetyPostNow");
  if (postNow) postNow.addEventListener("click", function () {
    postPromptOpen = true;
    if (postMoods) { postMoods.hidden = false; if (postPrompt) postPrompt.textContent = "How are you feeling?"; }
  });
  if (postMoods) postMoods.addEventListener("click", function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest("[data-mood]") : null;
    if (!t) return;
    state.post.log.unshift({ t: nowMs(), mood: t.getAttribute("data-mood") });
    if (state.post.log.length > 100) state.post.log.length = 100;
    state.post.dueAt = 0;
    postPromptOpen = false;
    if (postMoods) postMoods.hidden = true;
    save(); renderPost();
  });

  /* ---------------- GibberWear listener + scene journal (sentinel-1106-0321; metric decoding guide-1106-0847) ----------------
     The watch sends GGWave p=4 (ultrasound fast) chirps: TAP / DBL / HLD,
     plus metric readings E / H / N (Enjoyment / Heat / Endurance). A metric
     payload is the metric letter plus the DISPLAY value, -100 to +100 —
     the number in the chirp IS the number on the watch screen, shown
     as-is with NO conversion (owner ruling 2026-11-06; the old spec
     formula Display = Internal*2 - 100 is dead and must not come back).
     This block captures the microphone with getUserMedia and decodes the
     audio with the vendored ggwave-wasm library (data:application/javascript;base64,CnZhciBnZ3dhdmVfZmFjdG9yeSA9ICgoKSA9PiB7CiAgdmFyIF9zY3JpcHREaXIgPSB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnICYmIGRvY3VtZW50LmN1cnJlbnRTY3JpcHQgPyBkb2N1bWVudC5jdXJyZW50U2NyaXB0LnNyYyA6IHVuZGVmaW5lZDsKICBpZiAodHlwZW9mIF9fZmlsZW5hbWUgIT09ICd1bmRlZmluZWQnKSBfc2NyaXB0RGlyID0gX3NjcmlwdERpciB8fCBfX2ZpbGVuYW1lOwogIHJldHVybiAoCmZ1bmN0aW9uKGdnd2F2ZV9mYWN0b3J5KSB7CiAgZ2d3YXZlX2ZhY3RvcnkgPSBnZ3dhdmVfZmFjdG9yeSB8fCB7fTsKCnZhciBNb2R1bGU9dHlwZW9mIGdnd2F2ZV9mYWN0b3J5IT09InVuZGVmaW5lZCI/Z2d3YXZlX2ZhY3Rvcnk6e307dmFyIG9iakFzc2lnbj1PYmplY3QuYXNzaWduO3ZhciByZWFkeVByb21pc2VSZXNvbHZlLHJlYWR5UHJvbWlzZVJlamVjdDtNb2R1bGVbInJlYWR5Il09bmV3IFByb21pc2UoZnVuY3Rpb24ocmVzb2x2ZSxyZWplY3Qpe3JlYWR5UHJvbWlzZVJlc29sdmU9cmVzb2x2ZTtyZWFkeVByb21pc2VSZWplY3Q9cmVqZWN0fSk7dmFyIG1vZHVsZU92ZXJyaWRlcz1vYmpBc3NpZ24oe30sTW9kdWxlKTt2YXIgYXJndW1lbnRzXz1bXTt2YXIgdGhpc1Byb2dyYW09Ii4vdGhpcy5wcm9ncmFtIjt2YXIgcXVpdF89KHN0YXR1cyx0b1Rocm93KT0+e3Rocm93IHRvVGhyb3d9O3ZhciBFTlZJUk9OTUVOVF9JU19XRUI9dHlwZW9mIHdpbmRvdz09PSJvYmplY3QiO3ZhciBFTlZJUk9OTUVOVF9JU19XT1JLRVI9dHlwZW9mIGltcG9ydFNjcmlwdHM9PT0iZnVuY3Rpb24iO3ZhciBFTlZJUk9OTUVOVF9JU19OT0RFPXR5cGVvZiBwcm9jZXNzPT09Im9iamVjdCImJnR5cGVvZiBwcm9jZXNzLnZlcnNpb25zPT09Im9iamVjdCImJnR5cGVvZiBwcm9jZXNzLnZlcnNpb25zLm5vZGU9PT0ic3RyaW5nIjt2YXIgc2NyaXB0RGlyZWN0b3J5PSIiO2Z1bmN0aW9uIGxvY2F0ZUZpbGUocGF0aCl7aWYoTW9kdWxlWyJsb2NhdGVGaWxlIl0pe3JldHVybiBNb2R1bGVbImxvY2F0ZUZpbGUiXShwYXRoLHNjcmlwdERpcmVjdG9yeSl9cmV0dXJuIHNjcmlwdERpcmVjdG9yeStwYXRofXZhciByZWFkXyxyZWFkQXN5bmMscmVhZEJpbmFyeSxzZXRXaW5kb3dUaXRsZTtmdW5jdGlvbiBsb2dFeGNlcHRpb25PbkV4aXQoZSl7aWYoZSBpbnN0YW5jZW9mIEV4aXRTdGF0dXMpcmV0dXJuO2xldCB0b0xvZz1lO2VycigiZXhpdGluZyBkdWUgdG8gZXhjZXB0aW9uOiAiK3RvTG9nKX12YXIgZnM7dmFyIG5vZGVQYXRoO3ZhciByZXF1aXJlTm9kZUZTO2lmKEVOVklST05NRU5UX0lTX05PREUpe2lmKEVOVklST05NRU5UX0lTX1dPUktFUil7c2NyaXB0RGlyZWN0b3J5PXJlcXVpcmUoInBhdGgiKS5kaXJuYW1lKHNjcmlwdERpcmVjdG9yeSkrIi8ifWVsc2V7c2NyaXB0RGlyZWN0b3J5PV9fZGlybmFtZSsiLyJ9cmVxdWlyZU5vZGVGUz0oKCk9PntpZighbm9kZVBhdGgpe2ZzPXJlcXVpcmUoImZzIik7bm9kZVBhdGg9cmVxdWlyZSgicGF0aCIpfX0pO3JlYWRfPWZ1bmN0aW9uIHNoZWxsX3JlYWQoZmlsZW5hbWUsYmluYXJ5KXt2YXIgcmV0PXRyeVBhcnNlQXNEYXRhVVJJKGZpbGVuYW1lKTtpZihyZXQpe3JldHVybiBiaW5hcnk/cmV0OnJldC50b1N0cmluZygpfXJlcXVpcmVOb2RlRlMoKTtmaWxlbmFtZT1ub2RlUGF0aFsibm9ybWFsaXplIl0oZmlsZW5hbWUpO3JldHVybiBmcy5yZWFkRmlsZVN5bmMoZmlsZW5hbWUsYmluYXJ5P251bGw6InV0ZjgiKX07cmVhZEJpbmFyeT0oZmlsZW5hbWU9Pnt2YXIgcmV0PXJlYWRfKGZpbGVuYW1lLHRydWUpO2lmKCFyZXQuYnVmZmVyKXtyZXQ9bmV3IFVpbnQ4QXJyYXkocmV0KX1yZXR1cm4gcmV0fSk7cmVhZEFzeW5jPSgoZmlsZW5hbWUsb25sb2FkLG9uZXJyb3IpPT57dmFyIHJldD10cnlQYXJzZUFzRGF0YVVSSShmaWxlbmFtZSk7aWYocmV0KXtvbmxvYWQocmV0KX1yZXF1aXJlTm9kZUZTKCk7ZmlsZW5hbWU9bm9kZVBhdGhbIm5vcm1hbGl6ZSJdKGZpbGVuYW1lKTtmcy5yZWFkRmlsZShmaWxlbmFtZSxmdW5jdGlvbihlcnIsZGF0YSl7aWYoZXJyKW9uZXJyb3IoZXJyKTtlbHNlIG9ubG9hZChkYXRhLmJ1ZmZlcil9KX0pO2lmKHByb2Nlc3NbImFyZ3YiXS5sZW5ndGg+MSl7dGhpc1Byb2dyYW09cHJvY2Vzc1siYXJndiJdWzFdLnJlcGxhY2UoL1xcL2csIi8iKX1hcmd1bWVudHNfPXByb2Nlc3NbImFyZ3YiXS5zbGljZSgyKTtwcm9jZXNzWyJvbiJdKCJ1bmNhdWdodEV4Y2VwdGlvbiIsZnVuY3Rpb24oZXgpe2lmKCEoZXggaW5zdGFuY2VvZiBFeGl0U3RhdHVzKSl7dGhyb3cgZXh9fSk7cHJvY2Vzc1sib24iXSgidW5oYW5kbGVkUmVqZWN0aW9uIixmdW5jdGlvbihyZWFzb24pe3Rocm93IHJlYXNvbn0pO3F1aXRfPSgoc3RhdHVzLHRvVGhyb3cpPT57aWYoa2VlcFJ1bnRpbWVBbGl2ZSgpKXtwcm9jZXNzWyJleGl0Q29kZSJdPXN0YXR1czt0aHJvdyB0b1Rocm93fWxvZ0V4Y2VwdGlvbk9uRXhpdCh0b1Rocm93KTtwcm9jZXNzWyJleGl0Il0oc3RhdHVzKX0pO01vZHVsZVsiaW5zcGVjdCJdPWZ1bmN0aW9uKCl7cmV0dXJuIltFbXNjcmlwdGVuIE1vZHVsZSBvYmplY3RdIn19ZWxzZSBpZihFTlZJUk9OTUVOVF9JU19XRUJ8fEVOVklST05NRU5UX0lTX1dPUktFUil7aWYoRU5WSVJPTk1FTlRfSVNfV09SS0VSKXtzY3JpcHREaXJlY3Rvcnk9c2VsZi5sb2NhdGlvbi5ocmVmfWVsc2UgaWYodHlwZW9mIGRvY3VtZW50IT09InVuZGVmaW5lZCImJmRvY3VtZW50LmN1cnJlbnRTY3JpcHQpe3NjcmlwdERpcmVjdG9yeT1kb2N1bWVudC5jdXJyZW50U2NyaXB0LnNyY31pZihfc2NyaXB0RGlyKXtzY3JpcHREaXJlY3Rvcnk9X3NjcmlwdERpcn1pZihzY3JpcHREaXJlY3RvcnkuaW5kZXhPZigiYmxvYjoiKSE9PTApe3NjcmlwdERpcmVjdG9yeT1zY3JpcHREaXJlY3Rvcnkuc3Vic3RyKDAsc2NyaXB0RGlyZWN0b3J5LnJlcGxhY2UoL1s/I10uKi8sIiIpLmxhc3RJbmRleE9mKCIvIikrMSl9ZWxzZXtzY3JpcHREaXJlY3Rvcnk9IiJ9e3JlYWRfPSh1cmw9Pnt0cnl7dmFyIHhocj1uZXcgWE1MSHR0cFJlcXVlc3Q7eGhyLm9wZW4oIkdFVCIsdXJsLGZhbHNlKTt4aHIuc2VuZChudWxsKTtyZXR1cm4geGhyLnJlc3BvbnNlVGV4dH1jYXRjaChlcnIpe3ZhciBkYXRhPXRyeVBhcnNlQXNEYXRhVVJJKHVybCk7aWYoZGF0YSl7cmV0dXJuIGludEFycmF5VG9TdHJpbmcoZGF0YSl9dGhyb3cgZXJyfX0pO2lmKEVOVklST05NRU5UX0lTX1dPUktFUil7cmVhZEJpbmFyeT0odXJsPT57dHJ5e3ZhciB4aHI9bmV3IFhNTEh0dHBSZXF1ZXN0O3hoci5vcGVuKCJHRVQiLHVybCxmYWxzZSk7eGhyLnJlc3BvbnNlVHlwZT0iYXJyYXlidWZmZXIiO3hoci5zZW5kKG51bGwpO3JldHVybiBuZXcgVWludDhBcnJheSh4aHIucmVzcG9uc2UpfWNhdGNoKGVycil7dmFyIGRhdGE9dHJ5UGFyc2VBc0RhdGFVUkkodXJsKTtpZihkYXRhKXtyZXR1cm4gZGF0YX10aHJvdyBlcnJ9fSl9cmVhZEFzeW5jPSgodXJsLG9ubG9hZCxvbmVycm9yKT0+e3ZhciB4aHI9bmV3IFhNTEh0dHBSZXF1ZXN0O3hoci5vcGVuKCJHRVQiLHVybCx0cnVlKTt4aHIucmVzcG9uc2VUeXBlPSJhcnJheWJ1ZmZlciI7eGhyLm9ubG9hZD0oKCk9PntpZih4aHIuc3RhdHVzPT0yMDB8fHhoci5zdGF0dXM9PTAmJnhoci5yZXNwb25zZSl7b25sb2FkKHhoci5yZXNwb25zZSk7cmV0dXJufXZhciBkYXRhPXRyeVBhcnNlQXNEYXRhVVJJKHVybCk7aWYoZGF0YSl7b25sb2FkKGRhdGEuYnVmZmVyKTtyZXR1cm59b25lcnJvcigpfSk7eGhyLm9uZXJyb3I9b25lcnJvcjt4aHIuc2VuZChudWxsKX0pfXNldFdpbmRvd1RpdGxlPSh0aXRsZT0+ZG9jdW1lbnQudGl0bGU9dGl0bGUpfWVsc2V7fXZhciBvdXQ9TW9kdWxlWyJwcmludCJdfHxjb25zb2xlLmxvZy5iaW5kKGNvbnNvbGUpO3ZhciBlcnI9TW9kdWxlWyJwcmludEVyciJdfHxjb25zb2xlLndhcm4uYmluZChjb25zb2xlKTtvYmpBc3NpZ24oTW9kdWxlLG1vZHVsZU92ZXJyaWRlcyk7bW9kdWxlT3ZlcnJpZGVzPW51bGw7aWYoTW9kdWxlWyJhcmd1bWVudHMiXSlhcmd1bWVudHNfPU1vZHVsZVsiYXJndW1lbnRzIl07aWYoTW9kdWxlWyJ0aGlzUHJvZ3JhbSJdKXRoaXNQcm9ncmFtPU1vZHVsZVsidGhpc1Byb2dyYW0iXTtpZihNb2R1bGVbInF1aXQiXSlxdWl0Xz1Nb2R1bGVbInF1aXQiXTt2YXIgdGVtcFJldDA9MDt2YXIgc2V0VGVtcFJldDA9dmFsdWU9Pnt0ZW1wUmV0MD12YWx1ZX07dmFyIHdhc21CaW5hcnk7aWYoTW9kdWxlWyJ3YXNtQmluYXJ5Il0pd2FzbUJpbmFyeT1Nb2R1bGVbIndhc21CaW5hcnkiXTt2YXIgbm9FeGl0UnVudGltZT1Nb2R1bGVbIm5vRXhpdFJ1bnRpbWUiXXx8dHJ1ZTtpZih0eXBlb2YgV2ViQXNzZW1ibHkhPT0ib2JqZWN0Iil7YWJvcnQoIm5vIG5hdGl2ZSB3YXNtIHN1cHBvcnQgZGV0ZWN0ZWQiKX12YXIgd2FzbU1lbW9yeTt2YXIgQUJPUlQ9ZmFsc2U7dmFyIEVYSVRTVEFUVVM7ZnVuY3Rpb24gYXNzZXJ0KGNvbmRpdGlvbix0ZXh0KXtpZighY29uZGl0aW9uKXthYm9ydCh0ZXh0KX19dmFyIFVURjhEZWNvZGVyPXR5cGVvZiBUZXh0RGVjb2RlciE9PSJ1bmRlZmluZWQiP25ldyBUZXh0RGVjb2RlcigidXRmOCIpOnVuZGVmaW5lZDtmdW5jdGlvbiBVVEY4QXJyYXlUb1N0cmluZyhoZWFwLGlkeCxtYXhCeXRlc1RvUmVhZCl7dmFyIGVuZElkeD1pZHgrbWF4Qnl0ZXNUb1JlYWQ7dmFyIGVuZFB0cj1pZHg7d2hpbGUoaGVhcFtlbmRQdHJdJiYhKGVuZFB0cj49ZW5kSWR4KSkrK2VuZFB0cjtpZihlbmRQdHItaWR4PjE2JiZoZWFwLnN1YmFycmF5JiZVVEY4RGVjb2Rlcil7cmV0dXJuIFVURjhEZWNvZGVyLmRlY29kZShoZWFwLnN1YmFycmF5KGlkeCxlbmRQdHIpKX1lbHNle3ZhciBzdHI9IiI7d2hpbGUoaWR4PGVuZFB0cil7dmFyIHUwPWhlYXBbaWR4KytdO2lmKCEodTAmMTI4KSl7c3RyKz1TdHJpbmcuZnJvbUNoYXJDb2RlKHUwKTtjb250aW51ZX12YXIgdTE9aGVhcFtpZHgrK10mNjM7aWYoKHUwJjIyNCk9PTE5Mil7c3RyKz1TdHJpbmcuZnJvbUNoYXJDb2RlKCh1MCYzMSk8PDZ8dTEpO2NvbnRpbnVlfXZhciB1Mj1oZWFwW2lkeCsrXSY2MztpZigodTAmMjQwKT09MjI0KXt1MD0odTAmMTUpPDwxMnx1MTw8Nnx1Mn1lbHNle3UwPSh1MCY3KTw8MTh8dTE8PDEyfHUyPDw2fGhlYXBbaWR4KytdJjYzfWlmKHUwPDY1NTM2KXtzdHIrPVN0cmluZy5mcm9tQ2hhckNvZGUodTApfWVsc2V7dmFyIGNoPXUwLTY1NTM2O3N0cis9U3RyaW5nLmZyb21DaGFyQ29kZSg1NTI5NnxjaD4+MTAsNTYzMjB8Y2gmMTAyMyl9fX1yZXR1cm4gc3RyfWZ1bmN0aW9uIFVURjhUb1N0cmluZyhwdHIsbWF4Qnl0ZXNUb1JlYWQpe3JldHVybiBwdHI/VVRGOEFycmF5VG9TdHJpbmcoSEVBUFU4LHB0cixtYXhCeXRlc1RvUmVhZCk6IiJ9ZnVuY3Rpb24gc3RyaW5nVG9VVEY4QXJyYXkoc3RyLGhlYXAsb3V0SWR4LG1heEJ5dGVzVG9Xcml0ZSl7aWYoIShtYXhCeXRlc1RvV3JpdGU+MCkpcmV0dXJuIDA7dmFyIHN0YXJ0SWR4PW91dElkeDt2YXIgZW5kSWR4PW91dElkeCttYXhCeXRlc1RvV3JpdGUtMTtmb3IodmFyIGk9MDtpPHN0ci5sZW5ndGg7KytpKXt2YXIgdT1zdHIuY2hhckNvZGVBdChpKTtpZih1Pj01NTI5NiYmdTw9NTczNDMpe3ZhciB1MT1zdHIuY2hhckNvZGVBdCgrK2kpO3U9NjU1MzYrKCh1JjEwMjMpPDwxMCl8dTEmMTAyM31pZih1PD0xMjcpe2lmKG91dElkeD49ZW5kSWR4KWJyZWFrO2hlYXBbb3V0SWR4KytdPXV9ZWxzZSBpZih1PD0yMDQ3KXtpZihvdXRJZHgrMT49ZW5kSWR4KWJyZWFrO2hlYXBbb3V0SWR4KytdPTE5Mnx1Pj42O2hlYXBbb3V0SWR4KytdPTEyOHx1JjYzfWVsc2UgaWYodTw9NjU1MzUpe2lmKG91dElkeCsyPj1lbmRJZHgpYnJlYWs7aGVhcFtvdXRJZHgrK109MjI0fHU+PjEyO2hlYXBbb3V0SWR4KytdPTEyOHx1Pj42JjYzO2hlYXBbb3V0SWR4KytdPTEyOHx1JjYzfWVsc2V7aWYob3V0SWR4KzM+PWVuZElkeClicmVhaztoZWFwW291dElkeCsrXT0yNDB8dT4+MTg7aGVhcFtvdXRJZHgrK109MTI4fHU+PjEyJjYzO2hlYXBbb3V0SWR4KytdPTEyOHx1Pj42JjYzO2hlYXBbb3V0SWR4KytdPTEyOHx1JjYzfX1oZWFwW291dElkeF09MDtyZXR1cm4gb3V0SWR4LXN0YXJ0SWR4fWZ1bmN0aW9uIHN0cmluZ1RvVVRGOChzdHIsb3V0UHRyLG1heEJ5dGVzVG9Xcml0ZSl7cmV0dXJuIHN0cmluZ1RvVVRGOEFycmF5KHN0cixIRUFQVTgsb3V0UHRyLG1heEJ5dGVzVG9Xcml0ZSl9ZnVuY3Rpb24gbGVuZ3RoQnl0ZXNVVEY4KHN0cil7dmFyIGxlbj0wO2Zvcih2YXIgaT0wO2k8c3RyLmxlbmd0aDsrK2kpe3ZhciB1PXN0ci5jaGFyQ29kZUF0KGkpO2lmKHU+PTU1Mjk2JiZ1PD01NzM0Myl1PTY1NTM2KygodSYxMDIzKTw8MTApfHN0ci5jaGFyQ29kZUF0KCsraSkmMTAyMztpZih1PD0xMjcpKytsZW47ZWxzZSBpZih1PD0yMDQ3KWxlbis9MjtlbHNlIGlmKHU8PTY1NTM1KWxlbis9MztlbHNlIGxlbis9NH1yZXR1cm4gbGVufXZhciBVVEYxNkRlY29kZXI9dHlwZW9mIFRleHREZWNvZGVyIT09InVuZGVmaW5lZCI/bmV3IFRleHREZWNvZGVyKCJ1dGYtMTZsZSIpOnVuZGVmaW5lZDtmdW5jdGlvbiBVVEYxNlRvU3RyaW5nKHB0cixtYXhCeXRlc1RvUmVhZCl7dmFyIGVuZFB0cj1wdHI7dmFyIGlkeD1lbmRQdHI+PjE7dmFyIG1heElkeD1pZHgrbWF4Qnl0ZXNUb1JlYWQvMjt3aGlsZSghKGlkeD49bWF4SWR4KSYmSEVBUFUxNltpZHhdKSsraWR4O2VuZFB0cj1pZHg8PDE7aWYoZW5kUHRyLXB0cj4zMiYmVVRGMTZEZWNvZGVyKXtyZXR1cm4gVVRGMTZEZWNvZGVyLmRlY29kZShIRUFQVTguc3ViYXJyYXkocHRyLGVuZFB0cikpfWVsc2V7dmFyIHN0cj0iIjtmb3IodmFyIGk9MDshKGk+PW1heEJ5dGVzVG9SZWFkLzIpOysraSl7dmFyIGNvZGVVbml0PUhFQVAxNltwdHIraSoyPj4xXTtpZihjb2RlVW5pdD09MClicmVhaztzdHIrPVN0cmluZy5mcm9tQ2hhckNvZGUoY29kZVVuaXQpfXJldHVybiBzdHJ9fWZ1bmN0aW9uIHN0cmluZ1RvVVRGMTYoc3RyLG91dFB0cixtYXhCeXRlc1RvV3JpdGUpe2lmKG1heEJ5dGVzVG9Xcml0ZT09PXVuZGVmaW5lZCl7bWF4Qnl0ZXNUb1dyaXRlPTIxNDc0ODM2NDd9aWYobWF4Qnl0ZXNUb1dyaXRlPDIpcmV0dXJuIDA7bWF4Qnl0ZXNUb1dyaXRlLT0yO3ZhciBzdGFydFB0cj1vdXRQdHI7dmFyIG51bUNoYXJzVG9Xcml0ZT1tYXhCeXRlc1RvV3JpdGU8c3RyLmxlbmd0aCoyP21heEJ5dGVzVG9Xcml0ZS8yOnN0ci5sZW5ndGg7Zm9yKHZhciBpPTA7aTxudW1DaGFyc1RvV3JpdGU7KytpKXt2YXIgY29kZVVuaXQ9c3RyLmNoYXJDb2RlQXQoaSk7SEVBUDE2W291dFB0cj4+MV09Y29kZVVuaXQ7b3V0UHRyKz0yfUhFQVAxNltvdXRQdHI+PjFdPTA7cmV0dXJuIG91dFB0ci1zdGFydFB0cn1mdW5jdGlvbiBsZW5ndGhCeXRlc1VURjE2KHN0cil7cmV0dXJuIHN0ci5sZW5ndGgqMn1mdW5jdGlvbiBVVEYzMlRvU3RyaW5nKHB0cixtYXhCeXRlc1RvUmVhZCl7dmFyIGk9MDt2YXIgc3RyPSIiO3doaWxlKCEoaT49bWF4Qnl0ZXNUb1JlYWQvNCkpe3ZhciB1dGYzMj1IRUFQMzJbcHRyK2kqND4+Ml07aWYodXRmMzI9PTApYnJlYWs7KytpO2lmKHV0ZjMyPj02NTUzNil7dmFyIGNoPXV0ZjMyLTY1NTM2O3N0cis9U3RyaW5nLmZyb21DaGFyQ29kZSg1NTI5NnxjaD4+MTAsNTYzMjB8Y2gmMTAyMyl9ZWxzZXtzdHIrPVN0cmluZy5mcm9tQ2hhckNvZGUodXRmMzIpfX1yZXR1cm4gc3RyfWZ1bmN0aW9uIHN0cmluZ1RvVVRGMzIoc3RyLG91dFB0cixtYXhCeXRlc1RvV3JpdGUpe2lmKG1heEJ5dGVzVG9Xcml0ZT09PXVuZGVmaW5lZCl7bWF4Qnl0ZXNUb1dyaXRlPTIxNDc0ODM2NDd9aWYobWF4Qnl0ZXNUb1dyaXRlPDQpcmV0dXJuIDA7dmFyIHN0YXJ0UHRyPW91dFB0cjt2YXIgZW5kUHRyPXN0YXJ0UHRyK21heEJ5dGVzVG9Xcml0ZS00O2Zvcih2YXIgaT0wO2k8c3RyLmxlbmd0aDsrK2kpe3ZhciBjb2RlVW5pdD1zdHIuY2hhckNvZGVBdChpKTtpZihjb2RlVW5pdD49NTUyOTYmJmNvZGVVbml0PD01NzM0Myl7dmFyIHRyYWlsU3Vycm9nYXRlPXN0ci5jaGFyQ29kZUF0KCsraSk7Y29kZVVuaXQ9NjU1MzYrKChjb2RlVW5pdCYxMDIzKTw8MTApfHRyYWlsU3Vycm9nYXRlJjEwMjN9SEVBUDMyW291dFB0cj4+Ml09Y29kZVVuaXQ7b3V0UHRyKz00O2lmKG91dFB0cis0PmVuZFB0cilicmVha31IRUFQMzJbb3V0UHRyPj4yXT0wO3JldHVybiBvdXRQdHItc3RhcnRQdHJ9ZnVuY3Rpb24gbGVuZ3RoQnl0ZXNVVEYzMihzdHIpe3ZhciBsZW49MDtmb3IodmFyIGk9MDtpPHN0ci5sZW5ndGg7KytpKXt2YXIgY29kZVVuaXQ9c3RyLmNoYXJDb2RlQXQoaSk7aWYoY29kZVVuaXQ+PTU1Mjk2JiZjb2RlVW5pdDw9NTczNDMpKytpO2xlbis9NH1yZXR1cm4gbGVufWZ1bmN0aW9uIGFsaWduVXAoeCxtdWx0aXBsZSl7aWYoeCVtdWx0aXBsZT4wKXt4Kz1tdWx0aXBsZS14JW11bHRpcGxlfXJldHVybiB4fXZhciBidWZmZXIsSEVBUDgsSEVBUFU4LEhFQVAxNixIRUFQVTE2LEhFQVAzMixIRUFQVTMyLEhFQVBGMzIsSEVBUEY2NDtmdW5jdGlvbiB1cGRhdGVHbG9iYWxCdWZmZXJBbmRWaWV3cyhidWYpe2J1ZmZlcj1idWY7TW9kdWxlWyJIRUFQOCJdPUhFQVA4PW5ldyBJbnQ4QXJyYXkoYnVmKTtNb2R1bGVbIkhFQVAxNiJdPUhFQVAxNj1uZXcgSW50MTZBcnJheShidWYpO01vZHVsZVsiSEVBUDMyIl09SEVBUDMyPW5ldyBJbnQzMkFycmF5KGJ1Zik7TW9kdWxlWyJIRUFQVTgiXT1IRUFQVTg9bmV3IFVpbnQ4QXJyYXkoYnVmKTtNb2R1bGVbIkhFQVBVMTYiXT1IRUFQVTE2PW5ldyBVaW50MTZBcnJheShidWYpO01vZHVsZVsiSEVBUFUzMiJdPUhFQVBVMzI9bmV3IFVpbnQzMkFycmF5KGJ1Zik7TW9kdWxlWyJIRUFQRjMyIl09SEVBUEYzMj1uZXcgRmxvYXQzMkFycmF5KGJ1Zik7TW9kdWxlWyJIRUFQRjY0Il09SEVBUEY2ND1uZXcgRmxvYXQ2NEFycmF5KGJ1Zil9dmFyIElOSVRJQUxfTUVNT1JZPU1vZHVsZVsiSU5JVElBTF9NRU1PUlkiXXx8MTY3NzcyMTY7dmFyIHdhc21UYWJsZTt2YXIgX19BVFBSRVJVTl9fPVtdO3ZhciBfX0FUSU5JVF9fPVtdO3ZhciBfX0FUUE9TVFJVTl9fPVtdO3ZhciBydW50aW1lSW5pdGlhbGl6ZWQ9ZmFsc2U7dmFyIHJ1bnRpbWVLZWVwYWxpdmVDb3VudGVyPTA7ZnVuY3Rpb24ga2VlcFJ1bnRpbWVBbGl2ZSgpe3JldHVybiBub0V4aXRSdW50aW1lfHxydW50aW1lS2VlcGFsaXZlQ291bnRlcj4wfWZ1bmN0aW9uIHByZVJ1bigpe2lmKE1vZHVsZVsicHJlUnVuIl0pe2lmKHR5cGVvZiBNb2R1bGVbInByZVJ1biJdPT0iZnVuY3Rpb24iKU1vZHVsZVsicHJlUnVuIl09W01vZHVsZVsicHJlUnVuIl1dO3doaWxlKE1vZHVsZVsicHJlUnVuIl0ubGVuZ3RoKXthZGRPblByZVJ1bihNb2R1bGVbInByZVJ1biJdLnNoaWZ0KCkpfX1jYWxsUnVudGltZUNhbGxiYWNrcyhfX0FUUFJFUlVOX18pfWZ1bmN0aW9uIGluaXRSdW50aW1lKCl7cnVudGltZUluaXRpYWxpemVkPXRydWU7Y2FsbFJ1bnRpbWVDYWxsYmFja3MoX19BVElOSVRfXyl9ZnVuY3Rpb24gcG9zdFJ1bigpe2lmKE1vZHVsZVsicG9zdFJ1biJdKXtpZih0eXBlb2YgTW9kdWxlWyJwb3N0UnVuIl09PSJmdW5jdGlvbiIpTW9kdWxlWyJwb3N0UnVuIl09W01vZHVsZVsicG9zdFJ1biJdXTt3aGlsZShNb2R1bGVbInBvc3RSdW4iXS5sZW5ndGgpe2FkZE9uUG9zdFJ1bihNb2R1bGVbInBvc3RSdW4iXS5zaGlmdCgpKX19Y2FsbFJ1bnRpbWVDYWxsYmFja3MoX19BVFBPU1RSVU5fXyl9ZnVuY3Rpb24gYWRkT25QcmVSdW4oY2Ipe19fQVRQUkVSVU5fXy51bnNoaWZ0KGNiKX1mdW5jdGlvbiBhZGRPbkluaXQoY2Ipe19fQVRJTklUX18udW5zaGlmdChjYil9ZnVuY3Rpb24gYWRkT25Qb3N0UnVuKGNiKXtfX0FUUE9TVFJVTl9fLnVuc2hpZnQoY2IpfXZhciBydW5EZXBlbmRlbmNpZXM9MDt2YXIgcnVuRGVwZW5kZW5jeVdhdGNoZXI9bnVsbDt2YXIgZGVwZW5kZW5jaWVzRnVsZmlsbGVkPW51bGw7ZnVuY3Rpb24gYWRkUnVuRGVwZW5kZW5jeShpZCl7cnVuRGVwZW5kZW5jaWVzKys7aWYoTW9kdWxlWyJtb25pdG9yUnVuRGVwZW5kZW5jaWVzIl0pe01vZHVsZVsibW9uaXRvclJ1bkRlcGVuZGVuY2llcyJdKHJ1bkRlcGVuZGVuY2llcyl9fWZ1bmN0aW9uIHJlbW92ZVJ1bkRlcGVuZGVuY3koaWQpe3J1bkRlcGVuZGVuY2llcy0tO2lmKE1vZHVsZVsibW9uaXRvclJ1bkRlcGVuZGVuY2llcyJdKXtNb2R1bGVbIm1vbml0b3JSdW5EZXBlbmRlbmNpZXMiXShydW5EZXBlbmRlbmNpZXMpfWlmKHJ1bkRlcGVuZGVuY2llcz09MCl7aWYocnVuRGVwZW5kZW5jeVdhdGNoZXIhPT1udWxsKXtjbGVhckludGVydmFsKHJ1bkRlcGVuZGVuY3lXYXRjaGVyKTtydW5EZXBlbmRlbmN5V2F0Y2hlcj1udWxsfWlmKGRlcGVuZGVuY2llc0Z1bGZpbGxlZCl7dmFyIGNhbGxiYWNrPWRlcGVuZGVuY2llc0Z1bGZpbGxlZDtkZXBlbmRlbmNpZXNGdWxmaWxsZWQ9bnVsbDtjYWxsYmFjaygpfX19TW9kdWxlWyJwcmVsb2FkZWRJbWFnZXMiXT17fTtNb2R1bGVbInByZWxvYWRlZEF1ZGlvcyJdPXt9O2Z1bmN0aW9uIGFib3J0KHdoYXQpe3tpZihNb2R1bGVbIm9uQWJvcnQiXSl7TW9kdWxlWyJvbkFib3J0Il0od2hhdCl9fXdoYXQ9IkFib3J0ZWQoIit3aGF0KyIpIjtlcnIod2hhdCk7QUJPUlQ9dHJ1ZTtFWElUU1RBVFVTPTE7d2hhdCs9Ii4gQnVpbGQgd2l0aCAtcyBBU1NFUlRJT05TPTEgZm9yIG1vcmUgaW5mby4iO3ZhciBlPW5ldyBXZWJBc3NlbWJseS5SdW50aW1lRXJyb3Iod2hhdCk7cmVhZHlQcm9taXNlUmVqZWN0KGUpO3Rocm93IGV9dmFyIGRhdGFVUklQcmVmaXg9ImRhdGE6YXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtO2Jhc2U2NCwiO2Z1bmN0aW9uIGlzRGF0YVVSSShmaWxlbmFtZSl7cmV0dXJuIGZpbGVuYW1lLnN0YXJ0c1dpdGgoZGF0YVVSSVByZWZpeCl9ZnVuY3Rpb24gaXNGaWxlVVJJKGZpbGVuYW1lKXtyZXR1cm4gZmlsZW5hbWUuc3RhcnRzV2l0aCgiZmlsZTovLyIpfXZhciB3YXNtQmluYXJ5RmlsZTt3YXNtQmluYXJ5RmlsZT0iZGF0YTphcHBsaWNhdGlvbi9vY3RldC1zdHJlYW07YmFzZTY0LEFHRnpiUUVBQUFBQjVRRWhZQU4vZjM4QVlBRi9BWDlnQVg4QVlBTi9mMzhCZjJBRmYzOS9mMzhBWUFSL2YzOS9BR0FHZjM5L2YzOS9BR0FBQUdBQ2YzOEFZQVYvZjM5L2Z3Ri9ZQUovZndGL1lBTi9mbjhCZm1BRWYzOS9md0YvWUFGOEFYMWdBQUYvWUFGOUFYMWdBWHdCZkdBQ2ZIOEJmR0FHZjN4L2YzOS9BWDlnQ245L2YzOS9mMzkvZjM4QVlBTi9mM3dBWUFkL2YzOS9mMzkvQUdBQ2ZuOEJmMkFEZkh4L0FYeGdBbng4QVh4Z0JYOTlmMzkvQVg5Z0JuOS9mMzkvZndGL1lBSjlmd0YvWUFKOGZ3Ri9ZQWQvZjM5L2YzOS9BWDlnQkg5L2ZuNEFZQU4vZjMwQVlBSi9md0Y5QXAwQkdnRmhBV0VBQUFGaEFXSUFBQUZoQVdNQUJnRmhBV1FBRXdGaEFXVUFCQUZoQVdZQUZBRmhBV2NBQ2dGaEFXZ0FCd0ZoQVdrQUFBRmhBV29BQWdGaEFXc0FBZ0ZoQVd3QURBRmhBVzBBQ0FGaEFXNEFBQUZoQVc4QUJRRmhBWEFBQWdGaEFYRUFCZ0ZoQVhJQUNRRmhBWE1BRlFGaEFYUUFBZ0ZoQVhVQUFRRmhBWFlBQVFGaEFYY0FBd0ZoQVhnQUNBRmhBWGtBQkFGaEFYb0FDQU5yYWdNREFBRUFCQU1DQWdFTkRRNEJBQUVXRHdJUUZ4Z1pCQThSQndZRkFCQURBQXdCQlFjRkF3b0FBQUVhQlJFQkFnQWJIQWtIQUFFREFBa2RDZ0FBSGdRRkJRVURDQUVIQ2hJQkN3RUxBd0VmSUFFQ0FRSUZBQUlDQ0FnQUJ3Y0NBQU1FQ1FZR0JnUUVDUTRFQlFGd0FUUTBCUWNCQVlBQ2dJQUNCZ2tCZndGQnNPM0FBZ3NISVFnQlFRSUFBVUlBUGdGREFRQUJSQUFoQVVVQUp3RkdBR3NCUndCT0FVZ0FmQWs5QVFCQkFRc3pnd0Z5VlU5cWFWVlBZMjVoYlY1c2dnRjdlbmw0ZDNaMWRITnhhR2RtWldSaVh5eEpTVUFzUUN4ZGZZQUJYQ3grZ1FGYkxIOVpXZ3J0dVFScWdRUUJBMzhnQWtHQUJFOEVRQ0FBSUFFZ0FoQVdHaUFBRHdzZ0FDQUNhaUVEQWtBZ0FDQUJjMEVEY1VVRVFBSkFJQUJCQTNGRkJFQWdBQ0VDREFFTElBSkZCRUFnQUNFQ0RBRUxJQUFoQWdOQUlBSWdBUzBBQURvQUFDQUJRUUZxSVFFZ0FrRUJhaUlDUVFOeFJRMEJJQUlnQTBrTkFBc0xBa0FnQTBGOGNTSUVRY0FBU1EwQUlBSWdCRUZBYWlJRlN3MEFBMEFnQWlBQktBSUFOZ0lBSUFJZ0FTZ0NCRFlDQkNBQ0lBRW9BZ2cyQWdnZ0FpQUJLQUlNTmdJTUlBSWdBU2dDRURZQ0VDQUNJQUVvQWhRMkFoUWdBaUFCS0FJWU5nSVlJQUlnQVNnQ0hEWUNIQ0FDSUFFb0FpQTJBaUFnQWlBQktBSWtOZ0lrSUFJZ0FTZ0NLRFlDS0NBQ0lBRW9BaXcyQWl3Z0FpQUJLQUl3TmdJd0lBSWdBU2dDTkRZQ05DQUNJQUVvQWpnMkFqZ2dBaUFCS0FJOE5nSThJQUZCUUdzaEFTQUNRVUJySWdJZ0JVME5BQXNMSUFJZ0JFOE5BUU5BSUFJZ0FTZ0NBRFlDQUNBQlFRUnFJUUVnQWtFRWFpSUNJQVJKRFFBTERBRUxJQU5CQkVrRVFDQUFJUUlNQVFzZ0FDQURRUVJySWdSTEJFQWdBQ0VDREFFTElBQWhBZ05BSUFJZ0FTMEFBRG9BQUNBQ0lBRXRBQUU2QUFFZ0FpQUJMUUFDT2dBQ0lBSWdBUzBBQXpvQUF5QUJRUVJxSVFFZ0FrRUVhaUlDSUFSTkRRQUxDeUFDSUFOSkJFQURRQ0FDSUFFdEFBQTZBQUFnQVVFQmFpRUJJQUpCQVdvaUFpQURSdzBBQ3dzZ0FBdnlBZ0lDZndGK0FrQWdBa1VOQUNBQUlBRTZBQUFnQUNBQ2FpSURRUUZySUFFNkFBQWdBa0VEU1EwQUlBQWdBVG9BQWlBQUlBRTZBQUVnQTBFRGF5QUJPZ0FBSUFOQkFtc2dBVG9BQUNBQ1FRZEpEUUFnQUNBQk9nQURJQU5CQkdzZ0FUb0FBQ0FDUVFsSkRRQWdBRUVBSUFCclFRTnhJZ1JxSWdNZ0FVSC9BWEZCZ1lLRUNHd2lBVFlDQUNBRElBSWdCR3RCZkhFaUJHb2lBa0VFYXlBQk5nSUFJQVJCQ1VrTkFDQURJQUUyQWdnZ0F5QUJOZ0lFSUFKQkNHc2dBVFlDQUNBQ1FReHJJQUUyQWdBZ0JFRVpTUTBBSUFNZ0FUWUNHQ0FESUFFMkFoUWdBeUFCTmdJUUlBTWdBVFlDRENBQ1FSQnJJQUUyQWdBZ0FrRVVheUFCTmdJQUlBSkJHR3NnQVRZQ0FDQUNRUnhySUFFMkFnQWdCQ0FEUVFSeFFSaHlJZ1JySWdKQklFa05BQ0FCclVLQmdJQ0FFSDRoQlNBRElBUnFJUUVEUUNBQklBVTNBeGdnQVNBRk53TVFJQUVnQlRjRENDQUJJQVUzQXdBZ0FVRWdhaUVCSUFKQklHc2lBa0VmU3cwQUN3c2dBQXNqQVFGL0l3QkJFR3NpQXlRQUlBTWdBallDRENBQUlBRWdBaEJDSUFOQkVHb2tBQXN6QVFGL0lBQkJBU0FBR3lFQUFrQURRQ0FBRUNjaUFRMEJRYVR0QUNnQ0FDSUJCRUFnQVJFSEFBd0JDd3NRQndBTElBRUxGd0FnQUMwQUFFRWdjVVVFUUNBQklBSWdBQkE1R2dzTGJ3RUJmeU1BUVlBQ2F5SUZKQUFDUUNBQ0lBTk1EUUFnQkVHQXdBUnhEUUFnQlNBQlFmOEJjU0FDSUFOcklnSkJnQUlnQWtHQUFra2lBUnNRR3hvZ0FVVUVRQU5BSUFBZ0JVR0FBaEFlSUFKQmdBSnJJZ0pCL3dGTERRQUxDeUFBSUFVZ0FoQWVDeUFGUVlBQ2FpUUFDM1FCQVg4Z0FrVUVRQ0FBS0FJRUlBRW9BZ1JHRHdzZ0FDQUJSZ1JBUVFFUEN5QUJLQUlFSWdJdEFBQWhBUUpBSUFBb0FnUWlBeTBBQUNJQVJRMEFJQUFnQVVjTkFBTkFJQUl0QUFFaEFTQURMUUFCSWdCRkRRRWdBa0VCYWlFQ0lBTkJBV29oQXlBQUlBRkdEUUFMQ3lBQUlBRkdDOHdNQVFkL0FrQWdBRVVOQUNBQVFRaHJJZ01nQUVFRWF5Z0NBQ0lCUVhoeElnQnFJUVVDUUNBQlFRRnhEUUFnQVVFRGNVVU5BU0FESUFNb0FnQWlBV3NpQTBIRTZRQW9BZ0JKRFFFZ0FDQUJhaUVBSUFOQnlPa0FLQUlBUndSQUlBRkIvd0ZOQkVBZ0F5Z0NDQ0lDSUFGQkEzWWlCRUVEZEVIYzZRQnFSaG9nQWlBREtBSU1JZ0ZHQkVCQnRPa0FRYlRwQUNnQ0FFRitJQVIzY1RZQ0FBd0RDeUFDSUFFMkFnd2dBU0FDTmdJSURBSUxJQU1vQWhnaEJnSkFJQU1nQXlnQ0RDSUJSd1JBSUFNb0FnZ2lBaUFCTmdJTUlBRWdBallDQ0F3QkN3SkFJQU5CRkdvaUFpZ0NBQ0lFRFFBZ0EwRVFhaUlDS0FJQUlnUU5BRUVBSVFFTUFRc0RRQ0FDSVFjZ0JDSUJRUlJxSWdJb0FnQWlCQTBBSUFGQkVHb2hBaUFCS0FJUUlnUU5BQXNnQjBFQU5nSUFDeUFHUlEwQkFrQWdBeUFES0FJY0lnSkJBblJCNU9zQWFpSUVLQUlBUmdSQUlBUWdBVFlDQUNBQkRRRkJ1T2tBUWJqcEFDZ0NBRUYrSUFKM2NUWUNBQXdEQ3lBR1FSQkJGQ0FHS0FJUUlBTkdHMm9nQVRZQ0FDQUJSUTBDQ3lBQklBWTJBaGdnQXlnQ0VDSUNCRUFnQVNBQ05nSVFJQUlnQVRZQ0dBc2dBeWdDRkNJQ1JRMEJJQUVnQWpZQ0ZDQUNJQUUyQWhnTUFRc2dCU2dDQkNJQlFRTnhRUU5IRFFCQnZPa0FJQUEyQWdBZ0JTQUJRWDV4TmdJRUlBTWdBRUVCY2pZQ0JDQUFJQU5xSUFBMkFnQVBDeUFESUFWUERRQWdCU2dDQkNJQlFRRnhSUTBBQWtBZ0FVRUNjVVVFUUNBRlFjenBBQ2dDQUVZRVFFSE02UUFnQXpZQ0FFSEE2UUJCd09rQUtBSUFJQUJxSWdBMkFnQWdBeUFBUVFGeU5nSUVJQU5CeU9rQUtBSUFSdzBEUWJ6cEFFRUFOZ0lBUWNqcEFFRUFOZ0lBRHdzZ0JVSEk2UUFvQWdCR0JFQkJ5T2tBSUFNMkFnQkJ2T2tBUWJ6cEFDZ0NBQ0FBYWlJQU5nSUFJQU1nQUVFQmNqWUNCQ0FBSUFOcUlBQTJBZ0FQQ3lBQlFYaHhJQUJxSVFBQ1FDQUJRZjhCVFFSQUlBVW9BZ2dpQWlBQlFRTjJJZ1JCQTNSQjNPa0Fha1lhSUFJZ0JTZ0NEQ0lCUmdSQVFiVHBBRUcwNlFBb0FnQkJmaUFFZDNFMkFnQU1BZ3NnQWlBQk5nSU1JQUVnQWpZQ0NBd0JDeUFGS0FJWUlRWUNRQ0FGSUFVb0Fnd2lBVWNFUUNBRktBSUlJZ0pCeE9rQUtBSUFTUm9nQWlBQk5nSU1JQUVnQWpZQ0NBd0JDd0pBSUFWQkZHb2lBaWdDQUNJRURRQWdCVUVRYWlJQ0tBSUFJZ1FOQUVFQUlRRU1BUXNEUUNBQ0lRY2dCQ0lCUVJScUlnSW9BZ0FpQkEwQUlBRkJFR29oQWlBQktBSVFJZ1FOQUFzZ0IwRUFOZ0lBQ3lBR1JRMEFBa0FnQlNBRktBSWNJZ0pCQW5SQjVPc0FhaUlFS0FJQVJnUkFJQVFnQVRZQ0FDQUJEUUZCdU9rQVFianBBQ2dDQUVGK0lBSjNjVFlDQUF3Q0N5QUdRUkJCRkNBR0tBSVFJQVZHRzJvZ0FUWUNBQ0FCUlEwQkN5QUJJQVkyQWhnZ0JTZ0NFQ0lDQkVBZ0FTQUNOZ0lRSUFJZ0FUWUNHQXNnQlNnQ0ZDSUNSUTBBSUFFZ0FqWUNGQ0FDSUFFMkFoZ0xJQU1nQUVFQmNqWUNCQ0FBSUFOcUlBQTJBZ0FnQTBISTZRQW9BZ0JIRFFGQnZPa0FJQUEyQWdBUEN5QUZJQUZCZm5FMkFnUWdBeUFBUVFGeU5nSUVJQUFnQTJvZ0FEWUNBQXNnQUVIL0FVMEVRQ0FBUVFOMklnRkJBM1JCM09rQWFpRUFBbjlCdE9rQUtBSUFJZ0pCQVNBQmRDSUJjVVVFUUVHMDZRQWdBU0FDY2pZQ0FDQUFEQUVMSUFBb0FnZ0xJUUlnQUNBRE5nSUlJQUlnQXpZQ0RDQURJQUEyQWd3Z0F5QUNOZ0lJRHd0Qkh5RUNJQU5DQURjQ0VDQUFRZi8vL3dkTkJFQWdBRUVJZGlJQklBRkJnUDQvYWtFUWRrRUljU0lCZENJQ0lBSkJnT0FmYWtFUWRrRUVjU0lDZENJRUlBUkJnSUFQYWtFUWRrRUNjU0lFZEVFUGRpQUJJQUp5SUFSeWF5SUJRUUYwSUFBZ0FVRVZhblpCQVhGeVFSeHFJUUlMSUFNZ0FqWUNIQ0FDUVFKMFFlVHJBR29oQVFKQUFrQUNRRUc0NlFBb0FnQWlCRUVCSUFKMElnZHhSUVJBUWJqcEFDQUVJQWR5TmdJQUlBRWdBellDQUNBRElBRTJBaGdNQVFzZ0FFRUFRUmtnQWtFQmRtc2dBa0VmUmh0MElRSWdBU2dDQUNFQkEwQWdBU0lFS0FJRVFYaHhJQUJHRFFJZ0FrRWRkaUVCSUFKQkFYUWhBaUFFSUFGQkJIRnFJZ2RCRUdvb0FnQWlBUTBBQ3lBSElBTTJBaEFnQXlBRU5nSVlDeUFESUFNMkFnd2dBeUFETmdJSURBRUxJQVFvQWdnaUFDQUROZ0lNSUFRZ0F6WUNDQ0FEUVFBMkFoZ2dBeUFFTmdJTUlBTWdBRFlDQ0F0QjFPa0FRZFRwQUNnQ0FFRUJheUlBUVg4Z0FCczJBZ0FMQzJvQkEzOGpBRUVRYXlJQkpBQWdBVUVBTmdJTUlBRWdBRFlDQkNBQklBQTJBZ0FnQVNBQVFRRnFOZ0lJSUFFaEFpTUFRUkJySWdNa0FDQURRUWhxSWdBZ0FpZ0NCRFlDQUNBQUtBSUFRUUU2QUFBZ0FpZ0NDRUVCT2dBQUlBTkJFR29rQUNBQlFSQnFKQUFMbGdFQkJIOGpBRUVRYXlJQkpBQWdBVUVBTmdJTUlBRWdBRFlDQkNBQklBQTJBZ0FnQVNBQVFRRnFOZ0lJSUFFaEF5TUFRUkJySWdRa0FDQUVRUWhxSWdBZ0F5Z0NCRFlDQUNBQUtBSUFMUUFBUlFSQUFuOENRQ0FES0FJSUlnSXRBQUFpQUVFQlJ3Ui9JQUJCQW5FTkFTQUNRUUk2QUFCQkFRVkJBQXNNQVFzUUJ3QUxJUUlMSUFSQkVHb2tBQ0FCUVJCcUpBQWdBZ3RMQVFKOElBQWdBS0lpQVNBQW9pSUNJQUVnQWFLaUlBRkVwMFk3aklmTnhqNmlSSFRueXVMNUFDcS9vS0lnQWlBQlJMTDdib2tRRVlFL29rUjNyTXRVVlZYRnY2Q2lJQUNnb0xZTFR3RUJmQ0FBSUFDaUlnQWdBQ0FBb2lJQm9pQUFSR2xRN3VCQ2svaytva1FuSGcvb2g4Qld2NkNpSUFGRVFqb0Y0Vk5WcFQraUlBQkVnVjRNL2YvLzM3K2lSQUFBQUFBQUFQQS9vS0NndGd2T0JBQkI4TjhBTFFBQVJRUkFRZVRmQUVFQU5nSUFRZGpmQUVFQU5nSUFRY3pmQUVFQU5nSUFRY0RmQUVFQU5nSUFRYlRmQUVFQU5nSUFRYWpmQUVFQU5nSUFRWnpmQUVFQU5nSUFRWkRmQUVFQU5nSUFRWVRmQUVFQU5nSUFRZmplQUVFQU5nSUFRZTNmQUVFQU9nQUFRZUhmQUVFQU9nQUFRZFhmQUVFQU9nQUFRY25mQUVFQU9nQUFRYjNmQUVFQU9nQUFRYkhmQUVFQU9nQUFRYVhmQUVFQU9nQUFRWm5mQUVFQU9nQUFRWTNmQUVFQU9nQUFRWUhmQUVFQU9nQUFRZlhlQUVFQU9nQUFRZkxlQUVHRGdvZ0lOZ0VBUWZEZUFFRVlPd0VBUWV6ZUFFSEhDRFlDQUVIbTNnQkJob0tJQ0RZQkFFSGszZ0JCR0RzQkFFSGczZ0JCNmdnMkFnQkIydDRBUVltQ2lBZzJBUUJCMk40QVFSZzdBUUJCMU40QVFmOEtOZ0lBUWM3ZUFFR0Rnb1FJTmdFQVFjemVBRUVZT3dFQVFjamVBRUhVQ0RZQ0FFSEMzZ0JCaG9LRUNEWUJBRUhBM2dCQkdEc0JBRUc4M2dCQjlBZzJBZ0JCdHQ0QVFZbUNoQWcyQVFCQnRONEFRUmc3QVFCQnNONEFRWXNMTmdJQVFhcmVBRUdEaG9RSU5nRUFRYWplQUVIQUFqc0JBRUdrM2dCQnV3ZzJBZ0JCbnQ0QVFZYUdoQWcyQVFCQm5ONEFRY0FDT3dFQVFaamVBRUhoQ0RZQ0FFR1MzZ0JCaVlhRUNEWUJBRUdRM2dCQndBSTdBUUJCak40QVFmUUtOZ0lBUVliZUFFR0Rob1FJTmdFQVFZVGVBRUVvT3dFQVFZRGVBRUhaQ0RZQ0FFSDYzUUJCaG9hRUNEWUJBRUg0M1FCQktEc0JBRUgwM1FCQitRZzJBZ0JCN3QwQVFZbUdoQWcyQVFCQjdOMEFRU2c3QVFCQjZOMEFRWkFMTmdJQVFmRGZBRUVCT2dBQUMwSG8zUUFMalM0QkMzOGpBRUVRYXlJTEpBQUNRQUpBQWtBQ1FBSkFBa0FDUUFKQUFrQUNRQUpBSUFCQjlBRk5CRUJCdE9rQUtBSUFJZ1pCRUNBQVFRdHFRWGh4SUFCQkMwa2JJZ2RCQTNZaUFuWWlBVUVEY1FSQUlBRkJmM05CQVhFZ0Ftb2lBMEVEZENJQlFlVHBBR29vQWdBaUJFRUlhaUVBQWtBZ0JDZ0NDQ0lDSUFGQjNPa0FhaUlCUmdSQVFiVHBBQ0FHUVg0Z0EzZHhOZ0lBREFFTElBSWdBVFlDRENBQklBSTJBZ2dMSUFRZ0EwRURkQ0lCUVFOeU5nSUVJQUVnQkdvaUFTQUJLQUlFUVFGeU5nSUVEQXdMSUFkQnZPa0FLQUlBSWdwTkRRRWdBUVJBQWtCQkFpQUNkQ0lBUVFBZ0FHdHlJQUVnQW5SeElnQkJBQ0FBYTNGQkFXc2lBQ0FBUVF4MlFSQnhJZ0oySWdGQkJYWkJDSEVpQUNBQ2NpQUJJQUIySWdGQkFuWkJCSEVpQUhJZ0FTQUFkaUlCUVFGMlFRSnhJZ0J5SUFFZ0FIWWlBVUVCZGtFQmNTSUFjaUFCSUFCMmFpSURRUU4wSWdCQjVPa0FhaWdDQUNJRUtBSUlJZ0VnQUVIYzZRQnFJZ0JHQkVCQnRPa0FJQVpCZmlBRGQzRWlCallDQUF3QkN5QUJJQUEyQWd3Z0FDQUJOZ0lJQ3lBRVFRaHFJUUFnQkNBSFFRTnlOZ0lFSUFRZ0Iyb2lBaUFEUVFOMElnRWdCMnNpQTBFQmNqWUNCQ0FCSUFScUlBTTJBZ0FnQ2dSQUlBcEJBM1lpQVVFRGRFSGM2UUJxSVFWQnlPa0FLQUlBSVFRQ2Z5QUdRUUVnQVhRaUFYRkZCRUJCdE9rQUlBRWdCbkkyQWdBZ0JRd0JDeUFGS0FJSUN5RUJJQVVnQkRZQ0NDQUJJQVEyQWd3Z0JDQUZOZ0lNSUFRZ0FUWUNDQXRCeU9rQUlBSTJBZ0JCdk9rQUlBTTJBZ0FNREF0QnVPa0FLQUlBSWdsRkRRRWdDVUVBSUFscmNVRUJheUlBSUFCQkRIWkJFSEVpQW5ZaUFVRUZka0VJY1NJQUlBSnlJQUVnQUhZaUFVRUNka0VFY1NJQWNpQUJJQUIySWdGQkFYWkJBbkVpQUhJZ0FTQUFkaUlCUVFGMlFRRnhJZ0J5SUFFZ0FIWnFRUUowUWVUckFHb29BZ0FpQVNnQ0JFRjRjU0FIYXlFRElBRWhBZ05BQWtBZ0FpZ0NFQ0lBUlFSQUlBSW9BaFFpQUVVTkFRc2dBQ2dDQkVGNGNTQUhheUlDSUFNZ0FpQURTU0lDR3lFRElBQWdBU0FDR3lFQklBQWhBZ3dCQ3dzZ0FTZ0NHQ0VJSUFFZ0FTZ0NEQ0lFUndSQUlBRW9BZ2dpQUVIRTZRQW9BZ0JKR2lBQUlBUTJBZ3dnQkNBQU5nSUlEQXNMSUFGQkZHb2lBaWdDQUNJQVJRUkFJQUVvQWhBaUFFVU5BeUFCUVJCcUlRSUxBMEFnQWlFRklBQWlCRUVVYWlJQ0tBSUFJZ0FOQUNBRVFSQnFJUUlnQkNnQ0VDSUFEUUFMSUFWQkFEWUNBQXdLQzBGL0lRY2dBRUcvZjBzTkFDQUFRUXRxSWdCQmVIRWhCMEc0NlFBb0FnQWlDVVVOQUVFQUlBZHJJUU1DUUFKQUFrQUNmMEVBSUFkQmdBSkpEUUFhUVI4Z0IwSC8vLzhIU3cwQUdpQUFRUWgySWdBZ0FFR0EvajlxUVJCMlFRaHhJZ0owSWdBZ0FFR0E0QjlxUVJCMlFRUnhJZ0YwSWdBZ0FFR0FnQTlxUVJCMlFRSnhJZ0IwUVE5MklBRWdBbklnQUhKcklnQkJBWFFnQnlBQVFSVnFka0VCY1hKQkhHb0xJZ1pCQW5SQjVPc0FhaWdDQUNJQ1JRUkFRUUFoQUF3QkMwRUFJUUFnQjBFQVFSa2dCa0VCZG1zZ0JrRWZSaHQwSVFFRFFBSkFJQUlvQWdSQmVIRWdCMnNpQlNBRFR3MEFJQUloQkNBRklnTU5BRUVBSVFNZ0FpRUFEQU1MSUFBZ0FpZ0NGQ0lGSUFVZ0FpQUJRUjEyUVFSeGFpZ0NFQ0lDUmhzZ0FDQUZHeUVBSUFGQkFYUWhBU0FDRFFBTEN5QUFJQVJ5UlFSQVFRQWhCRUVDSUFaMElnQkJBQ0FBYTNJZ0NYRWlBRVVOQXlBQVFRQWdBR3R4UVFGcklnQWdBRUVNZGtFUWNTSUNkaUlCUVFWMlFRaHhJZ0FnQW5JZ0FTQUFkaUlCUVFKMlFRUnhJZ0J5SUFFZ0FIWWlBVUVCZGtFQ2NTSUFjaUFCSUFCMklnRkJBWFpCQVhFaUFISWdBU0FBZG1wQkFuUkI1T3NBYWlnQ0FDRUFDeUFBUlEwQkN3TkFJQUFvQWdSQmVIRWdCMnNpQVNBRFNTRUNJQUVnQXlBQ0d5RURJQUFnQkNBQ0d5RUVJQUFvQWhBaUFRUi9JQUVGSUFBb0FoUUxJZ0FOQUFzTElBUkZEUUFnQTBHODZRQW9BZ0FnQjJ0UERRQWdCQ2dDR0NFR0lBUWdCQ2dDRENJQlJ3UkFJQVFvQWdnaUFFSEU2UUFvQWdCSkdpQUFJQUUyQWd3Z0FTQUFOZ0lJREFrTElBUkJGR29pQWlnQ0FDSUFSUVJBSUFRb0FoQWlBRVVOQXlBRVFSQnFJUUlMQTBBZ0FpRUZJQUFpQVVFVWFpSUNLQUlBSWdBTkFDQUJRUkJxSVFJZ0FTZ0NFQ0lBRFFBTElBVkJBRFlDQUF3SUN5QUhRYnpwQUNnQ0FDSUNUUVJBUWNqcEFDZ0NBQ0VEQWtBZ0FpQUhheUlCUVJCUEJFQkJ2T2tBSUFFMkFnQkJ5T2tBSUFNZ0Iyb2lBRFlDQUNBQUlBRkJBWEkyQWdRZ0FpQURhaUFCTmdJQUlBTWdCMEVEY2pZQ0JBd0JDMEhJNlFCQkFEWUNBRUc4NlFCQkFEWUNBQ0FESUFKQkEzSTJBZ1FnQWlBRGFpSUFJQUFvQWdSQkFYSTJBZ1FMSUFOQkNHb2hBQXdLQ3lBSFFjRHBBQ2dDQUNJSVNRUkFRY0RwQUNBSUlBZHJJZ0UyQWdCQnpPa0FRY3pwQUNnQ0FDSUNJQWRxSWdBMkFnQWdBQ0FCUVFGeU5nSUVJQUlnQjBFRGNqWUNCQ0FDUVFocUlRQU1DZ3RCQUNFQUlBZEJMMm9pQ1FKL1FZenRBQ2dDQUFSQVFaVHRBQ2dDQUF3QkMwR1k3UUJDZnpjQ0FFR1E3UUJDZ0tDQWdJQ0FCRGNDQUVHTTdRQWdDMEVNYWtGd2NVSFlxdFdxQlhNMkFnQkJvTzBBUVFBMkFnQkI4T3dBUVFBMkFnQkJnQ0FMSWdGcUlnWkJBQ0FCYXlJRmNTSUNJQWRORFFsQjdPd0FLQUlBSWdRRVFFSGs3QUFvQWdBaUF5QUNhaUlCSUFOTkRRb2dBU0FFU3cwS0MwSHc3QUF0QUFCQkJIRU5CQUpBQWtCQnpPa0FLQUlBSWdNRVFFSDA3QUFoQUFOQUlBTWdBQ2dDQUNJQlR3UkFJQUVnQUNnQ0JHb2dBMHNOQXdzZ0FDZ0NDQ0lBRFFBTEMwRUFFQ2tpQVVGL1JnMEZJQUloQmtHUTdRQW9BZ0FpQTBFQmF5SUFJQUZ4QkVBZ0FpQUJheUFBSUFGcVFRQWdBMnR4YWlFR0N5QUdJQWRORFFVZ0JrSCsvLy8vQjBzTkJVSHM3QUFvQWdBaUJBUkFRZVRzQUNnQ0FDSURJQVpxSWdBZ0EwME5CaUFBSUFSTERRWUxJQVlRS1NJQUlBRkhEUUVNQndzZ0JpQUlheUFGY1NJR1FmNy8vLzhIU3cwRUlBWVFLU0lCSUFBb0FnQWdBQ2dDQkdwR0RRTWdBU0VBQ3dKQUlBQkJmMFlOQUNBSFFUQnFJQVpORFFCQmxPMEFLQUlBSWdFZ0NTQUdhMnBCQUNBQmEzRWlBVUgrLy8vL0Iwc0VRQ0FBSVFFTUJ3c2dBUkFwUVg5SEJFQWdBU0FHYWlFR0lBQWhBUXdIQzBFQUlBWnJFQ2thREFRTElBQWlBVUYvUncwRkRBTUxRUUFoQkF3SEMwRUFJUUVNQlFzZ0FVRi9SdzBDQzBIdzdBQkI4T3dBS0FJQVFRUnlOZ0lBQ3lBQ1FmNy8vLzhIU3cwQklBSVFLU0VCUVFBUUtTRUFJQUZCZjBZTkFTQUFRWDlHRFFFZ0FDQUJUUTBCSUFBZ0FXc2lCaUFIUVNocVRRMEJDMEhrN0FCQjVPd0FLQUlBSUFacUlnQTJBZ0JCNk93QUtBSUFJQUJKQkVCQjZPd0FJQUEyQWdBTEFrQUNRQUpBUWN6cEFDZ0NBQ0lGQkVCQjlPd0FJUUFEUUNBQklBQW9BZ0FpQXlBQUtBSUVJZ0pxUmcwQ0lBQW9BZ2dpQUEwQUN3d0NDMEhFNlFBb0FnQWlBRUVBSUFBZ0FVMGJSUVJBUWNUcEFDQUJOZ0lBQzBFQUlRQkIrT3dBSUFZMkFnQkI5T3dBSUFFMkFnQkIxT2tBUVg4MkFnQkIyT2tBUVl6dEFDZ0NBRFlDQUVHQTdRQkJBRFlDQUFOQUlBQkJBM1FpQTBIazZRQnFJQU5CM09rQWFpSUNOZ0lBSUFOQjZPa0FhaUFDTmdJQUlBQkJBV29pQUVFZ1J3MEFDMEhBNlFBZ0JrRW9heUlEUVhnZ0FXdEJCM0ZCQUNBQlFRaHFRUWR4R3lJQWF5SUNOZ0lBUWN6cEFDQUFJQUZxSWdBMkFnQWdBQ0FDUVFGeU5nSUVJQUVnQTJwQktEWUNCRUhRNlFCQm5PMEFLQUlBTmdJQURBSUxJQUF0QUF4QkNIRU5BQ0FESUFWTERRQWdBU0FGVFEwQUlBQWdBaUFHYWpZQ0JFSE02UUFnQlVGNElBVnJRUWR4UVFBZ0JVRUlha0VIY1JzaUFHb2lBallDQUVIQTZRQkJ3T2tBS0FJQUlBWnFJZ0VnQUdzaUFEWUNBQ0FDSUFCQkFYSTJBZ1FnQVNBRmFrRW9OZ0lFUWREcEFFR2M3UUFvQWdBMkFnQU1BUXRCeE9rQUtBSUFJQUZMQkVCQnhPa0FJQUUyQWdBTElBRWdCbW9oQWtIMDdBQWhBQUpBQWtBQ1FBSkFBa0FDUUFOQUlBSWdBQ2dDQUVjRVFDQUFLQUlJSWdBTkFRd0NDd3NnQUMwQURFRUljVVVOQVF0QjlPd0FJUUFEUUNBRklBQW9BZ0FpQWs4RVFDQUNJQUFvQWdScUlnUWdCVXNOQXdzZ0FDZ0NDQ0VBREFBTEFBc2dBQ0FCTmdJQUlBQWdBQ2dDQkNBR2FqWUNCQ0FCUVhnZ0FXdEJCM0ZCQUNBQlFRaHFRUWR4RzJvaUNTQUhRUU55TmdJRUlBSkJlQ0FDYTBFSGNVRUFJQUpCQ0dwQkIzRWJhaUlHSUFjZ0NXb2lDR3NoQWlBRklBWkdCRUJCek9rQUlBZzJBZ0JCd09rQVFjRHBBQ2dDQUNBQ2FpSUFOZ0lBSUFnZ0FFRUJjallDQkF3REN5QUdRY2pwQUNnQ0FFWUVRRUhJNlFBZ0NEWUNBRUc4NlFCQnZPa0FLQUlBSUFKcUlnQTJBZ0FnQ0NBQVFRRnlOZ0lFSUFBZ0NHb2dBRFlDQUF3REN5QUdLQUlFSWdCQkEzRkJBVVlFUUNBQVFYaHhJUVVDUUNBQVFmOEJUUVJBSUFZb0FnZ2lBeUFBUVFOMklnQkJBM1JCM09rQWFrWWFJQU1nQmlnQ0RDSUJSZ1JBUWJUcEFFRzA2UUFvQWdCQmZpQUFkM0UyQWdBTUFnc2dBeUFCTmdJTUlBRWdBellDQ0F3QkN5QUdLQUlZSVFjQ1FDQUdJQVlvQWd3aUFVY0VRQ0FHS0FJSUlnQWdBVFlDRENBQklBQTJBZ2dNQVFzQ1FDQUdRUlJxSWdBb0FnQWlBdzBBSUFaQkVHb2lBQ2dDQUNJRERRQkJBQ0VCREFFTEEwQWdBQ0VFSUFNaUFVRVVhaUlBS0FJQUlnTU5BQ0FCUVJCcUlRQWdBU2dDRUNJRERRQUxJQVJCQURZQ0FBc2dCMFVOQUFKQUlBWWdCaWdDSENJRFFRSjBRZVRyQUdvaUFDZ0NBRVlFUUNBQUlBRTJBZ0FnQVEwQlFianBBRUc0NlFBb0FnQkJmaUFEZDNFMkFnQU1BZ3NnQjBFUVFSUWdCeWdDRUNBR1JodHFJQUUyQWdBZ0FVVU5BUXNnQVNBSE5nSVlJQVlvQWhBaUFBUkFJQUVnQURZQ0VDQUFJQUUyQWhnTElBWW9BaFFpQUVVTkFDQUJJQUEyQWhRZ0FDQUJOZ0lZQ3lBRklBWnFJUVlnQWlBRmFpRUNDeUFHSUFZb0FnUkJmbkUyQWdRZ0NDQUNRUUZ5TmdJRUlBSWdDR29nQWpZQ0FDQUNRZjhCVFFSQUlBSkJBM1lpQUVFRGRFSGM2UUJxSVFJQ2YwRzA2UUFvQWdBaUFVRUJJQUIwSWdCeFJRUkFRYlRwQUNBQUlBRnlOZ0lBSUFJTUFRc2dBaWdDQ0FzaEFDQUNJQWcyQWdnZ0FDQUlOZ0lNSUFnZ0FqWUNEQ0FJSUFBMkFnZ01Bd3RCSHlFQUlBSkIvLy8vQjAwRVFDQUNRUWgySWdBZ0FFR0EvajlxUVJCMlFRaHhJZ04wSWdBZ0FFR0E0QjlxUVJCMlFRUnhJZ0YwSWdBZ0FFR0FnQTlxUVJCMlFRSnhJZ0IwUVE5MklBRWdBM0lnQUhKcklnQkJBWFFnQWlBQVFSVnFka0VCY1hKQkhHb2hBQXNnQ0NBQU5nSWNJQWhDQURjQ0VDQUFRUUowUWVUckFHb2hCQUpBUWJqcEFDZ0NBQ0lEUVFFZ0FIUWlBWEZGQkVCQnVPa0FJQUVnQTNJMkFnQWdCQ0FJTmdJQUlBZ2dCRFlDR0F3QkN5QUNRUUJCR1NBQVFRRjJheUFBUVI5R0czUWhBQ0FFS0FJQUlRRURRQ0FCSWdNb0FnUkJlSEVnQWtZTkF5QUFRUjEySVFFZ0FFRUJkQ0VBSUFNZ0FVRUVjV29pQkNnQ0VDSUJEUUFMSUFRZ0NEWUNFQ0FJSUFNMkFoZ0xJQWdnQ0RZQ0RDQUlJQWcyQWdnTUFndEJ3T2tBSUFaQktHc2lBMEY0SUFGclFRZHhRUUFnQVVFSWFrRUhjUnNpQUdzaUFqWUNBRUhNNlFBZ0FDQUJhaUlBTmdJQUlBQWdBa0VCY2pZQ0JDQUJJQU5xUVNnMkFnUkIwT2tBUVp6dEFDZ0NBRFlDQUNBRklBUkJKeUFFYTBFSGNVRUFJQVJCSjJ0QkIzRWJha0V2YXlJQUlBQWdCVUVRYWtrYklnSkJHellDQkNBQ1FmenNBQ2tDQURjQ0VDQUNRZlRzQUNrQ0FEY0NDRUg4N0FBZ0FrRUlhallDQUVINDdBQWdCallDQUVIMDdBQWdBVFlDQUVHQTdRQkJBRFlDQUNBQ1FSaHFJUUFEUUNBQVFRYzJBZ1FnQUVFSWFpRUJJQUJCQkdvaEFDQUJJQVJKRFFBTElBSWdCVVlOQXlBQ0lBSW9BZ1JCZm5FMkFnUWdCU0FDSUFWcklnUkJBWEkyQWdRZ0FpQUVOZ0lBSUFSQi93Rk5CRUFnQkVFRGRpSUFRUU4wUWR6cEFHb2hBZ0ovUWJUcEFDZ0NBQ0lCUVFFZ0FIUWlBSEZGQkVCQnRPa0FJQUFnQVhJMkFnQWdBZ3dCQ3lBQ0tBSUlDeUVBSUFJZ0JUWUNDQ0FBSUFVMkFnd2dCU0FDTmdJTUlBVWdBRFlDQ0F3RUMwRWZJUUFnQlVJQU53SVFJQVJCLy8vL0IwMEVRQ0FFUVFoMklnQWdBRUdBL2o5cVFSQjJRUWh4SWdKMElnQWdBRUdBNEI5cVFSQjJRUVJ4SWdGMElnQWdBRUdBZ0E5cVFSQjJRUUp4SWdCMFFROTJJQUVnQW5JZ0FISnJJZ0JCQVhRZ0JDQUFRUlZxZGtFQmNYSkJIR29oQUFzZ0JTQUFOZ0ljSUFCQkFuUkI1T3NBYWlFREFrQkJ1T2tBS0FJQUlnSkJBU0FBZENJQmNVVUVRRUc0NlFBZ0FTQUNjallDQUNBRElBVTJBZ0FnQlNBRE5nSVlEQUVMSUFSQkFFRVpJQUJCQVhacklBQkJIMFliZENFQUlBTW9BZ0FoQVFOQUlBRWlBaWdDQkVGNGNTQUVSZzBFSUFCQkhYWWhBU0FBUVFGMElRQWdBaUFCUVFSeGFpSURLQUlRSWdFTkFBc2dBeUFGTmdJUUlBVWdBallDR0FzZ0JTQUZOZ0lNSUFVZ0JUWUNDQXdEQ3lBREtBSUlJZ0FnQ0RZQ0RDQURJQWcyQWdnZ0NFRUFOZ0lZSUFnZ0F6WUNEQ0FJSUFBMkFnZ0xJQWxCQ0dvaEFBd0ZDeUFDS0FJSUlnQWdCVFlDRENBQ0lBVTJBZ2dnQlVFQU5nSVlJQVVnQWpZQ0RDQUZJQUEyQWdnTFFjRHBBQ2dDQUNJQUlBZE5EUUJCd09rQUlBQWdCMnNpQVRZQ0FFSE02UUJCek9rQUtBSUFJZ0lnQjJvaUFEWUNBQ0FBSUFGQkFYSTJBZ1FnQWlBSFFRTnlOZ0lFSUFKQkNHb2hBQXdEQzBHSTZBQkJNRFlDQUVFQUlRQU1BZ3NDUUNBR1JRMEFBa0FnQkNnQ0hDSUNRUUowUWVUckFHb2lBQ2dDQUNBRVJnUkFJQUFnQVRZQ0FDQUJEUUZCdU9rQUlBbEJmaUFDZDNFaUNUWUNBQXdDQ3lBR1FSQkJGQ0FHS0FJUUlBUkdHMm9nQVRZQ0FDQUJSUTBCQ3lBQklBWTJBaGdnQkNnQ0VDSUFCRUFnQVNBQU5nSVFJQUFnQVRZQ0dBc2dCQ2dDRkNJQVJRMEFJQUVnQURZQ0ZDQUFJQUUyQWhnTEFrQWdBMEVQVFFSQUlBUWdBeUFIYWlJQVFRTnlOZ0lFSUFBZ0JHb2lBQ0FBS0FJRVFRRnlOZ0lFREFFTElBUWdCMEVEY2pZQ0JDQUVJQWRxSWdVZ0EwRUJjallDQkNBRElBVnFJQU0yQWdBZ0EwSC9BVTBFUUNBRFFRTjJJZ0JCQTNSQjNPa0FhaUVDQW45QnRPa0FLQUlBSWdGQkFTQUFkQ0lBY1VVRVFFRzA2UUFnQUNBQmNqWUNBQ0FDREFFTElBSW9BZ2dMSVFBZ0FpQUZOZ0lJSUFBZ0JUWUNEQ0FGSUFJMkFnd2dCU0FBTmdJSURBRUxRUjhoQUNBRFFmLy8vd2ROQkVBZ0EwRUlkaUlBSUFCQmdQNC9ha0VRZGtFSWNTSUNkQ0lBSUFCQmdPQWZha0VRZGtFRWNTSUJkQ0lBSUFCQmdJQVBha0VRZGtFQ2NTSUFkRUVQZGlBQklBSnlJQUJ5YXlJQVFRRjBJQU1nQUVFVmFuWkJBWEZ5UVJ4cUlRQUxJQVVnQURZQ0hDQUZRZ0EzQWhBZ0FFRUNkRUhrNndCcUlRRUNRQUpBSUFsQkFTQUFkQ0lDY1VVRVFFRzQ2UUFnQWlBSmNqWUNBQ0FCSUFVMkFnQU1BUXNnQTBFQVFSa2dBRUVCZG1zZ0FFRWZSaHQwSVFBZ0FTZ0NBQ0VIQTBBZ0J5SUJLQUlFUVhoeElBTkdEUUlnQUVFZGRpRUNJQUJCQVhRaEFDQUJJQUpCQkhGcUlnSW9BaEFpQncwQUN5QUNJQVUyQWhBTElBVWdBVFlDR0NBRklBVTJBZ3dnQlNBRk5nSUlEQUVMSUFFb0FnZ2lBQ0FGTmdJTUlBRWdCVFlDQ0NBRlFRQTJBaGdnQlNBQk5nSU1JQVVnQURZQ0NBc2dCRUVJYWlFQURBRUxBa0FnQ0VVTkFBSkFJQUVvQWh3aUFrRUNkRUhrNndCcUlnQW9BZ0FnQVVZRVFDQUFJQVEyQWdBZ0JBMEJRYmpwQUNBSlFYNGdBbmR4TmdJQURBSUxJQWhCRUVFVUlBZ29BaEFnQVVZYmFpQUVOZ0lBSUFSRkRRRUxJQVFnQ0RZQ0dDQUJLQUlRSWdBRVFDQUVJQUEyQWhBZ0FDQUVOZ0lZQ3lBQktBSVVJZ0JGRFFBZ0JDQUFOZ0lVSUFBZ0JEWUNHQXNDUUNBRFFROU5CRUFnQVNBRElBZHFJZ0JCQTNJMkFnUWdBQ0FCYWlJQUlBQW9BZ1JCQVhJMkFnUU1BUXNnQVNBSFFRTnlOZ0lFSUFFZ0Iyb2lBaUFEUVFGeU5nSUVJQUlnQTJvZ0F6WUNBQ0FLQkVBZ0NrRURkaUlBUVFOMFFkenBBR29oQlVISTZRQW9BZ0FoQkFKL1FRRWdBSFFpQUNBR2NVVUVRRUcwNlFBZ0FDQUdjallDQUNBRkRBRUxJQVVvQWdnTElRQWdCU0FFTmdJSUlBQWdCRFlDRENBRUlBVTJBZ3dnQkNBQU5nSUlDMEhJNlFBZ0FqWUNBRUc4NlFBZ0F6WUNBQXNnQVVFSWFpRUFDeUFMUVJCcUpBQWdBQXN4QUNBQkFuOGdBaWdDVEVFQVNBUkFJQUFnQVNBQ0VEa01BUXNnQUNBQklBSVFPUXNpQUVZRVFBOExJQUFnQVc0YUMxSUJBbjlCZ05jQUtBSUFJZ0VnQUVFRGFrRjhjU0lDYWlFQUFrQWdBa0VBSUFBZ0FVMGJEUUFnQUQ4QVFSQjBTd1JBSUFBUUZFVU5BUXRCZ05jQUlBQTJBZ0FnQVE4TFFZam9BRUV3TmdJQVFYOExnd0VDQTM4QmZnSkFJQUJDZ0lDQWdCQlVCRUFnQUNFRkRBRUxBMEFnQVVFQmF5SUJJQUFnQUVJS2dDSUZRZ3ArZmFkQk1ISTZBQUFnQUVMLy8vLy9ud0ZXSVFJZ0JTRUFJQUlOQUFzTElBV25JZ0lFUUFOQUlBRkJBV3NpQVNBQ0lBSkJDbTRpQTBFS2JHdEJNSEk2QUFBZ0FrRUpTeUVFSUFNaEFpQUVEUUFMQ3lBQkMrY0NBZ04vQVh3akFFRVFheUlCSkFBQ2ZTQUF2Q0lEUWYvLy8vOEhjU0lDUWRxZnBQb0RUUVJBUXdBQWdEOGdBa0dBZ0lETUEwa05BUm9nQUxzUUpRd0JDeUFDUWRHbjdZTUVUUVJBSUFDN0lRUWdBa0hrbDl1QUJFOEVRRVFZTFVSVSt5RUp3RVFZTFVSVSt5RUpRQ0FEUVFCT0d5QUVvQkFsakF3Q0N5QURRUUJJQkVBZ0JFUVlMVVJVK3lINVA2QVFKQXdDQzBRWUxVUlUreUg1UHlBRW9SQWtEQUVMSUFKQjFlT0lod1JOQkVBZ0FrSGcyNytGQkU4RVFFUVlMVVJVK3lFWndFUVlMVVJVK3lFWlFDQURRUUJPR3lBQXU2QVFKUXdDQ3lBRFFRQklCRUJFMGlFemYzelpFc0FnQUx1aEVDUU1BZ3NnQUx0RTBpRXpmM3paRXNDZ0VDUU1BUXNnQUNBQWt5QUNRWUNBZ1B3SFR3MEFHZ0pBQWtBQ1FBSkFJQUFnQVVFSWFoQkxRUU54RGdNQUFRSURDeUFCS3dNSUVDVU1Bd3NnQVNzRENKb1FKQXdDQ3lBQkt3TUlFQ1dNREFFTElBRXJBd2dRSkFzaEFDQUJRUkJxSkFBZ0FBc0dBQ0FBRUNFTHhRRUJBbjhqQUVFUWF5SUJKQUFDUUNBQXZVSWdpS2RCLy8vLy93ZHhJZ0pCKzhPay93Tk5CRUFnQWtHQWdNRHlBMGtOQVNBQVJBQUFBQUFBQUFBQVFRQVFMaUVBREFFTElBSkJnSURBL3dkUEJFQWdBQ0FBb1NFQURBRUxBa0FDUUFKQUFrQWdBQ0FCRUV4QkEzRU9Bd0FCQWdNTElBRXJBd0FnQVNzRENFRUJFQzRoQUF3REN5QUJLd01BSUFFckF3Z1FMeUVBREFJTElBRXJBd0FnQVNzRENFRUJFQzZhSVFBTUFRc2dBU3NEQUNBQkt3TUlFQythSVFBTElBRkJFR29rQUNBQUM1a0JBUU44SUFBZ0FLSWlBeUFESUFPaW9pQURSSHpWejFvNjJlVTlva1RybkN1SzV1VmF2cUNpSUFNZ0EwUjkvckZYNHgzSFBxSkUxV0hCR2FBQktyK2dva1NtK0JBUkVSR0JQNkNnSVFVZ0F5QUFvaUVFSUFKRkJFQWdCQ0FESUFXaVJFbFZWVlZWVmNXL29LSWdBS0FQQ3lBQUlBTWdBVVFBQUFBQUFBRGdQNklnQlNBRW9xR2lJQUdoSUFSRVNWVlZWVlZWeFQraW9LRUxrZ0VCQTN4RUFBQUFBQUFBOEQ4Z0FDQUFvaUlDUkFBQUFBQUFBT0Evb2lJRG9TSUVSQUFBQUFBQUFQQS9JQVNoSUFPaElBSWdBaUFDSUFKRWtCWExHYUFCK2o2aVJIZFJ3Ulpzd1ZhL29LSkVURlZWVlZWVnBUK2dvaUFDSUFLaUlnTWdBNklnQWlBQ1JOUTRpTDdwK3FpOW9rVEVzYlM5bnU0aFBxQ2lSSzFTbklCUGZwSytvS0tnb2lBQUlBR2lvYUNnQzYwS0F3dC9CbndCZlNNQVFTQnJJZ3NrQUNBTElBQXBBekEzQXhnZ0N5QUFLUU1vTndNUUlBc2dBQ2tESURjRENDQUFJQUFvQWlBZ0FtbzJBaUFnQkFSQUlBSkJRR29oRENBQUtBSVlJUVlnQUNnQ0VDRUpBMEFnQmlBRlFRSjBJZ2RxSUFjZ0NXb2lCeW9DQURnQ0FDQUhJQU1nQlNBTWFrRUNkR29xQWdBNEFnQWdCaUFGUVFGeUlnaEJBblFpQjJvZ0J5QUphaUlIS2dJQU9BSUFJQWNnQXlBSUlBeHFRUUowYWlvQ0FEZ0NBQ0FGUVFKcUlnVkJ3QUJIRFFBTEFrQWdBa0VBVEEwQVFRQWhCU0FDUVFGclFRTlBCRUFnQWtGOGNTRUhBMEFnQlVFQ2RDSUpJQVpxSWdnZ0F5QUphaW9DQURnQ2dBSWdDQ0FESUFsQkJISnFLZ0lBT0FLRUFpQUlJQU1nQ1VFSWNtb3FBZ0E0QW9nQ0lBZ2dBeUFKUVF4eWFpb0NBRGdDakFJZ0JVRUVhaUVGSUExQkJHb2lEU0FIUncwQUN3c2dBa0VEY1NJSVJRMEFBMEFnQlVFQ2RDSUhJQVpxSUFNZ0Iyb3FBZ0E0QW9BQ0lBVkJBV29oQlNBT1FRRnFJZzRnQ0VjTkFBc0xJQVloQXd0RUFBQUFBQUFBOEQ4Z0Fic2lGYU1oRkNBQUtBSWtJUVVnQUNnQ0tDRUdRWDhoQ2dOQUFrQUNRQ0FGSUFaTUJFQWdCU0VHREFFTElBUkZCRUFEUUNBS1FRRnFJZ29nQWs0TkF5QUFJQVpCQVdvaUJqWUNLQ0FGSUFaS0RRQUxJQVVoQmd3QkN3TkFJQXBCQVdvaUNpQUNUZzBDSUFNZ0NrRUNkR29xQWdBaEZpQUFLQUlJSWdZZ0JrRUVha0djQkJBNklBQW9BZ2dnRmpnQ25BUWdBQ0FBS0FJb1FRRnFJZ1UyQWlnZ0JTQUFLQUlrSWdaSURRQUxDeUFBS0FJZ1FVQnJJUWNnQndKL0lBQXJBekFpRTBRQUFBQUFBQUJRUUtBaUVKbEVBQUFBQUFBQTRFRmpCRUFnRUtvTUFRdEJnSUNBZ0hnTElnaElJUVVnQnlBSUlBVWJJUXdDZnlBVFJBQUFBQUFBQUZEQW9FUUFBQUFBQUFEd1A2QWlFSmxFQUFBQUFBQUE0RUZqQkVBZ0VLb01BUXRCZ0lDQWdIZ0xJZzVCQUNBT1FRQktHeUVGUWNBQUlBWnJJUWtDUUNBQlF3QUFnRDlkQkVCRUFBQUFBQUFBQUFBaEVpQUZJQXhPRFFFZ0FDZ0NDQ0VJQTBCRUFBQUFBQUFBQUFBaEVTQUlJQVVnQ1dwQkFuUnFLZ0lBdXlBVElBVzNvWmtpRUVRQUFBQUFBSUJQUUdZRWZFUUFBQUFBQUFBQUFBVWdBQ2dDQUFKL0lCQkVBQUFBQUFBQVFFQ2lJaEdaUkFBQUFBQUFBT0JCWXdSQUlCR3FEQUVMUVlDQWdJQjRDeUlOUVFKMGFpSUhLZ0lFdXlBSEtnSUF1eUlRb1NBUklBMjNvYUlnRUtBTG9pQVNvQ0VTSUFWQkFXb2lCU0FNUncwQUN3d0JDMFFBQUFBQUFBQUFBQ0VTSUFVZ0RFNE5BQ0FBS0FJSUlRZ0RRRVFBQUFBQUFBQUFBQ0VSSUJRZ0NDQUZJQWxxUVFKMGFpb0NBTHVpSUJRZ0V5QUZ0NkdpbVNJUVJBQUFBQUFBZ0U5QVpnUjhSQUFBQUFBQUFBQUFCU0FBS0FJQUFuOGdFRVFBQUFBQUFBQkFRS0lpRVpsRUFBQUFBQUFBNEVGakJFQWdFYW9NQVF0QmdJQ0FnSGdMSWcxQkFuUnFJZ2NxQWdTN0lBY3FBZ0M3SWhDaElCRWdEYmVob2lBUW9BdWlJQktnSVJJZ0JVRUJhaUlGSUF4SERRQUxDeUFFQkVBZ0JDQVBRUUowYWlBU3RqZ0NBQXNnQUNBR05nSW9JQUFnRXlBVm9DSVFPUU13SUFBQ2Z5QVFtVVFBQUFBQUFBRGdRV01FUUNBUXFnd0JDMEdBZ0lDQWVBc2lCVFlDSkNBUFFRRnFJUThnQlNBR1RBMEJBMEFnQ2tFQmFpSUtJQUpPRFFFZ0FDQUVCSDhnQXlBS1FRSjBhaW9DQUNFV0lBQW9BZ2dpQmlBR1FRUnFRWndFRURvZ0FDZ0NDQ0FXT0FLY0JDQUFLQUlrSVFVZ0FDZ0NLQVVnQmd0QkFXb2lCallDS0NBRklBWktEUUFMREFFTEN5QUVSUVJBSUFBZ0N5a0RDRGNESUNBQUlBc3BBeGczQXpBZ0FDQUxLUU1RTndNb0N5QUxRU0JxSkFBZ0R3dEpBUUovSUFBb0FnUWlCVUVJZFNFR0lBQW9BZ0FpQUNBQklBVkJBWEVFZnlBR0lBSW9BZ0JxS0FJQUJTQUdDeUFDYWlBRFFRSWdCVUVDY1JzZ0JDQUFLQUlBS0FJWUVRUUFDLzBDQWdGOEEzOGpBRUVRYXlJQ0pBQUNRQ0FBdkNJRVFmLy8vLzhIY1NJRFFkcWZwUG9EVFFSQUlBTkJnSUNBekFOSkRRRWdBTHNRSkNFQURBRUxJQU5CMGFmdGd3Uk5CRUFnQUxzaEFTQURRZU9YMjRBRVRRUkFJQVJCQUVnRVFDQUJSQmd0UkZUN0lmay9vQkFsakNFQURBTUxJQUZFR0MxRVZQc2grYitnRUNVaEFBd0NDMFFZTFVSVSt5RUp3RVFZTFVSVSt5RUpRQ0FFUVFCT0d5QUJvSm9RSkNFQURBRUxJQU5CMWVPSWh3Uk5CRUFnQUxzaEFTQURRZC9idjRVRVRRUkFJQVJCQUVnRVFDQUJSTkloTTM5ODJSSkFvQkFsSVFBTUF3c2dBVVRTSVROL2ZOa1N3S0FRSll3aEFBd0NDMFFZTFVSVSt5RVp3RVFZTFVSVSt5RVpRQ0FFUVFCT0d5QUJvQkFrSVFBTUFRc2dBMEdBZ0lEOEIwOEVRQ0FBSUFDVElRQU1BUXNDUUFKQUFrQUNRQ0FBSUFKQkNHb1FTMEVEY1E0REFBRUNBd3NnQWlzRENCQWtJUUFNQXdzZ0Fpc0RDQkFsSVFBTUFnc2dBaXNEQ0pvUUpDRUFEQUVMSUFJckF3Z1FKWXdoQUFzZ0FrRVFhaVFBSUFBTHFBRUFBa0FnQVVHQUNFNEVRQ0FBUkFBQUFBQUFBT0Ivb2lFQUlBRkIvdzlKQkVBZ0FVSC9CMnNoQVF3Q0N5QUFSQUFBQUFBQUFPQi9vaUVBSUFGQi9SY2dBVUg5RjBrYlFmNFBheUVCREFFTElBRkJnWGhLRFFBZ0FFUUFBQUFBQUFCZ0E2SWhBQ0FCUWJod1N3UkFJQUZCeVFkcUlRRU1BUXNnQUVRQUFBQUFBQUJnQTZJaEFDQUJRZkJvSUFGQjhHaExHMEdTRDJvaEFRc2dBQ0FCUWY4SGFxMUNOSWEvb2dzRkFCQmdBQXRMQVFKL0lBQW9BZ1FpQmtFSWRTRUhJQUFvQWdBaUFDQUJJQUlnQmtFQmNRUi9JQWNnQXlnQ0FHb29BZ0FGSUFjTElBTnFJQVJCQWlBR1FRSnhHeUFGSUFBb0FnQW9BaFFSQmdBTG1nRUFJQUJCQVRvQU5RSkFJQUFvQWdRZ0FrY05BQ0FBUVFFNkFEUUNRQ0FBS0FJUUlnSkZCRUFnQUVFQk5nSWtJQUFnQXpZQ0dDQUFJQUUyQWhBZ0EwRUJSdzBDSUFBb0FqQkJBVVlOQVF3Q0N5QUJJQUpHQkVBZ0FDZ0NHQ0lDUVFKR0JFQWdBQ0FETmdJWUlBTWhBZ3NnQUNnQ01FRUJSdzBDSUFKQkFVWU5BUXdDQ3lBQUlBQW9BaVJCQVdvMkFpUUxJQUJCQVRvQU5nc0xYUUVCZnlBQUtBSVFJZ05GQkVBZ0FFRUJOZ0lrSUFBZ0FqWUNHQ0FBSUFFMkFoQVBDd0pBSUFFZ0EwWUVRQ0FBS0FJWVFRSkhEUUVnQUNBQ05nSVlEd3NnQUVFQk9nQTJJQUJCQWpZQ0dDQUFJQUFvQWlSQkFXbzJBaVFMQzZ3QkF3RjhBWDRCZnlBQXZTSUNRalNJcDBIL0QzRWlBMEd5Q0UwRWZDQURRZjBIVFFSQUlBQkVBQUFBQUFBQUFBQ2lEd3NDZkNBQUlBQ2FJQUpDQUZrYklnQkVBQUFBQUFBQU1FT2dSQUFBQUFBQUFERERvQ0FBb1NJQlJBQUFBQUFBQU9BL1pBUkFJQUFnQWFCRUFBQUFBQUFBOEwrZ0RBRUxJQUFnQWFBaUFDQUJSQUFBQUFBQUFPQy9aVVVOQUJvZ0FFUUFBQUFBQUFEd1A2QUxJZ0FnQUpvZ0FrSUFXUnNGSUFBTEM4QUJBUU4vQWtBZ0FTQUNLQUlRSWdNRWZ5QURCU0FDRUVnTkFTQUNLQUlRQ3lBQ0tBSVVJZ1ZyU3dSQUlBSWdBQ0FCSUFJb0FpUVJBd0FQQ3dKQUlBSW9BbEJCQUVnRVFFRUFJUU1NQVFzZ0FTRUVBMEFnQkNJRFJRUkFRUUFoQXd3Q0N5QUFJQU5CQVdzaUJHb3RBQUJCQ2tjTkFBc2dBaUFBSUFNZ0FpZ0NKQkVEQUNJRUlBTkpEUUVnQUNBRGFpRUFJQUVnQTJzaEFTQUNLQUlVSVFVTElBVWdBQ0FCRUJvYUlBSWdBaWdDRkNBQmFqWUNGQ0FCSUFOcUlRUUxJQVFMMVFJQkFuOENRQ0FBSUFGR0RRQWdBU0FBSUFKcUlnUnJRUUFnQWtFQmRHdE5CRUFnQUNBQklBSVFHaG9QQ3lBQUlBRnpRUU54SVFNQ1FBSkFJQUFnQVVrRVFDQUREUUlnQUVFRGNVVU5BUU5BSUFKRkRRUWdBQ0FCTFFBQU9nQUFJQUZCQVdvaEFTQUNRUUZySVFJZ0FFRUJhaUlBUVFOeERRQUxEQUVMQWtBZ0F3MEFJQVJCQTNFRVFBTkFJQUpGRFFVZ0FDQUNRUUZySWdKcUlnTWdBU0FDYWkwQUFEb0FBQ0FEUVFOeERRQUxDeUFDUVFOTkRRQURRQ0FBSUFKQkJHc2lBbW9nQVNBQ2FpZ0NBRFlDQUNBQ1FRTkxEUUFMQ3lBQ1JRMENBMEFnQUNBQ1FRRnJJZ0pxSUFFZ0Ftb3RBQUE2QUFBZ0FnMEFDd3dDQ3lBQ1FRTk5EUUFEUUNBQUlBRW9BZ0EyQWdBZ0FVRUVhaUVCSUFCQkJHb2hBQ0FDUVFScklnSkJBMHNOQUFzTElBSkZEUUFEUUNBQUlBRXRBQUE2QUFBZ0FFRUJhaUVBSUFGQkFXb2hBU0FDUVFGcklnSU5BQXNMQzY4dUFROS9JQUFnQUMwQUFTSU1JQUFvQWdScVFRRnFOZ0lRSUFBb0Fod29BZ0FnQUM4QkdHb2dBU0FBTFFBQUloRVFHaG9nQUNBUk9nQVVJQUF0QUFBaUJDQUFLQUljS0FJQUlBQXZBUmhxYWlBQ0lBQXRBQUVpQVJBYUdpQUFJQUVnQkdvaUFqb0FGQ0FBSUFBdEFDQWlBU0FDSUFFZ0FrSC9BWEZMR3lJQk9nQWdJQUFvQWlnb0FnQWdBQzhCSkdvZ0FDZ0NIQ2dDQUNBQUx3RVlhaUFCUWY4QmNSQWFHaUFBSUFFNkFDQWdBRUVBT2dDa0FVRUJJUkFnQUNBQUxRQUJRUUZxT2dCMElBQW9BbndvQWdBZ0FDOEJlR3BCQURvQUFDQUFMUUFCQkVBRFFDQVFRZjhCY1NJS1FRRnJRZjhCYnlFQklBQW9BaHdvQWdBZ0FDOEJHR29pQnkwQUFDRUNBa0FnQUMwQUZDSUlRUUpKRFFBZ0FVSC9BV29nQVNBQlFRQklHMEh3S21vdEFBQWhCa0VCSVFFZ0NFRUJheUlFUVFGeElRVWdDRUVDUndSQUlBUkJmbkVoQ0VFQUlRMERRQ0FCUVFGcUlRUWdBa0gvQVhFaUFnUi9JQVpCOENocUxRQUFJQUpCOENocUxRQUFha0h3S21vdEFBQUZRUUFMSUFFZ0Iyb3RBQUJ6UWY4QmNTSUNCSDhnQmtId0tHb3RBQUFnQWtId0tHb3RBQUJxUWZBcWFpMEFBQVZCQUFzaEFpQUJRUUpxSVFFZ0JDQUhhaTBBQUNBQ2N5RUNJQTFCQW1vaURTQUlSdzBBQ3dzZ0JVVU5BQ0FDUWY4QmNTSUNCSDhnQmtId0tHb3RBQUFnQWtId0tHb3RBQUJxUWZBcWFpMEFBQVZCQUFzZ0FTQUhhaTBBQUhNaEFnc2dBQ2dDZkNnQ0FDQUFMd0Y0YWlBS2FpQUNPZ0FBSUFBdEFBRWdFRUVCYWlJUVFmOEJjVThOQUFzTEFrQUNRQ0FBTFFCMElnUkZEUUFnRENBUmFpRVNJQUFvQW53b0FnQWdBQzhCZUdvaEFrRUFJUUVEUUNBQklBSnFMUUFBUlFSQUlBUWdBVUVCYWlJQlJ3MEJEQUlMQ3lBU1FmOEJjU0lQSVFWQkFDRUJRUUFoQWlBQVFRQTZBRGdDUUNBQUxRQ2tBVVVOQUFOQUlBQW9BcXdCS0FJQUlBQXZBYWdCYWlBQmFpMEFBQ0VJSUFBb0FrQW9BZ0FoQkNBQUlBSkJBV282QURnZ0JDQUFMd0U4YWlBQ1FmOEJjV29nQ0VGL2N5QUZham9BQUNBQlFRRnFJZ0VnQUMwQXBBRlBEUUVnQUMwQU9DRUNEQUFMQUFzZ0FDZ0NpQUVvQWdBZ0FDOEJoQUZxUVFBZ0FDMEFnZ0VRR3hvZ0FDZ0NpQUVvQWdBZ0FDOEJoQUZxSUFBb0Fud29BZ0FnQUM4QmVHcEJBV29nQUMwQWRFRUJheUlDUWY4QmNSQWFHaUFBSUFJNkFJQUJJQUF0QUtRQklnRUVRQU5BSUFKQi93RnhRUUZMQkVCQkFDRUJRUUFnQUNnQ1FDZ0NBQ0FBTHdFOGFpQUphaTBBQUNJQ0lBSkIvd0ZHRzBId0ttb3RBQUFoQ2dOQVFRQWhBaUFBS0FLSUFTZ0NBQ0FBTHdHRUFXb2lCU0FCUWY4QmNXb2lDQzBBQUNJRUJFQWdDa0h3S0dvdEFBQWdCRUh3S0dvdEFBQnFRZkFxYWkwQUFDRUNDeUFJSUFVZ0FVRUJhaUlCUWY4QmNXb3RBQUFnQW5NNkFBQWdBQzBBZ0FFaUFrRUJheUFCUVJoMFFSaDFTZzBBQ3lBQUxRQ2tBU0VCQ3lBSlFRRnFJZ2tnQVVIL0FYRkpEUUFMQzBFQUlSQWdBQzBBcEFFaENTQUFRUUU2QUVRZ0FFRUJPZ0E0SUFCQlFHc29BZ0FvQWdBZ0FDOEJQR3BCQVRvQUFDQUFLQUpNS0FJQUlBQXZBVWhxUVFFNkFBQWdDU0FBTFFBQklnMUhCRUFnQUMwQWdBRWlBU0FOYTBIL0FYRkJBQ0FCSUExTEd5RUdBMEFnQUNnQ2lBRW9BZ0FnQUM4QmhBRnFJZ3dnQmlBT2FpSUtRZjhCY1dvdEFBQWhEU0FBTFFBNElnZEJBazhFUUNBQUtBSkFLQUlBSUFBdkFUeHFJUVZCQVNFQlFRRWhBZ05BUVFBaEN3SkFJQVVnQnlBQ1FYOXpha0gvQVhGcUxRQUFJZ2hGRFFBZ0RDQUtJQUZyUWY4QmNXb3RBQUFpQkVVTkFDQUVRZkFvYWkwQUFDQUlRZkFvYWkwQUFHcEI4Q3BxTFFBQUlRc0xJQUpCQVdvaEFpQUxJQTF6SVEwZ0FVRUJhaUlCSUFkSERRQUxDeUFBS0FKTUtBSUFJUUlnQUNBQUxRQkVJZ0ZCQVdvNkFFUWdBU0FDSUFBdkFVaHFha0VBT2dBQUlBMUIvd0Z4SWdnRVFDQUFMUUJFSWdzZ0FDMEFPQ0lCU3dSQUlBQWdDem9BWENBTlFmOEJjU0VJUVFBaEFnTkFJQUFvQW1Rb0FnQWdBQzhCWUdvZ0Ftb2dBQ2dDVENnQ0FDQUFMd0ZJYWlBQ2FpMEFBQ0lCQkg4Z0NFSHdLR290QUFBZ0FVSHdLR290QUFCcVFmQXFhaTBBQUFWQkFBczZBQUFnQWtFQmFpSUNJQUF0QUVSSkRRQUxJQUFnQUMwQU9DSUJPZ0JFUVFBaEFnSkFJQUVFUUNBSVFmQW9haTBBQUVIL0FYTkI4Q3BxTFFBQUlRUURRQ0FBS0FKTUtBSUFJQUF2QVVocUlBSnFJQUFvQWtBb0FnQWdBQzhCUEdvZ0Ftb3RBQUFpQVFSL0lBUkI4Q2hxTFFBQUlBRkI4Q2hxTFFBQWFrSHdLbW90QUFBRlFRQUxPZ0FBSUFKQkFXb2lBaUFBTFFBNElnRkpEUUFMREFFTFFRQWhBUXNnQUNBQklBQXRBRndpQWlBQklBSkxHeUlCT2dBNElBQW9Ba0FvQWdBZ0FDOEJQR29nQUNnQ1pDZ0NBQ0FBTHdGZ2FpQUJFQm9hSUFBZ0FUb0FPQ0FBTFFCRUlRc0xJQUFnQ3pvQVhFRUFJUUlnQ3dSQUEwQWdBQ2dDWkNnQ0FDQUFMd0ZnYWlBQ2FpQUFLQUpNS0FJQUlBQXZBVWhxSUFKcUxRQUFJZ0VFZnlBSVFmQW9haTBBQUNBQlFmQW9haTBBQUdwQjhDcHFMUUFBQlVFQUN6b0FBQ0FDUVFGcUlnSWdBQzBBUkVrTkFBc2dBQzBBWENFQ0lBQXRBRGdoQVFzZ0FDQUJJQUlnQVVIL0FYRWdBa0gvQVhGTEd5SUNPZ0JvUVFBaEFTQUFLQUp3S0FJQUlBQXZBV3hxUVFBZ0FrSC9BWEVRR3hvZ0FDMEFPQ0lFQkVCQkFDRUNJQVFoQVFOQUlBQW9BbkFvQWdBZ0FDOEJiR29nQUMwQWFDQUNJQUZyYWtIL0FYRnFJQUFvQWtBb0FnQWdBQzhCUEdvZ0Ftb3RBQUE2QUFBZ0FrRUJhaUlDSUFBdEFEZ2lBVWtOQUFzTFFRQWhBaUFBTFFCY0lnc0VRQU5BSUFBb0FuQW9BZ0FnQUM4QmJHb2dBQzBBYUNBQ0lBdHJha0gvQVhGcUlnRWdBUzBBQUNBQUtBSmtLQUlBSUFBdkFXQnFJQUpxTFFBQWN6b0FBQ0FDUVFGcUlnSWdBQzBBWENJTFNRMEFDeUFBTFFBNElRRUxJQUFnQVNBQUxRQm9JZ0lnQVVIL0FYRWdBa3NiSWdFNkFEZ2dBQ2dDUUNnQ0FDQUFMd0U4YWlBQUtBSndLQUlBSUFBdkFXeHFJQUZCL3dGeEVCb2FJQUFnQVRvQU9Bc2dBQzBBQVNJTklBbHJJQTVCQVdvaURrSC9BWEZMRFFBTEN3SkFJQUF0QURnaUNFVUVRRUVBSVFJTUFRc2dBQ2dDUUNnQ0FDQUFMd0U4YWlFRVFRQWhBUU5BSUFFaUFrRUJhaUVCSUFRZ0FrSC9BWEZxTFFBQVJRMEFDd3NnRFNBQ1FYOXpJQWxySUFocVFRRjBJQWxxVHdSQUlBQW9BcUFCS0FJQUlBQXZBWndCYWlBQUtBSkFLQUlBSUFBdkFUeHFJQUpxSUFnZ0Ftc1FHaG9nQUNBQUxRQTRJQUpyT2dDWUFRc2dBQ0FBTFFDWUFTSUVPZ0E0SUFSQkdIUkJnSUNBQ0d0QkdIVWlBVUVBVGdSQVFRQWhDd05BSUFBb0FrQW9BZ0FnQUM4QlBHb2dDMm9nQUNnQ29BRW9BZ0FnQUM4Qm5BRnFJQUZCL3dGeGFpMEFBRG9BQUNBQlFRRnJJUUVnQzBFQmFpSUxJQVJIRFFBTElBQXRBRGdoQkFzZ0FFRUFPZ0N3QVNBUFJRUkFRUUVQQ3lBRUlRRkJBQ0VPQTBBZ0FDZ0NRQ2dDQUNBQUx3RThhaUlHTFFBQUlRSUNRQ0FCUWY4QmNTSUZRUUpKRFFBZ0VFSHdLbW90QUFBaERFRUJJUUVnQlVFQmF5SUlRUUZ4SVFvZ0JVRUNSd1JBSUFoQmZuRWhCVUVBSVEwRFFFRUFJUXNnQVVFQmFpRUlJQUpCL3dGeElnSUVmeUFNUWZBb2FpMEFBQ0FDUWZBb2FpMEFBR3BCOENwcUxRQUFCVUVBQ3lBQklBWnFMUUFBYzBIL0FYRWlBZ1IvSUF4QjhDaHFMUUFBSUFKQjhDaHFMUUFBYWtId0ttb3RBQUFGUVFBTElRSWdBVUVDYWlFQklBWWdDR290QUFBZ0FuTWhBaUFOUVFKcUlnMGdCVWNOQUFzTElBcEZEUUFnQWtIL0FYRWlBZ1IvSUF4QjhDaHFMUUFBSUFKQjhDaHFMUUFBYWtId0ttb3RBQUFGUVFBTElBRWdCbW90QUFCeklRSUxJQUpCL3dGeFJRUkFJQUFvQXJnQktBSUFJUUlnQUNBQUxRQ3dBU0lCUVFGcU9nQ3dBU0FCSUFJZ0FDOEJ0QUZxYWlBU0lBNUJmM05xT2dBQUN5QVBJQkJCQVdvaUVFY0VRQ0FPUVFGcUlRNGdBQzBBT0NFQkRBRUxDMEVCSVFFZ0FDMEFzQUVpQWlBRVFRRnJRZjhCY1VjTkFTQUNSUTBCSUFCQkZHb2hBa0VBSVFFRFFDQUFLQUs0QVNnQ0FDQUFMd0cwQVdvZ0FXb3RBQUFoQlNBQUtBS3NBU2dDQUNFSUlBQWdBQzBBcEFFaUJFRUJham9BcEFFZ0JDQUlJQUF2QWFnQmFtb2dCVG9BQUNBQlFRRnFJZ0VnQUMwQXNBRkpEUUFMSUFJaENFRUFJUUlnQUVHOEFXb2lCQ0FBTFFDa0FUb0FBQ0FBTFFDa0FRUkFBMEFnQUNnQ3hBRW9BZ0FnQUM4QndBRnFJQUpxSUFndEFBQWdBQ2dDckFFb0FnQWdBQzhCcUFGcUlBSnFMUUFBUVg5emFqb0FBQ0FDUVFGcUlnSWdBQzBBcEFGSkRRQUxDMEVBSVFvZ0FDSUJRUUU2QUl3QklBQW9BcFFCS0FJQUlBQXZBWkFCYWtFQk9nQUFJQUJCQWpvQVJDQUFRUUU2QURnZ0JDMEFBQVJBQTBBZ0FTZ0NRQ2dDQUNBQkx3RThha0VCT2dBQUlBRW9Ba3dvQWdBZ0FTOEJTR3BCQUNBRUtBSUlLQUlBSUFRdkFRUnFJQXBxTFFBQUlnSWdBa0gvQVVZYlFmQXFhaTBBQURvQUFDQUJLQUpNS0FJQUlBRXZBVWhxUVFBNkFBRWdBU0FCTFFBNElnVWdBUzBBUkNJQ0lBSWdCVWtiSWdJNkFGd2dBU2dDWkNnQ0FDQUJMd0ZnYWtFQUlBSVFHeHBCQUNFR0lBRXRBRGdpQndSQUEwQWdBU2dDWkNnQ0FDQUJMd0ZnYWlBQkxRQmNJQVlnQjJ0cVFmOEJjV29nQVNnQ1FDZ0NBQ0FCTHdFOGFpQUdhaTBBQURvQUFDQUdRUUZxSWdZZ0FTMEFPQ0lIU1EwQUN3dEJBQ0VHSUFFdEFFUWlCd1JBQTBBZ0FTZ0NaQ2dDQUNBQkx3RmdhaUFCTFFCY0lBWWdCMnRxUWY4QmNXb2lBaUFDTFFBQUlBRW9Ba3dvQWdBZ0FTOEJTR29nQm1vdEFBQnpPZ0FBSUFaQkFXb2lCaUFCTFFCRUlnZEpEUUFMQ3lBQklBRXRBSXdCSUFFdEFGeHFRUUZySWdJNkFHZ2dBU2dDY0NnQ0FDQUJMd0ZzYWtFQUlBSkIvd0Z4RUJzYUlBRXRBSXdCSVFjQ1FDQUJMUUJjSWdWRkRRQkJBQ0VNUVFFaEFpQUhSUVJBUVFBaEJ3d0JDd05BUVFBaEJpQUNRZjhCY1FSL0EwQkJBQ0VIQWtBZ0FTZ0NsQUVvQWdBZ0FTOEJrQUZxSUFacUxRQUFJZ1ZGRFFBZ0FTOEJZQ0FCS0FKa0tBSUFJQXhxYWkwQUFDSUNSUTBBSUFKQjhDaHFMUUFBSUFWQjhDaHFMUUFBYWtId0ttb3RBQUFoQndzZ0FTZ0NjQ2dDQUNBQkx3RnNhaUFHSUF4cVFmOEJjV29pQWlBQ0xRQUFJQWR6T2dBQUlBWkJBV29pQmlBQkxRQ01BU0lIU1EwQUN5QUJMUUJjSVFVZ0J3VkJBQXNoQWlBTVFRRnFJZ3dnQlVrTkFBc0xJQUVnQnlBQkxRQm9JZ0lnQWlBSFNSc2lBam9BakFFZ0FTZ0NsQUVvQWdBZ0FTOEJrQUZxSUFFb0FuQW9BZ0FnQVM4QmJHb2dBa0gvQVhFUUdob2dBU0FDT2dDTUFTQUtRUUZxSWdvZ0JDMEFBRWtOQUFzTElBRkIzQUJxSWdRZ0FTMEFkRG9BQUNBQkxRQjBJZ1ZCR0hSQmdJQ0FDR3RCR0hVaUFrRUFUZ1JBUVFBaENRTkFJQUVvQW1Rb0FnQWdBUzhCWUdvZ0NXb2dBU2dDZkNnQ0FDQUJMd0Y0YWlBQ1FmOEJjV290QUFBNkFBQWdBa0VCYXlFQ0lBbEJBV29pQ1NBRlJ3MEFDd3NnQVMwQWpBRkJBV3RCL3dGeElRWkJBQ0VISUFGQk9Hb2lBaUFFTFFBQUlBQXRBSXdCYWtFQmF5SUJPZ0FBSUFCQlFHc29BZ0FvQWdBZ0FDOEJQR3BCQUNBQlFmOEJjUkFiR2dKQUlBQXRBSXdCSWdwRkRRQWdCQzBBQUVVTkFFRUJJUVVEUUNBRlFmOEJjU0VCUVFBaEJTQUJCRUFEUUNBQUtBSkFLQUlBSUFBdkFUeHFJQVVnQjJwQi93RnhhaUlNQW45QkFDQUVLQUlJS0FJQUlBUXZBUVJxSUFWcUxRQUFJZ3BGRFFBYVFRQWdBQzhCa0FFZ0FDZ0NsQUVvQWdBZ0IycHFMUUFBSWdGRkRRQWFJQUZCOENocUxRQUFJQXBCOENocUxRQUFha0h3S21vdEFBQUxJQXd0QUFCek9nQUFJQVZCQVdvaUJTQUVMUUFBSWdGSkRRQUxJQUF0QUl3QklRb2dBU0VGQ3lBSFFRRnFJZ2NnQ2trTkFBc0xJQUFnQmtFQ2Fqb0FSQ0FBS0FKTUtBSUFJQUF2QVVocVFRQWdBQzBBUmhBYkdpQUFLQUpNS0FJQUlBQXZBVWhxUVFFNkFBQWdBaWdDQ0NnQ0FDQUNMd0VFYWlJRUlBQW9BbkFvQWdBZ0FDOEJiR29pQVVjRVFDQUJJQVFnQWkwQUFCQWFHZ3NnQUNBQ0xRQUFJZ1E2QUdoQkFDRU1JQUl0QUFBaUFTQUFMUUJFSWdWclFRRnFJZ1pCQUVvRVFBTkFBa0FnQUNnQ2NDZ0NBQ0FBTHdGc2FpQU1haTBBQUNJS1JRMEFRUUVoQmlBRlFRSkpEUUFEUUNBQUtBSk1LQUlBSUFBdkFVaHFJQVpxTFFBQUlnUUVRQ0FBS0FKd0tBSUFJQUF2QVd4cUlBWWdER3BCL3dGeGFpSUJJQUV0QUFBZ0NrSHdLR290QUFBZ0JFSHdLR290QUFCcVFmQXFhaTBBQUhNNkFBQWdBQzBBUkNFRkN5QUdRUUZxSWdZZ0JVa05BQXNnQWkwQUFDRUJDeUFNUVFGcUlnd2dBU0FGYTBFQmFpSUdTQTBBQ3lBQUxRQm9JUVFMSUFBb0FuQW9BZ0FnQUM4QmJHb2lBU0FCSUFacUlBUWdCbXNRT2lBQUlBQXRBR2dnQm1zNkFHZ2dBQ0FBTFFCb0lnRTZBTWdCSUFGQkdIUkJnSUNBQ0d0QkdIVWlBa0VBVGdSQVFRQWhDUU5BSUFBb0F0QUJLQUlBSUFBdkFjd0JhaUFKYWlBQUtBSndLQUlBSUFBdkFXeHFJQUpCL3dGeGFpMEFBRG9BQUNBQ1FRRnJJUUlnQ1VFQmFpSUpJQUZIRFFBTEMwRUFJUWtnQUVFQU9nQTRBa0FnQUMwQXZBRkZEUUJCQUNFQ0EwQWdBQ2dDeEFFb0FnQWdBQzhCd0FGcUlBSnFMUUFBSVFRZ0FDZ0NRQ2dDQUNFQklBQWdDVUVCYWpvQU9DQUJJQUF2QVR4cUlBbEIvd0Z4YWlBRVFYOXpRUUFnQkJ0Qi93RnhJZ0ZCL3dGelFRQWdBV3NnQVJ0QjhDcHFMUUFBT2dBQUlBSkJBV29pQWlBQUxRQzhBVThOQVNBQUxRQTRJUWtNQUFzQUMwRUFJUVFnQUNnQ1dDZ0NBQ0FBTHdGVWFrRUFJQUF0QUZJUUd4b2dBQ0FJTFFBQUlnSTZBRkFnQUMwQU9DSVBCRUFEUUNBQUtBSkFLQUlBSUFBdkFUeHFJQVJxTFFBQUlRRkJBQ0VDSUFCQkFEb0FSQ0FCUWZBb2FpMEFBRUgvQVhOQjhDcHFMUUFBSVFkQkFTRUpBa0FnRDBVTkFBTkFJQUlnQkVjRVFBSi9JQUFvQWtBb0FnQWdBQzhCUEdvZ0Ftb3RBQUFpQVFSQUlBRkI4Q2hxTFFBQUlBZEI4Q2hxTFFBQWFrSHdLbW90QUFBTUFRdEJBQXNoQ2lBQUtBSk1LQUlBSVFVZ0FDQUFMUUJFSWdGQkFXbzZBRVFnQVNBRklBQXZBVWhxYWlBS1FRRnpPZ0FBSUFBdEFEZ2hEd3NnQWtFQmFpSUNJQTlKRFFBTElBQXRBRVFpREVVTkFDQUFLQUpNS0FJQUlBQXZBVWhxSVFwQkFDRUNBMEFDZjBFQUlBbEIvd0Z4SWdWRkRRQWFRUUFnQWlBS2FpMEFBQ0lCUlEwQUdpQUJRZkFvYWkwQUFDQUZRZkFvYWkwQUFHcEI4Q3BxTFFBQUN5RUpJQUpCQVdvaUFpQU1SdzBBQ3dzZ0FDZ0NjQ2dDQUNBQUx3RnNhaUlHTFFBQUlRc0NRQ0FBTFFCb0lnVkJBa2tOQUVFQklRSWdCVUVCYXlJQlFRRnhJUXdnQlVFQ1J3UkFJQUZCZm5FaENrRUFJUTREUUVFQUlROGdBa0VCYWlFRklBdEIvd0Z4SWdFRWZ5QUhRZkFvYWkwQUFDQUJRZkFvYWkwQUFHcEI4Q3BxTFFBQUJVRUFDeUFDSUFacUxRQUFjeUlCQkg4Z0IwSHdLR290QUFBZ0FVSHdLR290QUFCcVFmQXFhaTBBQUFWQkFBc2hBU0FDUVFKcUlRSWdCU0FHYWkwQUFDQUJjeUVMSUE1QkFtb2lEaUFLUncwQUN3c2dERVVOQUNBTFFmOEJjU0lCQkg4Z0IwSHdLR290QUFBZ0FVSHdLR290QUFCcVFmQXFhaTBBQUFWQkFBc2dBaUFHYWkwQUFITWhDd3NnQUNnQ3JBRW9BZ0FnQUM4QnFBRnFJQVJxTFFBQUlBQW9BbGdvQWdBZ0FDOEJWR3BxSUF0Qi93RnhJZ0VFZnlBQUtBSkFLQUlBSUFBdkFUeHFJQVJxTFFBQVFmQW9haTBBQUVId0ttb3RBQUJCOENocUxRQUFJQUZCOENocUxRQUFha0h3S21vdEFBQkI4Q2hxTFFBQUlBbEIvd0Z4UWZBb2FpMEFBR3RCL3dGcVFmLy9BM0ZCL3dGd1FmQXFhaTBBQUFWQkFBczZBQUFnQkVFQmFpSUVJQUF0QURnaUQwa05BQXNnQUMwQVVDRUNDeUFBSUFndEFBQWlBU0FDSUFFZ0FrSC9BWEZMR3lJQk9nQWdRUUFoQWlBQUtBSW9LQUlBSUFBdkFTUnFRUUFnQVVIL0FYRVFHeG9nQ0MwQUFDSUpCRUFEUUNBQUtBSW9LQUlBSUFBdkFTUnFJQUF0QUNBZ0FpQUphMnBCL3dGeGFpQUlLQUlJS0FJQUlBZ3ZBUVJxSUFKcUxRQUFPZ0FBSUFKQkFXb2lBaUFJTFFBQUlnbEpEUUFMQ3lBQUxRQlFJZ2tFUUVFQUlRSURRQ0FBS0FJb0tBSUFJQUF2QVNScUlBQXRBQ0FnQWlBSmEycEIvd0Z4YWlJQklBRXRBQUFnQUNnQ1dDZ0NBQ0FBTHdGVWFpQUNhaTBBQUhNNkFBQWdBa0VCYWlJQ0lBQXRBRkFpQ1VrTkFBc0xDeUFBSUJFNkFDQWdBeUFBS0FJb0tBSUFJQUF2QVNScUlCRVFHaHBCQUNFQkN5QUJDNVVFQVFKL1FRRWdBQ3dBQnlJQklBRkJBVW9iUVFFZ0FDMEFDUnNpQVNBQUxBQVRJZ0lnQVNBQ1NCc2dBU0FBTFFBVkd5SUJJQUFzQUI4aUFpQUJJQUpJR3lBQklBQXRBQ0ViSWdFZ0FDd0FLeUlDSUFFZ0FrZ2JJQUVnQUMwQUxSc2lBU0FBTEFBM0lnSWdBU0FDU0JzZ0FTQUFMUUE1R3lJQklBQXNBRU1pQWlBQklBSklHeUFCSUFBdEFFVWJJZ0VnQUN3QVR5SUNJQUVnQWtnYklBRWdBQzBBVVJzaUFTQUFMQUJiSWdJZ0FTQUNTQnNnQVNBQUxRQmRHeUlCSUFBc0FHY2lBaUFCSUFKSUd5QUJJQUF0QUdrYklnRWdBQ3dBY3lJQ0lBRWdBa2diSUFFZ0FDMEFkUnNpQVNBQUxBQi9JZ0lnQVNBQ1NCc2dBU0FBTFFDQkFSc2lBU0FBTEFDTEFTSUNJQUVnQWtnYklBRWdBQzBBalFFYklnRWdBQ3dBbHdFaUFpQUJJQUpJR3lBQklBQXRBSmtCR3lJQklBQXNBS01CSWdJZ0FTQUNTQnNnQVNBQUxRQ2xBUnNpQVNBQUxBQ3ZBU0lDSUFFZ0FrZ2JJQUVnQUMwQXNRRWJJZ0VnQUN3QXV3RWlBaUFCSUFKSUd5QUJJQUF0QUwwQkd5SUJJQUFzQU1jQklnSWdBU0FDU0JzZ0FTQUFMUURKQVJzaUFTQUFMQURUQVNJQ0lBRWdBa2diSUFFZ0FDMEExUUViSWdFZ0FDd0Ezd0VpQWlBQklBSklHeUFCSUFBdEFPRUJHeUlCSUFBc0FPc0JJZ0lnQVNBQ1NCc2dBU0FBTFFEdEFSc2lBU0FBTEFEM0FTSUNJQUVnQWtnYklBRWdBQzBBK1FFYklnRWdBQ3dBZ3dJaUFpQUJJQUpJR3lBQklBQXRBSVVDR3d2R0JnSUlmd1o5QWtBZ0FpZ0NBQ0lJUVFKMElBQk9EUUFnQWtFQk5nSUVJQUlnQUVFQ2RTSUlOZ0lBSUFCQkRFZ05BQ0FEUW9DQWdQd0ROd0lBUVFJaEJDQURJQWhCQVhZaUJrRUNkR29pQlNBR3NrUVlMVVJVK3lIcFB5QUd0Nk8ySWd5VUVDc2lEVGdDQkNBRklBMDRBZ0FnQ0VFR1NRMEFBMEFnQXlBRVFRSjBJZ1ZxSUF3Z0JMS1VJZzBRS3lJT09BSUFJQU1nQlVFRWNtb2dEUkF5SWcwNEFnQWdBeUFJSUFSclFRSjBhaUlGSUE0NEFnUWdCU0FOT0FJQUlBUkJBbW9pQkNBR1NRMEFDeUFJSUFKQkNHb2dBeEJYQ3dKQUlBSW9BZ1FpQmtFQ2RDQUFUZzBBSUFJZ0FFRUNkU0lHTmdJRUlBQkJDRWdOQUVFQklRUWdBeUFJUVFKMGFpSUZJQVpCQVhZaUI3SkVHQzFFVlBzaDZUOGdCN2VqdGlJTWxCQXJJZzA0QWdBZ0JTQUhRUUowYWlBTlF3QUFBRCtVT0FJQUlBWkJCRWtOQUNBSFFRSWdCMEVDU3h0QkFXc2lCMEVCY1NFS0lBQkJHRThFUUNBSFFYNXhJUXRCQUNFSEEwQWdCU0FFUVFKMGFpQU1JQVN5bENJTkVDdERBQUFBUDVRNEFnQWdCU0FHSUFSclFRSjBhaUFORURKREFBQUFQNVE0QWdBZ0JTQUVRUUZxSWdsQkFuUnFJQXdnQ2JLVUlnMFFLME1BQUFBL2xEZ0NBQ0FGSUFZZ0NXdEJBblJxSUEwUU1rTUFBQUEvbERnQ0FDQUVRUUpxSVFRZ0IwRUNhaUlISUF0SERRQUxDeUFLUlEwQUlBVWdCRUVDZEdvZ0RDQUVzcFFpREJBclF3QUFBRCtVT0FJQUlBVWdCaUFFYTBFQ2RHb2dEQkF5UXdBQUFEK1VPQUlBQ3dKQUlBQkJCVTRFUUNBQUlBSkJDR29nQVJCWElBQWdBU0FERUZZZ0JrRUJkQ0FBUVFGMklnVnRJUWNnQUVFRlJnMEJRUUloQkNBRElBaEJBblJxSVFoQkFDRUNBMEFnQVNBRVFRSjBJZ2xxSWdNZ0F5b0NBQ0lNUXdBQUFEOGdDQ0FHSUFJZ0Iyb2lBbXRCQW5ScUtnSUFreUlOSUF3Z0FTQUFJQVJyUVFKMGFpSURLZ0lBa3lJTWxDQUJJQWxCQkhKcUlna3FBZ0FpRGlBREtnSUVraUlQSUFnZ0FrRUNkR29xQWdBaUVKU1RJaEdUT0FJQUlBa2dEaUFOSUErVUlCQWdESlNTSWd5VE9BSUFJQU1nQXlvQ0FDQVJramdDQUNBRElBTXFBZ1FnREpNNEFnUWdCRUVDYWlJRUlBVkpEUUFMREFFTElBQkJCRWNOQUVFRUlBRWdBeEJXQ3lBQklBRXFBZ0FpRENBQktnSUVJZzJUT0FJRUlBRWdEQ0FOa2pnQ0FBdVVDQUVDZjBHa0pVR2xDVUVFUVFBUURrR2tKVUdpRUVFQUVBQkJwQ1ZCMHhWQkFSQUFRYVFsUWVzVlFRSVFBRUdrSlVHMUZrRURFQUJCcENWQnpoWkJCQkFBUWFRbFFjc1hRUVVRQUVIQUpVSHRERUVFUVFBUURrSEFKVUhkRDBFQUVBQkJ3Q1ZCd0E1QkFSQUFRY0FsUWVVTlFRSVFBRUhBSlVIOEQwRURFQUJCd0NWQjNRNUJCQkFBUWNBbFFZVU9RUVVRQUVIQUpVSEREMEVHRUFCQndDVkJxQTVCQnhBQVFjQWxRY29OUVFnUUFFSEFKVUg5RjBFTUVBQkJ3Q1ZCNUJkQkRSQUFRY0FsUWJJWFFRNFFBRUhBSlVHWkYwRVBFQUJCd0NWQmdCZEJFQkFBUWNBbFFlY1dRUkVRQUVIQUpVR2NGa0VTRUFCQndDVkJneFpCRXhBQVFjQWxRYm9WUVJRUUFFSEFKVUdoRlVFVkVBQkJzUTFCbU5FQVJBQUFBQUFBQUFCQUVBVkIrQXhCbU5FQVJBQUFBQUFBQUJCQUVBVkJrUTFCbU5FQVJBQUFBQUFBQUJoQUVBVkJtdzlCbU5FQVJBQUFBQUFBQUNCQUVBVkIvUTVCbU5FQVJBQUFBQUFBQURCQUVBVkIzQ1ZCeFFsQjVDVkJBVUhtSlVFQ0VCQkJCQkFkSWdCQkFEWUNBRUVFRUIwaUFVRUFOZ0lBUWR3bFFaY0xRWmpSQUVIcEpVRURJQUJCbU5FQVFlMGxRUVFnQVJBRFFRUVFIU0lBUVFRMkFnQkJCQkFkSWdGQkJEWUNBRUhjSlVIMUNVSGcwUUJCOGlWQkJTQUFRZURSQUVIMkpVRUdJQUVRQTBFRUVCMGlBRUVJTmdJQVFRUVFIU0lCUVFnMkFnQkIzQ1ZCclFoQjRORUFRZklsUVFVZ0FFSGcwUUJCOWlWQkJpQUJFQU5CQkJBZElnQkJERFlDQUVFRUVCMGlBVUVNTmdJQVFkd2xRWkFNUWVEUkFFSHlKVUVGSUFCQjRORUFRZllsUVFZZ0FSQURRUVFRSFNJQVFSQTJBZ0JCQkJBZElnRkJFRFlDQUVIY0pVR2JERUdZMFFCQjZTVkJBeUFBUVpqUkFFSHRKVUVFSUFFUUEwRUVFQjBpQUVFVU5nSUFRUVFRSFNJQlFSUTJBZ0JCM0NWQjB3eEI0TkVBUWZJbFFRVWdBRUhnMFFCQjlpVkJCaUFCRUFOQkJCQWRJZ0JCR0RZQ0FFRUVFQjBpQVVFWU5nSUFRZHdsUWVVSlFhUWxRZWtsUVFjZ0FFR2tKVUh0SlVFSUlBRVFBMEVFRUIwaUFFRWNOZ0lBUVFRUUhTSUJRUncyQWdCQjNDVkJuUWhCcENWQjZTVkJCeUFBUWFRbFFlMGxRUWdnQVJBRFFRUVFIU0lBUVNBMkFnQkJCQkFkSWdGQklEWUNBRUhjSlVIRkRFR1kwUUJCNlNWQkF5QUFRWmpSQUVIdEpVRUVJQUVRQTBIY0pSQVBRYnNKUVFGQi9DVkJnQ1pCQ1VFS0VBSkJtZ2xCQWtHRUprSHBKVUVMUVF3UUFrR3lERUVDUVl3bVFaUW1RUTFCRGhBQ1FiY01RUVZCd0NaQitDZEJEMEVRRUFKQnZneEJBMEdBS0VHTUtFRVJRUklRQWtHbEMwRUJRWlFvUWVZbFFSTkJGQkFDUWJBTFFRRkJsQ2hCNWlWQkUwRVZFQUpCMHdwQkEwR1lLRUh0SlVFV1FSY1FBa0hDQ2tFRFFaZ29RZTBsUVJaQkdCQUNRY0RaQUVHZ3l3QW9BZ0EyQWdBUVRrR2M2UUJCck9nQU5nSUFRZFRvQUVFcU5nSUFDMUlCQVg4Z0FDZ0NCQ0VFSUFBb0FnQWlBQ0FCQW45QkFDQUNSUTBBR2lBRVFRaDFJZ0VnQkVFQmNVVU5BQm9nQVNBQ0tBSUFhaWdDQUFzZ0Ftb2dBMEVDSUFSQkFuRWJJQUFvQWdBb0Fod1JCUUFMQ2dBZ0FDQUJRUUFRSUF1WkFnQWdBRVVFUUVFQUR3c0Nmd0pBSUFBRWZ5QUJRZjhBVFEwQkFrQkJuT2tBS0FJQUtBSUFSUVJBSUFGQmdIOXhRWUMvQTBZTkF3d0JDeUFCUWY4UFRRUkFJQUFnQVVFL2NVR0FBWEk2QUFFZ0FDQUJRUVoyUWNBQmNqb0FBRUVDREFRTElBRkJnRUJ4UVlEQUEwY2dBVUdBc0FOUGNVVUVRQ0FBSUFGQlAzRkJnQUZ5T2dBQ0lBQWdBVUVNZGtIZ0FYSTZBQUFnQUNBQlFRWjJRVDl4UVlBQmNqb0FBVUVEREFRTElBRkJnSUFFYTBILy96OU5CRUFnQUNBQlFUOXhRWUFCY2pvQUF5QUFJQUZCRW5aQjhBRnlPZ0FBSUFBZ0FVRUdka0UvY1VHQUFYSTZBQUlnQUNBQlFReDJRVDl4UVlBQmNqb0FBVUVFREFRTEMwR0k2QUJCR1RZQ0FFRi9CVUVCQ3d3QkN5QUFJQUU2QUFCQkFRc0xEQUFnQUNBQklBSkJBQkJHQzd3Q0FBSkFBa0FDUUFKQUFrQUNRQUpBQWtBQ1FBSkFBa0FnQVVFSmF3NFNBQWdKQ2dnSkFRSURCQW9KQ2dvSUNRVUdCd3NnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBQ0FCS0FJQU5nSUFEd3NnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBQ0FCTWdFQU53TUFEd3NnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBQ0FCTXdFQU53TUFEd3NnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBQ0FCTUFBQU53TUFEd3NnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBQ0FCTVFBQU53TUFEd3NnQWlBQ0tBSUFRUWRxUVhoeElnRkJDR28yQWdBZ0FDQUJLd01BT1FNQUR3c2dBQ0FDUVFBUkNBQUxEd3NnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBQ0FCTkFJQU53TUFEd3NnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBQ0FCTlFJQU53TUFEd3NnQWlBQ0tBSUFRUWRxUVhoeElnRkJDR28yQWdBZ0FDQUJLUU1BTndNQUMzSUJBMzhnQUNnQ0FDd0FBRUV3YTBFS1R3UkFRUUFQQ3dOQUlBQW9BZ0FoQTBGL0lRRWdBa0hNbWJQbUFFMEVRRUYvSUFNc0FBQkJNR3NpQVNBQ1FRcHNJZ0pxSUFGQi8vLy8vd2NnQW10S0d5RUJDeUFBSUFOQkFXbzJBZ0FnQVNFQ0lBTXNBQUZCTUd0QkNra05BQXNnQWd1akZBSVJmd0YrSXdCQjBBQnJJZ1lrQUNBR0lBRTJBa3dnQmtFM2FpRVZJQVpCT0dvaEUwRUFJUUVDUUFKQUFrQUNRQU5BSUFGQi8vLy8vd2NnRFd0S0RRRWdBU0FOYWlFTklBWW9Ba3dpQ2lFQkFrQUNRQUpBSUFvdEFBQWlDUVJBQTBBQ1FBSkFJQWxCL3dGeElnZEZCRUFnQVNFSkRBRUxJQWRCSlVjTkFTQUJJUWtEUUNBQkxRQUJRU1ZIRFFFZ0JpQUJRUUpxSWdjMkFrd2dDVUVCYWlFSklBRXRBQUloQ3lBSElRRWdDMEVsUmcwQUN3c2dDU0FLYXlJQlFmLy8vLzhISUExckloWktEUWNnQUFSQUlBQWdDaUFCRUI0TElBRU5Ca0YvSVJKQkFTRUhBa0FnQmlnQ1RDSUJMQUFCUVRCclFRcFBEUUFnQVMwQUFrRWtSdzBBSUFFc0FBRkJNR3NoRWtFQklSUkJBeUVIQ3lBR0lBRWdCMm9pQVRZQ1RFRUFJUTRDUUNBQkxBQUFJZ3hCSUdzaUMwRWZTd1JBSUFFaEJ3d0JDeUFCSVFkQkFTQUxkQ0lJUVluUkJIRkZEUUFEUUNBR0lBRkJBV29pQnpZQ1RDQUlJQTV5SVE0Z0FTd0FBU0lNUVNCcklndEJJRThOQVNBSElRRkJBU0FMZENJSVFZblJCSEVOQUFzTEFrQWdERUVxUmdSQUlBWUNmd0pBSUFjc0FBRkJNR3RCQ2s4TkFDQUdLQUpNSWdFdEFBSkJKRWNOQUNBQkxBQUJRUUowSUFScVFjQUJhMEVLTmdJQUlBRXNBQUZCQTNRZ0EycEJnQU5yS0FJQUlROUJBU0VVSUFGQkEyb01BUXNnRkEwR1FRQWhGRUVBSVE4Z0FBUkFJQUlnQWlnQ0FDSUJRUVJxTmdJQUlBRW9BZ0FoRHdzZ0JpZ0NURUVCYWdzaUFUWUNUQ0FQUVFCT0RRRkJBQ0FQYXlFUElBNUJnTUFBY2lFT0RBRUxJQVpCekFCcUVFUWlEMEVBU0EwSUlBWW9Ba3doQVF0QkFDRUhRWDhoQ0FKL1FRQWdBUzBBQUVFdVJ3MEFHaUFCTFFBQlFTcEdCRUFnQmdKL0FrQWdBU3dBQWtFd2EwRUtUdzBBSUFZb0Frd2lBUzBBQTBFa1J3MEFJQUVzQUFKQkFuUWdCR3BCd0FGclFRbzJBZ0FnQVN3QUFrRURkQ0FEYWtHQUEyc29BZ0FoQ0NBQlFRUnFEQUVMSUJRTkJpQUFCSDhnQWlBQ0tBSUFJZ0ZCQkdvMkFnQWdBU2dDQUFWQkFBc2hDQ0FHS0FKTVFRSnFDeUlCTmdKTUlBaEJmM05CSDNZTUFRc2dCaUFCUVFGcU5nSk1JQVpCekFCcUVFUWhDQ0FHS0FKTUlRRkJBUXNoRUFOQUlBY2hFVUVjSVFrZ0FTd0FBRUg3QUd0QlJra05DU0FHSUFGQkFXb2lERFlDVENBQkxBQUFJUWNnRENFQklBY2dFVUU2YkdwQjc4b0FhaTBBQUNJSFFRRnJRUWhKRFFBTEFrQUNRQ0FIUVJ0SEJFQWdCMFVOQ3lBU1FRQk9CRUFnQkNBU1FRSjBhaUFITmdJQUlBWWdBeUFTUVFOMGFpa0RBRGNEUUF3Q0N5QUFSUTBJSUFaQlFHc2dCeUFDRUVNZ0JpZ0NUQ0VNREFJTElCSkJBRTROQ2d0QkFDRUJJQUJGRFFjTElBNUIvLzk3Y1NJTElBNGdEa0dBd0FCeEd5RUhRUUFoRGtHQUNDRVNJQk1oQ1FKQUFrQUNRQUovQWtBQ1FBSkFBa0FDZndKQUFrQUNRQUpBQWtBQ1FBSkFJQXhCQVdzc0FBQWlBVUZmY1NBQklBRkJEM0ZCQTBZYklBRWdFUnNpQVVIWUFHc09JUVFVRkJRVUZCUVVGQTRVRHdZT0RnNFVCaFFVRkJRQ0JRTVVGQWtVQVJRVUJBQUxBa0FnQVVIQkFHc09CdzRVQ3hRT0RnNEFDeUFCUWRNQVJnMEpEQk1MSUFZcEEwQWhGMEdBQ0F3RkMwRUFJUUVDUUFKQUFrQUNRQUpBQWtBQ1FDQVJRZjhCY1E0SUFBRUNBd1FhQlFZYUN5QUdLQUpBSUEwMkFnQU1HUXNnQmlnQ1FDQU5OZ0lBREJnTElBWW9Ba0FnRGF3M0F3QU1Gd3NnQmlnQ1FDQU5Pd0VBREJZTElBWW9Ba0FnRFRvQUFBd1ZDeUFHS0FKQUlBMDJBZ0FNRkFzZ0JpZ0NRQ0FOckRjREFBd1RDeUFJUVFnZ0NFRUlTeHNoQ0NBSFFRaHlJUWRCK0FBaEFRc2dFeUVLSUFGQklIRWhFU0FHS1FOQUloZFFSUVJBQTBBZ0NrRUJheUlLSUJlblFROXhRWURQQUdvdEFBQWdFWEk2QUFBZ0YwSVBWaUVMSUJkQ0JJZ2hGeUFMRFFBTEN5QUdLUU5BVUEwRElBZEJDSEZGRFFNZ0FVRUVka0dBQ0dvaEVrRUNJUTRNQXdzZ0V5RUJJQVlwQTBBaUYxQkZCRUFEUUNBQlFRRnJJZ0VnRjZkQkIzRkJNSEk2QUFBZ0YwSUhWaUVLSUJkQ0E0Z2hGeUFLRFFBTEN5QUJJUW9nQjBFSWNVVU5BaUFJSUJNZ0Ntc2lBVUVCYWlBQklBaElHeUVJREFJTElBWXBBMEFpRjBJQVV3UkFJQVpDQUNBWGZTSVhOd05BUVFFaERrR0FDQXdCQ3lBSFFZQVFjUVJBUVFFaERrR0JDQXdCQzBHQ0NFR0FDQ0FIUVFGeElnNGJDeUVTSUJjZ0V4QXFJUW9MSUJCQkFDQUlRUUJJR3cwT0lBZEIvLzk3Y1NBSElCQWJJUWNDUUNBR0tRTkFJaGRDQUZJTkFDQUlEUUFnRXlJS0lRbEJBQ0VJREF3TElBZ2dGMUFnRXlBS2Eyb2lBU0FCSUFoSUd5RUlEQXNMQW45Qi8vLy8vd2NnQ0NBSVFRQklHeUlKSWd4QkFFY2hFUUpBQWtBQ1FDQUdLQUpBSWdGQm1CZ2dBUnNpQ2lJSEloQkJBM0ZGRFFBZ0RFVU5BQU5BSUJBdEFBQkZEUUlnREVFQmF5SU1RUUJISVJFZ0VFRUJhaUlRUVFOeFJRMEJJQXdOQUFzTElCRkZEUUVMQWtBZ0VDMEFBRVVOQUNBTVFRUkpEUUFEUUNBUUtBSUFJZ0ZCZjNNZ0FVR0Jnb1FJYTNGQmdJR0NoSGh4RFFFZ0VFRUVhaUVRSUF4QkJHc2lERUVEU3cwQUN3c2dERVVOQUFOQUlCQWdFQzBBQUVVTkFob2dFRUVCYWlFUUlBeEJBV3NpREEwQUN3dEJBQXNpQVNBSGF5QUpJQUViSWdFZ0Ntb2hDU0FJUVFCT0JFQWdDeUVISUFFaENBd0xDeUFMSVFjZ0FTRUlJQWt0QUFBTkRRd0tDeUFJQkVBZ0JpZ0NRQXdDQzBFQUlRRWdBRUVnSUE5QkFDQUhFQjhNQWdzZ0JrRUFOZ0lNSUFZZ0Jpa0RRRDRDQ0NBR0lBWkJDR29pQVRZQ1FFRi9JUWdnQVFzaENVRUFJUUVDUUFOQUlBa29BZ0FpQ2tVTkFRSkFJQVpCQkdvZ0NoQkJJZ3RCQUVnaUNnMEFJQXNnQ0NBQmEwc05BQ0FKUVFScUlRa2dDQ0FCSUF0cUlnRkxEUUVNQWdzTElBb05EUXRCUFNFSklBRkJBRWdOQ3lBQVFTQWdEeUFCSUFjUUh5QUJSUVJBUVFBaEFRd0JDMEVBSVFnZ0JpZ0NRQ0VKQTBBZ0NTZ0NBQ0lLUlEwQklBWkJCR29nQ2hCQklnb2dDR29pQ0NBQlN3MEJJQUFnQmtFRWFpQUtFQjRnQ1VFRWFpRUpJQUVnQ0VzTkFBc0xJQUJCSUNBUElBRWdCMEdBd0FCekVCOGdEeUFCSUFFZ0QwZ2JJUUVNQ0FzZ0VFRUFJQWhCQUVnYkRRaEJQU0VKSUFBZ0Jpc0RRQ0FQSUFnZ0J5QUJJQVVSRWdBaUFVRUFUZzBIREFrTElBWWdCaWtEUUR3QU4wRUJJUWdnRlNFS0lBc2hCd3dFQ3lBR0lBRkJBV29pQnpZQ1RDQUJMUUFCSVFrZ0J5RUJEQUFMQUFzZ0FBMEhJQlJGRFFKQkFTRUJBMEFnQkNBQlFRSjBhaWdDQUNJQUJFQWdBeUFCUVFOMGFpQUFJQUlRUTBFQklRMGdBVUVCYWlJQlFRcEhEUUVNQ1FzTFFRRWhEU0FCUVFwUERRY0RRQ0FFSUFGQkFuUnFLQUlBRFFFZ0FVRUJhaUlCUVFwSERRQUxEQWNMUVJ3aENRd0VDeUFKSUFwckloRWdDQ0FJSUJGSUd5SUxRZi8vLy84SElBNXJTZzBDUVQwaENTQUxJQTVxSWdnZ0R5QUlJQTlLR3lJQklCWktEUU1nQUVFZ0lBRWdDQ0FIRUI4Z0FDQVNJQTRRSGlBQVFUQWdBU0FJSUFkQmdJQUVjeEFmSUFCQk1DQUxJQkZCQUJBZklBQWdDaUFSRUI0Z0FFRWdJQUVnQ0NBSFFZREFBSE1RSHd3QkN3dEJBQ0VOREFNTFFUMGhDUXRCaU9nQUlBazJBZ0FMUVg4aERRc2dCa0hRQUdva0FDQU5DN0lDQVFOL0l3QkIwQUZySWdRa0FDQUVJQUkyQXN3QklBUkJvQUZxSWdKQkFFRW9FQnNhSUFRZ0JDZ0N6QUUyQXNnQkFrQkJBQ0FCSUFSQnlBRnFJQVJCMEFCcUlBSWdBeEJGUVFCSURRQWdBQ2dDVEVFQVRpRUZJQUFvQWdBaEFpQUFLQUpJUVFCTUJFQWdBQ0FDUVY5eE5nSUFDd0ovQWtBQ1FDQUFLQUl3UlFSQUlBQkIwQUEyQWpBZ0FFRUFOZ0ljSUFCQ0FEY0RFQ0FBS0FJc0lRWWdBQ0FFTmdJc0RBRUxJQUFvQWhBTkFRdEJmeUFBRUVnTkFSb0xJQUFnQVNBRVFjZ0JhaUFFUWRBQWFpQUVRYUFCYWlBREVFVUxJUUVnQmdSL0lBQkJBRUVBSUFBb0FpUVJBd0FhSUFCQkFEWUNNQ0FBSUFZMkFpd2dBRUVBTmdJY0lBQW9BaFFhSUFCQ0FEY0RFRUVBQlNBQkN4b2dBQ0FBS0FJQUlBSkJJSEZ5TmdJQUlBVkZEUUFMSUFSQjBBRnFKQUFMZmdJQmZ3RitJQUM5SWdOQ05JaW5RZjhQY1NJQ1FmOFBSd1I4SUFKRkJFQWdBU0FBUkFBQUFBQUFBQUFBWVFSL1FRQUZJQUJFQUFBQUFBQUE4RU9pSUFFUVJ5RUFJQUVvQWdCQlFHb0xOZ0lBSUFBUEN5QUJJQUpCL2dkck5nSUFJQU5DLy8vLy8vLy8vNGVBZjROQ2dJQ0FnSUNBZ1BBL2hMOEZJQUFMQzFrQkFYOGdBQ0FBS0FKSUlnRkJBV3NnQVhJMkFrZ2dBQ2dDQUNJQlFRaHhCRUFnQUNBQlFTQnlOZ0lBUVg4UEN5QUFRZ0EzQWdRZ0FDQUFLQUlzSWdFMkFod2dBQ0FCTmdJVUlBQWdBU0FBS0FJd2FqWUNFRUVBQ3dNQUFRc2xBUUYvSXdCQkVHc2lBeVFBSUFNZ0FqWUNEQ0FBSUFFZ0FrRWZFRVlnQTBFUWFpUUFDNVFEQWdOL0Ezd2pBRUVRYXlJREpBQUNRQ0FBdkNJRVFmLy8vLzhIY1NJQ1FkcWZwTzRFVFFSQUlBRWdBTHNpQmlBR1JJUEl5VzB3WCtRL29rUUFBQUFBQUFBNFE2QkVBQUFBQUFBQU9NT2dJZ1ZFQUFBQVVQc2grYitpb0NBRlJHTmlHbUcwRUZHK29xQWlCemtEQUNBSFJBQUFBR0Q3SWVtL1l5RUVBbjhnQlpsRUFBQUFBQUFBNEVGakJFQWdCYW9NQVF0QmdJQ0FnSGdMSVFJZ0JBUkFJQUVnQmlBRlJBQUFBQUFBQVBDL29DSUZSQUFBQUZEN0lmbS9vcUFnQlVSallocGh0QkJSdnFLZ09RTUFJQUpCQVdzaEFnd0NDeUFIUkFBQUFHRDdJZWsvWkVVTkFTQUJJQVlnQlVRQUFBQUFBQUR3UDZBaUJVUUFBQUJRK3lINXY2S2dJQVZFWTJJYVliUVFVYjZpb0RrREFDQUNRUUZxSVFJTUFRc2dBa0dBZ0lEOEIwOEVRQ0FCSUFBZ0FKTzdPUU1BUVFBaEFnd0JDeUFESUFJZ0FrRVhka0dXQVdzaUFrRVhkR3UrdXprRENDQURRUWhxSUFNZ0FrRUJRUUFRVFNFQ0lBTXJBd0FoQlNBRVFRQklCRUFnQVNBRm1qa0RBRUVBSUFKcklRSU1BUXNnQVNBRk9RTUFDeUFEUVJCcUpBQWdBZ3ZaQ2dNRWZBVi9BWDRqQUVFd2F5SUhKQUFDUUFKQUFrQWdBTDBpQzBJZ2lLY2lCa0gvLy8vL0IzRWlDRUg2MUwyQUJFMEVRQ0FHUWYvL1AzRkIrOE1rUmcwQklBaEIvTEtMZ0FSTkJFQWdDMElBV1FSQUlBRWdBRVFBQUVCVSt5SDV2NkFpQUVReFkySWFZYlRRdmFBaUFqa0RBQ0FCSUFBZ0FxRkVNV05pR21HMDBMMmdPUU1JUVFFaEJnd0ZDeUFCSUFCRUFBQkFWUHNoK1QrZ0lnQkVNV05pR21HMDBEMmdJZ0k1QXdBZ0FTQUFJQUtoUkRGallocGh0TkE5b0RrRENFRi9JUVlNQkFzZ0MwSUFXUVJBSUFFZ0FFUUFBRUJVK3lFSndLQWlBRVF4WTJJYVliVGd2YUFpQWprREFDQUJJQUFnQXFGRU1XTmlHbUcwNEwyZ09RTUlRUUloQmd3RUN5QUJJQUJFQUFCQVZQc2hDVUNnSWdCRU1XTmlHbUcwNEQyZ0lnSTVBd0FnQVNBQUlBS2hSREZqWWhwaHRPQTlvRGtEQ0VGK0lRWU1Bd3NnQ0VHN2pQR0FCRTBFUUNBSVFiejcxNEFFVFFSQUlBaEIvTExMZ0FSR0RRSWdDMElBV1FSQUlBRWdBRVFBQURCL2ZOa1N3S0FpQUVUS2xKT25rUTdwdmFBaUFqa0RBQ0FCSUFBZ0FxRkV5cFNUcDVFTzZiMmdPUU1JUVFNaEJnd0ZDeUFCSUFCRUFBQXdmM3paRWtDZ0lnQkV5cFNUcDVFTzZUMmdJZ0k1QXdBZ0FTQUFJQUtoUk1xVWs2ZVJEdWs5b0RrRENFRjlJUVlNQkFzZ0NFSDd3K1NBQkVZTkFTQUxRZ0JaQkVBZ0FTQUFSQUFBUUZUN0lSbkFvQ0lBUkRGallocGh0UEM5b0NJQ09RTUFJQUVnQUNBQ29VUXhZMklhWWJUd3ZhQTVBd2hCQkNFR0RBUUxJQUVnQUVRQUFFQlUreUVaUUtBaUFFUXhZMklhWWJUd1BhQWlBamtEQUNBQklBQWdBcUZFTVdOaUdtRzA4RDJnT1FNSVFYd2hCZ3dEQ3lBSVFmckQ1SWtFU3cwQkN5QUFJQUJFZzhqSmJUQmY1RCtpUkFBQUFBQUFBRGhEb0VRQUFBQUFBQUE0dzZBaUEwUUFBRUJVK3lINXY2S2dJZ0lnQTBReFkySWFZYlRRUGFJaUJLRWlCVVFZTFVSVSt5SHB2Mk1oQ1FKL0lBT1pSQUFBQUFBQUFPQkJZd1JBSUFPcURBRUxRWUNBZ0lCNEN5RUdBa0FnQ1FSQUlBWkJBV3NoQmlBRFJBQUFBQUFBQVBDL29DSURSREZqWWhwaHROQTlvaUVFSUFBZ0EwUUFBRUJVK3lINXY2S2dJUUlNQVFzZ0JVUVlMVVJVK3lIcFAyUkZEUUFnQmtFQmFpRUdJQU5FQUFBQUFBQUE4RCtnSWdORU1XTmlHbUcwMEQyaUlRUWdBQ0FEUkFBQVFGVDdJZm0vb3FBaEFnc2dBU0FDSUFTaElnQTVBd0FDUUNBSVFSUjJJZ2tnQUwxQ05JaW5RZjhQY1d0QkVVZ05BQ0FCSUFJZ0EwUUFBR0FhWWJUUVBhSWlBS0VpQlNBRFJITndBeTZLR2FNN29pQUNJQVdoSUFDaG9TSUVvU0lBT1FNQUlBa2dBTDFDTklpblFmOFBjV3RCTWtnRVFDQUZJUUlNQVFzZ0FTQUZJQU5FQUFBQUxvb1pvenVpSWdDaElnSWdBMFRCU1NBbG1vTjdPYUlnQlNBQ29TQUFvYUVpQktFaUFEa0RBQXNnQVNBQ0lBQ2hJQVNoT1FNSURBRUxJQWhCZ0lEQS93ZFBCRUFnQVNBQUlBQ2hJZ0E1QXdBZ0FTQUFPUU1JUVFBaEJnd0JDeUFMUXYvLy8vLy8vLzhIZzBLQWdJQ0FnSUNBc01FQWhMOGhBRUVBSVFaQkFTRUpBMEFnQjBFUWFpQUdRUU4wYWdKL0lBQ1pSQUFBQUFBQUFPQkJZd1JBSUFDcURBRUxRWUNBZ0lCNEM3Y2lBamtEQUNBQUlBS2hSQUFBQUFBQUFIQkJvaUVBUVFFaEJpQUpRUUZ4SVFwQkFDRUpJQW9OQUFzZ0J5QUFPUU1nQWtBZ0FFUUFBQUFBQUFBQUFHSUVRRUVDSVFZTUFRdEJBU0VKQTBBZ0NTSUdRUUZySVFrZ0IwRVFhaUFHUVFOMGFpc0RBRVFBQUFBQUFBQUFBR0VOQUFzTElBZEJFR29nQnlBSVFSUjJRWllJYXlBR1FRRnFRUUVRVFNFR0lBY3JBd0FoQUNBTFFnQlRCRUFnQVNBQW1qa0RBQ0FCSUFjckF3aWFPUU1JUVFBZ0Jtc2hCZ3dCQ3lBQklBQTVBd0FnQVNBSEt3TUlPUU1JQ3lBSFFUQnFKQUFnQmd1cEVRSURmQkIvSXdCQnNBUnJJZ2trQUNBQ0lBSkJBMnRCR0cwaUNFRUFJQWhCQUVvYkloRkJhR3hxSVF3Z0JFRUNkRUdBTldvb0FnQWlEU0FEUVFGcklndHFRUUJPQkVBZ0F5QU5haUVJSUJFZ0Myc2hBZ05BSUFsQndBSnFJQXBCQTNScUlBSkJBRWdFZkVRQUFBQUFBQUFBQUFVZ0FrRUNkRUdRTldvb0FnQzNDemtEQUNBQ1FRRnFJUUlnQ2tFQmFpSUtJQWhIRFFBTEN5QU1RUmhySVE4Z0RVRUFJQTFCQUVvYklRcEJBQ0VJQTBCRUFBQUFBQUFBQUFBaEJTQURRUUJLQkVBZ0NDQUxhaUVPUVFBaEFnTkFJQUFnQWtFRGRHb3JBd0FnQ1VIQUFtb2dEaUFDYTBFRGRHb3JBd0NpSUFXZ0lRVWdBa0VCYWlJQ0lBTkhEUUFMQ3lBSklBaEJBM1JxSUFVNUF3QWdDQ0FLUmlFQ0lBaEJBV29oQ0NBQ1JRMEFDMEV2SUF4cklSUkJNQ0FNYXlFU0lBeEJHV3NoRlNBTklRZ0NRQU5BSUFrZ0NFRURkR29yQXdBaEJVRUFJUUlnQ0NFS0lBaEJBRXdpRUVVRVFBTkFJQWxCNEFOcUlBSkJBblJxQW44Q2Z5QUZSQUFBQUFBQUFIQStvaUlHbVVRQUFBQUFBQURnUVdNRVFDQUdxZ3dCQzBHQWdJQ0FlQXUzSWdaRUFBQUFBQUFBY01HaUlBV2dJZ1daUkFBQUFBQUFBT0JCWXdSQUlBV3FEQUVMUVlDQWdJQjRDellDQUNBSklBcEJBV3NpQ2tFRGRHb3JBd0FnQnFBaEJTQUNRUUZxSWdJZ0NFY05BQXNMQW44Z0JTQVBFRE1pQlNBRlJBQUFBQUFBQU1BL29weEVBQUFBQUFBQUlNQ2lvQ0lGbVVRQUFBQUFBQURnUVdNRVFDQUZxZ3dCQzBHQWdJQ0FlQXNoRGlBRklBNjNvU0VGQWtBQ1FBSkFBbjhnRDBFQVRDSVdSUVJBSUFoQkFuUWdDV29pQWlBQ0tBTGNBeUlDSUFJZ0VuVWlBaUFTZEdzaUNqWUMzQU1nQWlBT2FpRU9JQW9nRkhVTUFRc2dEdzBCSUFoQkFuUWdDV29vQXR3RFFSZDFDeUlMUVFCTURRSU1BUXRCQWlFTElBVkVBQUFBQUFBQTREOW1EUUJCQUNFTERBRUxRUUFoQWtFQUlRb2dFRVVFUUFOQUlBbEI0QU5xSUFKQkFuUnFJaGNvQWdBaEVFSC8vLzhISVJNQ2Z3SkFJQW9OQUVHQWdJQUlJUk1nRUEwQVFRQU1BUXNnRnlBVElCQnJOZ0lBUVFFTElRb2dBa0VCYWlJQ0lBaEhEUUFMQ3dKQUlCWU5BRUgvLy84RElRSUNRQUpBSUJVT0FnRUFBZ3RCLy8vL0FTRUNDeUFJUVFKMElBbHFJaEFnRUNnQzNBTWdBbkUyQXR3REN5QU9RUUZxSVE0Z0MwRUNSdzBBUkFBQUFBQUFBUEEvSUFXaElRVkJBaUVMSUFwRkRRQWdCVVFBQUFBQUFBRHdQeUFQRURPaElRVUxJQVZFQUFBQUFBQUFBQUJoQkVCQkFDRUtJQWdoQWdKQUlBZ2dEVXdOQUFOQUlBbEI0QU5xSUFKQkFXc2lBa0VDZEdvb0FnQWdDbkloQ2lBQ0lBMUtEUUFMSUFwRkRRQWdEeUVNQTBBZ0RFRVlheUVNSUFsQjRBTnFJQWhCQVdzaUNFRUNkR29vQWdCRkRRQUxEQU1MUVFFaEFnTkFJQUlpQ2tFQmFpRUNJQWxCNEFOcUlBMGdDbXRCQW5ScUtBSUFSUTBBQ3lBSUlBcHFJUW9EUUNBSlFjQUNhaUFESUFocUlndEJBM1JxSUFoQkFXb2lDQ0FSYWtFQ2RFR1FOV29vQWdDM09RTUFRUUFoQWtRQUFBQUFBQUFBQUNFRklBTkJBRW9FUUFOQUlBQWdBa0VEZEdvckF3QWdDVUhBQW1vZ0N5QUNhMEVEZEdvckF3Q2lJQVdnSVFVZ0FrRUJhaUlDSUFOSERRQUxDeUFKSUFoQkEzUnFJQVU1QXdBZ0NDQUtTQTBBQ3lBS0lRZ01BUXNMQWtBZ0JVRVlJQXhyRURNaUJVUUFBQUFBQUFCd1FXWUVRQ0FKUWVBRGFpQUlRUUowYWdKL0FuOGdCVVFBQUFBQUFBQndQcUlpQnBsRUFBQUFBQUFBNEVGakJFQWdCcW9NQVF0QmdJQ0FnSGdMSWdLM1JBQUFBQUFBQUhEQm9pQUZvQ0lGbVVRQUFBQUFBQURnUVdNRVFDQUZxZ3dCQzBHQWdJQ0FlQXMyQWdBZ0NFRUJhaUVJREFFTEFuOGdCWmxFQUFBQUFBQUE0RUZqQkVBZ0Jhb01BUXRCZ0lDQWdIZ0xJUUlnRHlFTUN5QUpRZUFEYWlBSVFRSjBhaUFDTmdJQUMwUUFBQUFBQUFEd1B5QU1FRE1oQlFKQUlBaEJBRWdOQUNBSUlRTURRQ0FKSUFNaUFFRURkR29nQlNBSlFlQURhaUFEUVFKMGFpZ0NBTGVpT1FNQUlBTkJBV3NoQXlBRlJBQUFBQUFBQUhBK29pRUZJQUFOQUFzZ0NFRUFTQTBBSUFnaEFnTkFJQWdnQWlJQWF5RURSQUFBQUFBQUFBQUFJUVZCQUNFQ0EwQUNRQ0FDUVFOMFFlREtBR29yQXdBZ0NTQUFJQUpxUVFOMGFpc0RBS0lnQmFBaEJTQUNJQTFPRFFBZ0FpQURTU0VNSUFKQkFXb2hBaUFNRFFFTEN5QUpRYUFCYWlBRFFRTjBhaUFGT1FNQUlBQkJBV3NoQWlBQVFRQktEUUFMQ3dKQUFrQUNRQUpBQWtBZ0JBNEVBUUlDQUFRTFJBQUFBQUFBQUFBQUlRWUNRQ0FJUVFCTURRQWdDVUdnQVdvZ0NFRURkR29yQXdBaEJTQUlJUUlEUUNBSlFhQUJhaUlESUFKQkEzUnFJQVVnQXlBQ1FRRnJJZ0JCQTNScUlnTXJBd0FpQnlBSElBV2dJZ1dob0RrREFDQURJQVU1QXdBZ0FrRUJTeUVESUFBaEFpQUREUUFMSUFoQkFrZ05BQ0FKUWFBQmFpQUlRUU4wYWlzREFDRUZJQWdoQWdOQUlBbEJvQUZxSWdNZ0FrRURkR29nQlNBRElBSkJBV3NpQUVFRGRHb2lBeXNEQUNJR0lBWWdCYUFpQmFHZ09RTUFJQU1nQlRrREFDQUNRUUpMSVFNZ0FDRUNJQU1OQUF0RUFBQUFBQUFBQUFBaEJpQUlRUUZNRFFBRFFDQUdJQWxCb0FGcUlBaEJBM1JxS3dNQW9DRUdJQWhCQWtvaEFDQUlRUUZySVFnZ0FBMEFDd3NnQ1NzRG9BRWhCU0FMRFFJZ0FTQUZPUU1BSUFrckE2Z0JJUVVnQVNBR09RTVFJQUVnQlRrRENBd0RDMFFBQUFBQUFBQUFBQ0VGSUFoQkFFNEVRQU5BSUFnaUFFRUJheUVJSUFVZ0NVR2dBV29nQUVFRGRHb3JBd0NnSVFVZ0FBMEFDd3NnQVNBRm1pQUZJQXNiT1FNQURBSUxSQUFBQUFBQUFBQUFJUVVnQ0VFQVRnUkFJQWdoQXdOQUlBTWlBRUVCYXlFRElBVWdDVUdnQVdvZ0FFRURkR29yQXdDZ0lRVWdBQTBBQ3dzZ0FTQUZtaUFGSUFzYk9RTUFJQWtyQTZBQklBV2hJUVZCQVNFQ0lBaEJBRW9FUUFOQUlBVWdDVUdnQVdvZ0FrRURkR29yQXdDZ0lRVWdBaUFJUnlFQUlBSkJBV29oQWlBQURRQUxDeUFCSUFXYUlBVWdDeHM1QXdnTUFRc2dBU0FGbWprREFDQUpLd09vQVNFRklBRWdCcG81QXhBZ0FTQUZtamtEQ0FzZ0NVR3dCR29rQUNBT1FRZHhDOTREQUVIRTBBQkI2QXdRR1VIUTBBQkJ2UXBCQVVFQlFRQVFHRUhjMEFCQjRBbEJBVUdBZjBIL0FCQUVRZlRRQUVIWkNVRUJRWUIvUWY4QUVBUkI2TkFBUWRjSlFRRkJBRUgvQVJBRVFZRFJBRUdIQ1VFQ1FZQ0Fma0gvL3dFUUJFR00wUUJCL2doQkFrRUFRZi8vQXhBRVFaalJBRUdXQ1VFRVFZQ0FnSUI0UWYvLy8vOEhFQVJCcE5FQVFZMEpRUVJCQUVGL0VBUkJzTkVBUWNNTFFRUkJnSUNBZ0hoQi8vLy8vd2NRQkVHODBRQkJ1Z3RCQkVFQVFYOFFCRUhJMFFCQnN3bENnSUNBZ0lDQWdJQ0FmMEwvLy8vLy8vLy8vLzhBRUZoQjFORUFRYklKUWdCQ2Z4QllRZURSQUVHZkNVRUVFQTFCN05FQVFhc01RUWdRRFVIZ0owSGlDeEFNUWNndlFmWVRFQXhCb0RCQkJFSElDeEFJUWZ3d1FRSkI3Z3NRQ0VIWU1VRUVRZjBMRUFoQjZDWkI1QW9RRjBHNEprRUFRYkVURUFGQmtESkJBRUdYRkJBQlFiZ3lRUUZCenhNUUFVSGdNa0VDUWNFUUVBRkJpRE5CQTBIZ0VCQUJRYkF6UVFSQmlCRVFBVUhZTTBFRlFhVVJFQUZCZ0RSQkJFRzhGQkFCUWFnMFFRVkIyaFFRQVVHUU1rRUFRWXNTRUFGQnVESkJBVUhxRVJBQlFlQXlRUUpCelJJUUFVR0lNMEVEUWFzU0VBRkJzRE5CQkVHUUV4QUJRZGd6UVFWQjdoSVFBVUhRTkVFR1Fjc1JFQUZCK0RSQkIwR0JGUkFCQ3c4QUlBRWdBQ2dDQUdvZ0FqWUNBQXVWQkFFV2Z5QUFMQUNEQWlJQ0lBQXNBUGNCSWdNZ0FDd0E2d0VpQkNBQUxBRGZBU0lGSUFBc0FOTUJJZ1lnQUN3QXh3RWlCeUFBTEFDN0FTSUlJQUFzQUs4Qklna2dBQ3dBb3dFaUNpQUFMQUNYQVNJTElBQXNBSXNCSWd3Z0FDd0FmeUlOSUFBc0FITWlEaUFBTEFCbklnOGdBQ3dBV3lJUUlBQXNBRThpRVNBQUxBQkRJaElnQUN3QU55SVRJQUFzQUNzaUZDQUFMQUFmSWhVZ0FDd0FFeUlXSUFBc0FBY2lBVUVCSUFGQkFVb2JRUUVnQUMwQUNSc2lBU0FCSUJaSUd5QUJJQUF0QUJVYklnRWdBU0FWU0JzZ0FTQUFMUUFoR3lJQklBRWdGRWdiSUFFZ0FDMEFMUnNpQVNBQklCTklHeUFCSUFBdEFEa2JJZ0VnQVNBU1NCc2dBU0FBTFFCRkd5SUJJQUVnRVVnYklBRWdBQzBBVVJzaUFTQUJJQkJJR3lBQklBQXRBRjBiSWdFZ0FTQVBTQnNnQVNBQUxRQnBHeUlCSUFFZ0RrZ2JJQUVnQUMwQWRSc2lBU0FCSUExSUd5QUJJQUF0QUlFQkd5SUJJQUVnREVnYklBRWdBQzBBalFFYklnRWdBU0FMU0JzZ0FTQUFMUUNaQVJzaUFTQUJJQXBJR3lBQklBQXRBS1VCR3lJQklBRWdDVWdiSUFFZ0FDMEFzUUViSWdFZ0FTQUlTQnNnQVNBQUxRQzlBUnNpQVNBQklBZElHeUFCSUFBdEFNa0JHeUlCSUFFZ0JrZ2JJQUVnQUMwQTFRRWJJZ0VnQVNBRlNCc2dBU0FBTFFEaEFSc2lBU0FCSUFSSUd5QUJJQUF0QU8wQkd5SUJJQUVnQTBnYklBRWdBQzBBK1FFYklnRWdBU0FDU0JzZ0FTQUFMUUNGQWhzTDVCOENCMzhEZkNNQVFTQnJJZ2drQUFKL0FrQWdBQzBBUkVVRVFFR01BU0VIREFFTFFRUWhCU0FBS0FKSUlnZEJCRWdFUUVFQ0lRVkJBUXdDQzBFQUlBZEJEMGtOQVJvTElBZEJCVzVCQVhRaEJVRUFDeUVESUFVZ0Iyb2hCUUpBUWVUZEFDMEFBRUVCY1EwQVFlVGRBQkFqUlEwQVFkemJBQkFtUVlnQ0VCb2FRZVRkQUJBaUMwSGMyd0FRUENBRmFrRUJheUVFQWtCQjJOc0FMUUFBUVFGeERRQkIyTnNBRUNORkRRQkIwTmtBRUNaQmlBSVFHaHBCMk5zQUVDSUxJQVJCME5rQUVEeHRJUWtDUUNBRlFZRUNUZ1JBUVFBaEJFSEEyUUFvQWdBaUFFVU5BU0FJUVlBQ05nSU1JQWdDZjBFQ0lBTU5BQnBCQkNBSFFROUpEUUFhSUFkQkJXNUJBWFFMTmdJSUlBZ2dCellDQkNBSUlBVTJBZ0FnQUVIY0l5QUlFQndNQVFzZ0FDZ0NQQ0FGYWlFRElBRUVRQ0FDS0FJQUlRUWdBQ0FETmdKWUlBQWdBU0FFYWpZQ1ZBc2dBaUFESUFJb0FnQnFRUWRxUVFodFFRTjBJZ00yQWdBZ0FDMEFUQVJBSUFJZ0FDZ0NEQ0lFUVFOMElBRUVmeUFBSUFSQkFYUTJBcGdCSUFBZ0FTQURhallDbEFFZ0FpZ0NBQVVnQXd0cVFRZHFRUWh0UVFOMElnTTJBZ0FDZnlBQUtBSU1RUUp0dDU5RUFBQUFBQUFBQ0VDZ0lncVpSQUFBQUFBQUFPQkJZd1JBSUFxcURBRUxRWUNBZ0lCNEN5RUVJQUlnQVFSL0lBQWdCRFlDb0FFZ0FDQUJJQU5xTmdLY0FTQUNLQUlBQlNBREN5QUVRUUowYWtFSGFrRUliVUVEZENJRE5nSUFJQUFvQWd4QkFtMGhCQ0FDSUFFRWZ5QUFJQVEyQXFnQklBQWdBU0FEYWpZQ3BBRWdBaWdDQUFVZ0F3c2dCRUVDZEdwQkIycEJDRzFCQTNRaUF6WUNBQ0FBS0FJTUlRUWdBaUFCQkg4Z0FDQUVOZ0swQVNBQUlBRWdBMm8yQXJBQklBSW9BZ0FGSUFNTElBUkJBblJxUVFkcVFRaHRRUU4wSWdNMkFnQWdBQ2dDRENJRVFZQUJhaUFFSUFBdEFFNGlCQnNoQmlBQ0lBRUVmeUFBSUFZMkFyd0JJQUFnQVNBRGFqWUN1QUVnQWlnQ0FBVWdBd3NnQmtFQ2RHcEJCMnBCQ0cxQkEzUWlBellDQUNBQUtBSU1JZ1pCQTNRZ0JpQUVHeUVHSUFJZ0FRUi9JQUFnQmpZQ3hBRWdBQ0FCSUFOcU5nTEFBU0FDS0FJQUJTQURDeUFHUVFKMGFrRUhha0VJYlVFRGRDSUdOZ0lBSUFBb0Fnd2hBd0pBSUFRRVFDQURRUU4wSVFRZ0FDZ0NGQ0VEREFFTElBQW9BaFFoQkFzZ0F5QUViQ0VESUFJZ0FRUi9JQUFnQXpZQ3pBRWdBQ0FCSUFacU5nTElBU0FDSUFNZ0FpZ0NBR3BCQjJwQkNHMUJBM1FpQXpZQ0FDQUFJQWRCQVdvMkF0Z0JJQUFnQVNBRGFqWUMxQUVnQWlnQ0FBVWdBeUFHYWtFSGFrRUliVUVEZEFzZ0IycEJDR3BCQ0cxQkEzUWlBellDQUFKQUlBQXRBRVFFUUNBQUtBSklJZ05Cd1FCT0JFQkJBQ0VFUWNEWkFDZ0NBQ0lBUlEwRUlBaEJ3QUEyQWhRZ0NDQUROZ0lRSUFCQmlSOGdDRUVRYWhBY0RBUUxBa0JCNU4wQUxRQUFRUUZ4RFFCQjVOMEFFQ05GRFFCQjNOc0FFQ1pCaUFJUUdocEI1TjBBRUNJTEFuOUI1ZHNBTFFBQUJIOUI0dHNBTEFBQVFlVGJBQ3dBQUd3aUEwRUFJQU5CQUVvYkJVRUFDeUVEUWZIYkFDMEFBQVJBUWU3YkFDd0FBRUh3MndBc0FBQnNJZ1FnQXlBRElBUklHeUVEQzBIOTJ3QXRBQUFFUUVINjJ3QXNBQUJCL05zQUxBQUFiQ0lFSUFNZ0F5QUVTQnNoQXd0Qmlkd0FMUUFBQkVCQmh0d0FMQUFBUVlqY0FDd0FBR3dpQkNBRElBTWdCRWdiSVFNTFFaWGNBQzBBQUFSQVFaTGNBQ3dBQUVHVTNBQXNBQUJzSWdRZ0F5QURJQVJJR3lFREMwR2gzQUF0QUFBRVFFR2UzQUFzQUFCQm9Od0FMQUFBYkNJRUlBTWdBeUFFU0JzaEF3dEJyZHdBTFFBQUJFQkJxdHdBTEFBQVFhemNBQ3dBQUd3aUJDQURJQU1nQkVnYklRTUxRYm5jQUMwQUFBUkFRYmJjQUN3QUFFRzQzQUFzQUFCc0lnUWdBeUFESUFSSUd5RURDMEhGM0FBdEFBQUVRRUhDM0FBc0FBQkJ4TndBTEFBQWJDSUVJQU1nQXlBRVNCc2hBd3RCMGR3QUxRQUFCRUJCenR3QUxBQUFRZERjQUN3QUFHd2lCQ0FESUFNZ0JFZ2JJUU1MUWQzY0FDMEFBQVJBUWRyY0FDd0FBRUhjM0FBc0FBQnNJZ1FnQXlBRElBUklHeUVEQzBIcDNBQXRBQUFFUUVIbTNBQXNBQUJCNk53QUxBQUFiQ0lFSUFNZ0F5QUVTQnNoQXd0Qjlkd0FMUUFBQkVCQjh0d0FMQUFBUWZUY0FDd0FBR3dpQkNBRElBTWdCRWdiSVFNTFFZSGRBQzBBQUFSQVFmN2NBQ3dBQUVHQTNRQXNBQUJzSWdRZ0F5QURJQVJJR3lFREMwR04zUUF0QUFBRVFFR0szUUFzQUFCQmpOMEFMQUFBYkNJRUlBTWdBeUFFU0JzaEF3dEJtZDBBTFFBQUJFQkJsdDBBTEFBQVFaamRBQ3dBQUd3aUJDQURJQU1nQkVnYklRTUxRYVhkQUMwQUFBUkFRYUxkQUN3QUFFR2szUUFzQUFCc0lnUWdBeUFESUFSSUd5RURDMEd4M1FBdEFBQUVRRUd1M1FBc0FBQkJzTjBBTEFBQWJDSUVJQU1nQXlBRVNCc2hBd3RCdmQwQUxRQUFCRUJCdXQwQUxBQUFRYnpkQUN3QUFHd2lCQ0FESUFNZ0JFZ2JJUU1MUWNuZEFDMEFBQVJBUWNiZEFDd0FBRUhJM1FBc0FBQnNJZ1FnQXlBRElBUklHeUVEQzBIVjNRQXRBQUFFUUVIUzNRQXNBQUJCMU4wQUxBQUFiQ0lFSUFNZ0F5QUVTQnNoQXdzZ0EwSGgzUUF0QUFCRkRRQWFRZDdkQUN3QUFFSGczUUFzQUFCc0lnUWdBeUFESUFSSUd3c2dDV3doQXlBQUtBSU1JUVFnQVFSQUlBSW9BZ0FoQmlBQUlBUTJBcUFFSUFBZ0F6WUNuQVFnQUNBQklBWnFOZ0tZQkFzZ0FpQUNLQUlBSUFNZ0JHeHFRUWRxUVFodFFRTjBJZ00yQWdBZ0JVRUJkQ0VGSUFJZ0FRUi9JQUFnQlRZQ3FBUWdBQ0FCSUFOcU5nS2tCQ0FDS0FJQUJTQURDeUFGYWtFSGFrRUliVUVEZERZQ0FBSkFRZVRkQUMwQUFFRUJjUTBBUWVUZEFCQWpSUTBBUWR6YkFCQW1RWWdDRUJvYVFlVGRBQkFpQzBIYzJ3QVFVRUVGZENFRElBRUVRQ0FDS0FJQUlRVWdBQ0FETmdLd0JDQUFJQUVnQldvMkFxd0VDeUFDS0FJQUlRVU1BUXNnQWlBQUtBSU1JZ1ZCRFhRZ0FRUi9JQUFnQlVFTGREWUNrQVFnQUNBQklBTnFOZ0tNQkNBQ0tBSUFCU0FEQzJwQkIycEJDRzFCQTNRaUF6WUNBQ0FBS0FJTUlRVWdBaUFCQkg4Z0FDQUZOZ0w4QXlBQUlBRWdBMm8yQXZnRElBSW9BZ0FGSUFNTElBVkJBblJxUVFkcVFRaHRRUU4wSWdVMkFnQWdBQ2dDRENFRElBRUVRQ0FBSUFNMkFvZ0VJQUJCQkRZQ2hBUWdBQ0FCSUFWcU5nS0FCQ0FDS0FJQUlRVUxJQU5CQkhRaEF3c2dBaUFEUVFkeUlBVnFRUWh0UVFOMElnTTJBZ0FMSUFBdEFFMEVRQUpBUWRqYkFDMEFBRUVCY1EwQVFkamJBQkFqUlEwQVFkRFpBQkFtUVlnQ0VCb2FRZGpiQUJBaUMwSFEyUUFRVUNJRFFRVjBJUVlnQUMwQVQwVUVRQ0FCQkVBZ0FpZ0NBQ0VGSUFBZ0JqWUMwQVFnQUNBQklBVnFOZ0xNQkFzZ0FpQUNLQUlBSUFOQkNIUnFRUWRxUVFodFFRTjBJZ1UyQWdBZ0FpQURRUWQwSWdRZ0FDZ0NEQ0lEYkNBQkJIOGdBQ0FETmdMb0JDQUFJQVkyQXVRRUlBQWdBU0FGYWpZQzRBUWdBaWdDQUFVZ0JRdHFRUWRxUVFodFFRTjBJZ00yQWdBZ0FDZ0NEQ0VGSUFJZ0FRUi9JQUFnQlRZQzNBUWdBQ0FHTmdMWUJDQUFJQUVnQTJvMkF0UUVJQUlvQWdBRklBTUxJQVFnQld4QkIzSnFRUWh0UVFOMElnTTJBZ0FnQUNnQ0RDRUZJQUlnQVFSL0lBQWdCVFlDakFjZ0FDQUJJQU5xTmdLSUJ5QUNLQUlBQlNBREN5QUZRUUowYWtFSGFrRUliVUVEZENJRE5nSUFJQUlnQUNnQ0RDSUZRUU4wSUFFRWZ5QUFJQVZCQVhRMkFwUUhJQUFnQVNBRGFqWUNrQWNnQWlnQ0FBVWdBd3RxUVFkcVFRaHRRUU4wSWdVMkFnQWdBQ2dDRENBQUtBSVliRUVMZENFREFrQWdBVVVFUUNBQ0lBTkJCM0lnQldwQkNHMUJBM1FpQlRZQ0FDQUFLQUlNSVFNTUFRc2dBQ0FETmdLY0J5QUFJQUVnQldvMkFwZ0hJQUlnQWlnQ0FDQURRUWR5YWtFSWJVRURkQ0lETmdJQUlBQWdBU0FEYWpZQ29BY2dBQ0FBS0FJTUlnTkJDM1EyQXFRSElBSW9BZ0FoQlFzZ0FpQUZJQU5CREhScVFRZHFRUWh0UVFOME5nSUFDd0pBSUFBdEFFUUVRRUVBSVFVQ1FFSFkyd0F0QUFCQkFYRU5BRUhZMndBUUkwVU5BRUhRMlFBUUprR0lBaEFhR2tIWTJ3QVFJZ3RCQVNFRUEwQWdCVUVNYkNJRFFkblpBR290QUFBRVFDQURRZGZaQUdvc0FBQkJBWFFnQTBIWTJRQnFMQUFBYlNJRElBUWdBeUFFU2hzaEJBc2dCVUVCYWlJRlFSWkhEUUFMREFFTElBQW9BalFoQkFzZ0FnSi9JQUZGQkVBZ0J5QUNLQUlBYWtFSWFrRUliVUVEZEF3QkN5QUNLQUlBSVFNZ0FDQUhRUUZxTmdMd0JDQUFJQUVnQTJvMkF1d0VJQUlnQnlBQ0tBSUFha0VJYWtFSWJVRURkQ0lETmdJQUlBQWdCallDeUFRZ0FDQUJJQU5xTmdMRUJDQUNLQUlBQ3lBR1FRZHlha0VJYlVFRGRDSUROZ0lBSUFRZ0NXd2dDVUVBSUFSQkFVb2JhaUVGSUFJZ0FRUi9JQUFnQlRZQ3NBY2dBQ0FCSUFOcU5nS3NCeUFDS0FJQUJTQURDeUFGYWtFSGFrRUliVUVEZENJRE5nSUFDd0pBQWtBZ0FDMEFSRVVFUUNBQUtBSThRUUZyUWY4QmNTSUZJQVZCSEd4cVFRUnFJUVVnQWlBQkJIOGdBQ0FGTmdKZ0lBQWdBU0FEYWpZQ1hDQUNLQUlBQlNBREN5QUZha0VIYWtFSWJVRURkQ0lETmdJQUlBQkI1QUJxSVFaQmpBRWhCd3dCQ3lBQVFlUUFhaUVHUVFRaEJTQUFLQUpJSWdkQkJFZ0VRRUVDSVFVTUFnc2dCMEVQU1EwQkN5QUhRUVZ1UVFGMFFmNEJjU0VGQzBFQklRUWdCMEgvQVhGQkEyd2dCVUVCY21vZ0JVRWNiR29oQlNBQ0lBRUVmeUFHSUFVMkFnUWdCaUFCSUFOcU5nSUFJQUlvQWdBRklBTUxJQVZxUVFkcVFRaHRRUU4wTmdJQUlBQXRBRTVGRFFBZ0FpZ0NBQ0VEQWtBZ0FVVUVRQ0FDSUFOQmg4QUFha0VJYlVFRGRFR0hCbXBCQ0cxQkEzUkJod0pxUVFodFFRTjBRWWVBQVdwQkNHMUJBM1EyQWdBTUFRc2dBRUdBRURZQ3ZBY2dBQ0FCSUFOcUlnTTJBcmdISUFJZ0FpZ0NBRUdId0FCcVFRaHRRUU4wSWdVMkFnQWdBRUhBQVRZQ3hBY2dBQ0FCSUFWcU5nTEFCeUFDSUFJb0FnQkJod1pxUVFodFFRTjBJZ1UyQWdBZ0FFSEFBRFlDekFjZ0FDQUJJQVZxSWdjMkFzZ0hJQUlnQWlnQ0FFR0hBbXBCQ0cxQkEzUWlCVFlDQUNBQVFZQWdOZ0xVQnlBQUlBRWdCV28yQXRBSElBSWdBaWdDQUVHSGdBRnFRUWh0UVFOME5nSUFJQU5CZ0lDQS9BTTJBZ0JCQVNFQkEwQWdBYmNpQ2tRWUxVUlUreUVKUUtKRUFBQUFBQUFBb0QraUlnc1FMU0VNSXdCQkVHc2lBaVFBQW53Z0NrUVlMVVJVK3lGWlA2SWlDcjFDSUlpblFmLy8vLzhIY1NJRlFmdkRwUDhEVFFSQVJBQUFBQUFBQVBBL0lBVkJuc0dhOGdOSkRRRWFJQXBFQUFBQUFBQUFBQUFRTHd3QkN5QUtJQXFoSUFWQmdJREEvd2RQRFFBYUFrQUNRQUpBQWtBZ0NpQUNFRXhCQTNFT0F3QUJBZ01MSUFJckF3QWdBaXNEQ0JBdkRBTUxJQUlyQXdBZ0Fpc0RDRUVCRUM2YURBSUxJQUlyQXdBZ0Fpc0RDQkF2bWd3QkN5QUNLd01BSUFJckF3aEJBUkF1Q3lFS0lBSkJFR29rQUNBRElBRkJBblJxSUFwRUFBQUFBQUFBNEQraVJBQUFBQUFBQU9BL29DQU1JQXVqdHJ1aXRqZ0NBQ0FCUVFGcUlnRkJnQkJIRFFBTElBQkNBRGNEMkFjZ0FFSUFOd1BvQnlBQVFnQTNBK0FISUFkQkFDQUFLQUxNQjBFQ2RCQWJHaUFBS0FMQUIwRUFJQUFvQXNRSFFRSjBFQnNhSUFBb0F0QUhRUUFnQUNnQzFBZEJBblFRR3hvTEN5QUlRU0JxSkFBZ0JBdWVCd0VIZnlBQUlBQW9BZ1FnQUMwQUFXcEJBV28yQWhBZ0FDZ0NIQ2dDQUNBQUx3RVlha0VBSUFBdEFCWVFHeG9nQUNnQ0tDZ0NBQ0FBTHdFa2FrRUFJQUF0QUNJUUd4b0NRQ0FBTFFBTkJFQWdBQ2dDTkNnQ0FDQUFMd0V3YWlBQUtBSUlJQUF0QUFGQkFXb2lBMEgvQVhFUUdob2dBQ0FET2dBc0RBRUxJQUFvQWpRb0FnQWdBQzhCTUdwQkFUb0FBQ0FBUVFJNkFEZ2dBRUVCT2dBc0lBQXRBQUVFUUFOQUlBQW9Ba0FvQWdBZ0FDOEJQR3BCQVRvQUFDQUFLQUpBS0FJQUlBQXZBVHhxSUFsQkdIUkJHSFVpQTBIL0FXb2dBeUFEUVFCSUcwSHdLbW90QUFBNkFBRWdBQ0FBTFFBc0lBQXRBRGhxUVFGcklnTTZBRVFnQUNnQ1RDZ0NBQ0FBTHdGSWFrRUFJQU5CL3dGeEVCc2FJQUF0QUN3aEF3SkFJQUF0QURnaUJVVU5BRUVBSVFSQkFTRUlJQU5GQkVCQkFDRUREQUVMQTBCQkFDRUdJQWhCL3dGeEJIOERRRUVBSVFNQ1FDQUFLQUkwS0FJQUlBQXZBVEJxSUFacUxRQUFJZ1ZGRFFBZ0FDOEJQQ0FBS0FKQUtBSUFJQVJxYWkwQUFDSUlSUTBBSUFoQjhDaHFMUUFBSUFWQjhDaHFMUUFBYWtId0ttb3RBQUFoQXdzZ0FDZ0NUQ2dDQUNBQUx3RklhaUFFSUFacVFmOEJjV29pQlNBRkxRQUFJQU56T2dBQUlBWkJBV29pQmlBQUxRQXNJZ05KRFFBTElBQXRBRGdoQlNBREJVRUFDeUVJSUFSQkFXb2lCQ0FGU1EwQUN3c2dBQ0FESUFBdEFFUWlCQ0FESUFSTEd5SURPZ0FzSUFBb0FqUW9BZ0FnQUM4Qk1Hb2dBQ2dDVENnQ0FDQUFMd0ZJYWlBRFFmOEJjUkFhR2lBQUlBTTZBQ3dnQUMwQUFTQUpRUUZxSWdsQkdIUkJHSFZLRFFBTEN5QUFLQUlJSUFBb0FqUW9BZ0FnQUM4Qk1Hb2dBQzBBTEJBYUdpQUFRUUU2QUEwTElBQW9BaHdvQWdBZ0FDOEJHR29nQVNBQUxRQUFJZ01RR2hvZ0FDQURPZ0FVSUFBb0FpZ29BZ0FnQUM4QkpHb2dBU0FBTFFBQUVCb2FJQUFnQUMwQUFTSUJJQUF0QUJScU9nQWdJQUF0QUFBaUF3UkFBMEFDUUNBQUtBSW9LQUlBSUFBdkFTUnFJQWRxTFFBQUlnUkZEUUJCQVNFQklBQXRBQ3hCQWtrTkFBTkFJQUFvQWlnb0FnQWdBQzhCSkdvZ0FTQUhha0gvQVhGcUlnTWdBQ2dDTkNnQ0FDQUFMd0V3YWlBQmFpMEFBQ0lHQkg4Z0JFSHdLR290QUFBZ0JrSHdLR290QUFCcVFmQXFhaTBBQUFWQkFBc2dBeTBBQUhNNkFBQWdBVUVCYWlJQklBQXRBQ3hKRFFBTElBQXRBQUFoQXdzZ0IwRUJhaUlISUFOSkRRQUxJQU1oQnlBQUxRQUJJUUVMSUFJZ0FDZ0NLQ2dDQUNBQUx3RWthaUFIUWY4QmNXb2dBVUgvQVhFUUdob0x6QVlCQTM4akFFSFFBR3NpQlNRQUFrQWdBVUVBU0FSQVFRQWhBa0hBMlFBb0FnQWlBRVVOQVNBRklBRTJBZ0FnQUVIV0lDQUZFQndNQVFzQ1FDQUFMUUJOQkVBQ1FDQUFMUUJFQkg4Z0FDZ0NTQVZCakFFTElnWWdBVTRFUUNBQklRWU1BUXRCd05rQUtBSUFJZ2RGRFFBZ0JTQUdOZ0pFSUFVZ0FUWUNRQ0FIUWNNWklBVkJRR3NRSEFzZ0JFSGxBRThFUUVFQUlRSkJ3TmtBS0FJQUlnQkZEUU1nQlNBRU5nSVFJQUJCcmlFZ0JVRVFhaEFjREFNTElBQkJBRG9BdEFRZ0FDZ0M3QVJCQUNBQUtBTHdCQkFiR2lBQUtBSlVRUUFnQUNnQ1dCQWJHaUFHUVFCTURRRWdBMEVXVHdSQVFRQWhBa0hBMlFBb0FnQWlBRVVOQXlBRklBTTJBakFnQUVIQ0lTQUZRVEJxRUJ3TUF3c2dBQ0FEUVF4c2FpSUJMUUNKQlVVRVFFRUFJUUpCd05rQUtBSUFJZ0JGRFFNZ0JTQUROZ0lnSUFCQml4c2dCVUVnYWhBY0RBTUxJQUF0QUVRaEF3Si9Ba0FnQVMwQWlBVkJBa1lFUUNBREJFQWdBQ0FCS1FLQUJUY0M5QVFnQUNBQktBS0lCVFlDL0FRTUFndEJBQ0VDUWNEWkFDZ0NBQ0lBUlEwRlFkMGJRVHNnQUJBb0RBVUxJQUFnQVNrQ2dBVTNBdlFFSUFBZ0FTZ0NpQVUyQXZ3RUlBWWdBMFVOQVJvTElBQW9Ba2dMSVFFZ0FDQUJOZ0s4QkNBQUlBUzNSQUFBQUFBQUFGbEFvN1k0QXJnRUlBQW9BdXdFSUFFNkFBQkJBQ0VCSUFBb0Fyd0VRUUJLQkVBRFFFRUFJUVFnQVVFQmFpSURJQUFvQXV3RWFpQUJJQVpJQkg4Z0FTQUNhaTBBQUFWQkFBczZBQUFnQUMwQVVBUkFJQUFvQXV3RUlBTnFJZ1FnQkMwQUFDQUJRVDl4UWJBb2FpMEFBSE02QUFBTElBTWlBU0FBS0FLOEJFZ05BQXNMSUFCQkFUb0F0QVFNQVFzZ0FVVU5BRUhBMlFBb0FnQWlBVVVOQUVHS0drSEFBQ0FCRUNnTElBQXRBRXhGQkVCQkFTRUNEQUVMSUFCQkFEc0JiQ0FBUWdBM0FvQUJJQUJDQURjQ2lBRWdBQ2dDc0FGQkFDQUFLQUswQVVFQ2RCQWJHaUFBS0FLNEFVRUFJQUFvQXJ3QlFRSjBFQnNhUVFFaEFnSkFJQUFvQW9RRUlnRkJBRXdOQUNBQUtBS0lCQ0lEUVFCTURRQWdBQ2dDZ0FSQkFDQUJJQU5zUVFKMEVCc2FDeUFBS0FMVUFVRUFJQUFvQXRnQkVCc2FJQUFvQXB3RUlnRkJBRXdOQUNBQUtBS2dCQ0lEUVFCTURRQWdBQ2dDbUFSQkFDQUJJQU5zRUJzYUN5QUZRZEFBYWlRQUlBSUw2MFVERG44SWZRUjhJd0JCTUdzaUVpUUFBa0FnQUVFQ2RFR3cyUUJxS0FJQUlnZEZCRUJCZnlFQlFjRFpBQ2dDQUNJQ1JRMEJJQklnQURZQ0FDQUNRZFljSUJJUUhBd0JDeUFISUFJZ0FTQURJQVFRVTBVRVFFRi9JUUZCd05rQUtBSUFJZ0pGRFFFZ0VpQUFOZ0lnSUFKQm1Sd2dFa0VnYWhBY0RBRUxBa0FDUUFKQUlBWU9BZ0lBQVFzZ0J5MEF0QVFFZnlBSEtBSU1JUUFnQnkwQVRnUi9JQWRCdUFkcUlBY3FBZ2dnQnlvQ0JKVWdBQ0FIS0FLSUIwRUFFREJCQVdvRklBQUxJQWNzQVBvRUlBY3NBUHdFSUFjc0FQc0VJZ0VnQnlnQ1BBSi9RUUlnQnlnQ3ZBUWlBRUVFU0EwQUdrRUVJQUJCRDBrTkFCb2dBRUVGYmtFQmRBc2dBR3BxYWtFQmF5QUJiV3hzSUFjb0FqaEJBWFJxYkFWQkFBc2dCeWdDR0d3aEFRd0NDeUFITFFDMEJFVUVRRUVBSVFFTUFnc2dCeWdDRENFQUlBY3RBRTRFZnlBSFFiZ0hhaUFIS2dJSUlBY3FBZ1NWSUFBZ0J5Z0NpQWRCQUJBd1FRRnFCU0FBQ3lBSExBRDZCQ0FITEFEOEJDQUhMQUQ3QkNJQklBY29BandDZjBFQ0lBY29BcndFSWdCQkJFZ05BQnBCQkNBQVFROUpEUUFhSUFCQkJXNUJBWFFMSUFCcWFtcEJBV3NnQVcxc2JDQUhLQUk0UVFGMGFtd2hBUXdCQ3lNQVFlQUJheUlCSkFBQ1FDQUhMUUJOUlFSQVFRQWhBa0hBMlFBb0FnQWlBMFVOQVVHS0drSEFBQ0FERUNnTUFRc2dCeTBBVGdSQUlBZENBRGNENkFjZ0IwSUFOd1BnQnlBSFFnQTNBOWdISUFjb0FzZ0hRUUFnQnlnQ3pBZEJBblFRR3hvZ0J5Z0N3QWRCQUNBSEtBTEVCMEVDZEJBYkdpQUhLQUxRQjBFQUlBY29BdFFIUVFKMEVCc2FDd0ovUVFJZ0J5Z0N2QVFpQWtFRVNBMEFHa0VFSUFKQkQwa05BQm9nQWtFRmJrRUJkQXNoQ1NBSExBRDdCQ0lESUFjb0Fqd2lCaUFDSUFscWFtcEJBV3NnQTIwaEZDQUhMQUQ4QkNFSUlBY3NBUG9FSVF3Z0J5MEFSRVVFUUNBSEtBSmNJUUlnQVVFQU5nTGNBU0FCUVFBNkFOUUJJQUZCQURZQzBBRWdBVUVBT2dESUFTQUJRUUEyQXNRQklBRkJBRG9BdkFFZ0FVRUFOZ0s0QVNBQlFRQTZBTEFCSUFGQkFEWUNyQUVnQVVFQU9nQ2tBU0FCUVFBMkFxQUJJQUZCQURvQW1BRWdBVUVBTmdLVUFTQUJRUUE2QUl3QklBRkJBRFlDaUFFZ0FVRUFPZ0NBQVNBQlFRQTJBbndnQVVFQU9nQjBJQUZCQURZQ2NDQUJRUUE2QUdnZ0FVRUFOZ0prSUFGQkFEb0FYQ0FCUVFBMkFsZ2dBVUVBT2dCUUlBRkJBRFlDVENBQlFRQTZBRVFnQVVGQWEwRUFOZ0lBSUFGQkFEb0FPQ0FCUVFBMkFqUWdBVUVBT2dBc0lBRkJBRFlDS0NBQlFRQTZBQ0FnQVVFQU5nSWNJQUZCQURvQUZDQUJJQVpCQVdzaUF6b0FBU0FCUVFFNkFBQWdBVUVBT3dFTUlBSkZCRUJCQVNFS0lBTkIvd0Z4SWdJZ0FrRWNiR3BCQkdvUUp5RUNDeUFCUVFBN0FSZ2dBU0FHT2dBV0lBRWdCa0gvQVhFaUN6c0JKQ0FCSUFZNkFDSWdBU0FEUVFGMElnTTZBQzRnQVVFRE9nQTVJQUVnQXpvQU9pQUJJQXRCQVhRaUV6c0JNQ0FCSUJNZ0EwSCtBWEVpQkdvaUV6c0JQQ0FCSUFvNkFBd2dBU0FDTmdJRUlBRWdBallDQ0NBQlFRQTdBUlFnQVVHQUFqc0JJQ0FCUVlBRU93RXNJQUVnQVVFUWFpSUNOZ0ljSUFFZ0FqWUNLQ0FCSUFJMkFqUWdBU0FFSUJOcUlnbzdBVWdnQVNBRE9nQkdJQUVnQmpvQVVpQUJJQU02QUY0Z0FTQURPZ0JxSUFGQkNEb0FkU0FCSUFRZ0Ntb2lCanNCVkNBQklBWWdDMm9pQmpzQllDQUJJQVFnQm1vaUJqc0JiQ0FCSUFRZ0Jtb2lCanNCZUNBQlFZQUlPd0ZFSUFFZ0FqWUNRQ0FCUVFBNkFEZ2dBU0FDTmdKTUlBRkJnQW83QVZBZ0FTQUNOZ0pZSUFGQmdBdzdBVndnQVNBQ05nSmtJQUZCZ0E0N0FXZ2dBU0FDTmdKd0lBRWdBem9BZGlBQklBUWdCbW9pQmpzQmhBRWdBU0FET2dDQ0FTQUJJQU02QUk0QklBRWdBem9BbWdFZ0FVRU1PZ0NsQVNBQklBTTZBS1lCSUFFZ0JDQUdhaUlHT3dHUUFTQUJJQVFnQm1vaUJqc0JuQUVnQVNBRUlBWnFJZ1k3QWFnQklBRkJBRG9BZENBQklBSTJBbndnQVVHQUVqc0JnQUVnQVNBQ05nS0lBU0FCUVlBVU93R01BU0FCSUFJMkFwUUJJQUZCZ0JZN0FaZ0JJQUVnQWpZQ29BRWdBU0FFSUFacUlnWTdBYlFCSUFGQkRUb0FzUUVnQVNBQ05nS3NBU0FCUVFBNkFLUUJJQUVnQXpvQXNnRWdBU0FFSUFacUlnWTdBY0FCSUFGQkRqb0F2UUVnQVNBQ05nSzRBU0FCUVFBNkFMQUJJQUVnQXpvQXZnRWdBU0FFSUFacUlnWTdBY3dCSUFGQkR6b0F5UUVnQVNBQ05nTEVBU0FCUVFBNkFMd0JJQUVnQXpvQXlnRWdBU0FFSUFacU93SFlBU0FCUVJBNkFOVUJJQUVnQWpZQzBBRWdBVUVBT2dESUFTQUJJQU02QU5ZQklBRWdBallDM0FFZ0FVRUFPZ0RVQVNBQklBY29BdXdFSWdJZ0J5Z0NWQ0FDSUFFdEFBQVFHaUFCTFFBQWFoQlNBa0FnQVMwQURFVU5BQ0FCS0FJRUlnSkZEUUFnQWhBaEN5QUhMUUM4QkNFQ0N5QUhLQUprSVFSQkFDRUdJQUZCQURZQzNBRWdBVUVBT2dEVUFTQUJRUUEyQXRBQklBRkJBRG9BeUFFZ0FVRUFOZ0xFQVNBQlFRQTZBTHdCSUFGQkFEWUN1QUVnQVVFQU9nQ3dBU0FCUVFBMkFxd0JJQUZCQURvQXBBRWdBVUVBTmdLZ0FTQUJRUUE2QUpnQklBRkJBRFlDbEFFZ0FVRUFPZ0NNQVNBQlFRQTJBb2dCSUFGQkFEb0FnQUVnQVVFQU5nSjhJQUZCQURvQWRDQUJRUUEyQW5BZ0FVRUFPZ0JvSUFGQkFEWUNaQ0FCUVFBNkFGd2dBVUVBTmdKWUlBRkJBRG9BVUNBQlFRQTJBa3dnQVVFQU9nQkVJQUZCUUd0QkFEWUNBQ0FCUVFBNkFEZ2dBVUVBTmdJMElBRkJBRG9BTENBQlFRQTJBaWdnQVVFQU9nQWdJQUZCQURZQ0hDQUJRUUE2QUJRZ0FTQUpPZ0FCSUFFZ0Fqb0FBQ0FCUVFBN0FRd2dCRVVFUUVFQklRMGdDVUgrQVhFaUEwRWNiQ0FEYWlBQ1FmOEJjVUVEYkdwQkFXb1FKeUVFQ3lBSUlCUnNJQXhzSVJRZ0FVRUFPd0VZSUFFZ0FpQUphaUlMT2dBV0lBRWdDem9BSWlBQklBbEJBWFFpQXpvQUxpQUJRUU02QURrZ0FTQURPZ0E2SUFFZ0MwSC9BWEVpQ1RzQkpDQUJJQWxCQVhRaUFqc0JNQ0FCSUFJZ0EwSCtBWEVpQ21vaUNEc0JQQ0FCSUEwNkFBd2dBU0FFTmdJRUlBRWdCRFlDQ0NBQlFRQTdBUlFnQVVHQUFqc0JJQ0FCUVlBRU93RXNJQUVnQVVFUWFpSUNOZ0ljSUFFZ0FqWUNLQ0FCSUFJMkFqUWdBU0FJSUFwcUlnUTdBVWdnQVNBRE9nQkdJQUVnQ3pvQVVpQUJJQU02QUY0Z0FTQURPZ0JxSUFGQkNEb0FkU0FCSUFRZ0Ntb2lCRHNCVkNBQklBUWdDV29pQkRzQllDQUJJQVFnQ21vaUJEc0JiQ0FCSUFRZ0Ntb2lCRHNCZUNBQlFZQUlPd0ZFSUFFZ0FqWUNRQ0FCUVFBNkFEZ2dBU0FDTmdKTUlBRkJnQW83QVZBZ0FTQUNOZ0pZSUFGQmdBdzdBVndnQVNBQ05nSmtJQUZCZ0E0N0FXZ2dBU0FDTmdKd0lBRWdBem9BZGlBQklBUWdDbW9pQkRzQmhBRWdBU0FET2dDQ0FTQUJJQU02QUk0QklBRWdBem9BbWdFZ0FVRU1PZ0NsQVNBQklBTTZBS1lCSUFFZ0JDQUthaUlFT3dHUUFTQUJJQVFnQ21vaUJEc0JuQUVnQVNBRUlBcHFJZ1E3QWFnQklBRkJBRG9BZENBQklBSTJBbndnQVVHQUVqc0JnQUVnQVNBQ05nS0lBU0FCUVlBVU93R01BU0FCSUFJMkFwUUJJQUZCZ0JZN0FaZ0JJQUVnQWpZQ29BRWdBU0FFSUFwcUlnUTdBYlFCSUFGQkRUb0FzUUVnQVNBQ05nS3NBU0FCUVFBNkFLUUJJQUVnQXpvQXNnRWdBU0FFSUFwcUlnUTdBY0FCSUFGQkRqb0F2UUVnQVNBQ05nSzRBU0FCUVFBNkFMQUJJQUVnQXpvQXZnRWdBU0FFSUFwcUlnUTdBY3dCSUFGQkR6b0F5UUVnQVNBQ05nTEVBU0FCUVFBNkFMd0JJQUVnQXpvQXlnRWdBU0FFSUFwcU93SFlBU0FCUVJBNkFOVUJJQUVnQWpZQzBBRWdBVUVBT2dESUFTQUJJQU02QU5ZQklBRWdBallDM0FFZ0FVRUFPZ0RVQVNBQklBY29BdXdFUVFGcUlnSWdCeWdDVkNBSEtBSThhaUFDSUFFdEFBQVFHaUFCTFFBQWFoQlNJQWRCQURZQ3FBY0NRQ0FITFFDMEJFVU5BQU5BQWtBZ0J5Z0NPQ0lDSUFaS0JFQkJBQ0VDSUFjb0FqUkJBRXdOQVFOQUlBY2dCeWdDcUFjaUEwRUJhallDcUFjZ0F5QUhLQUtzQjJvZ0FrRUJjU0FDUVFGMGNqb0FBQ0FDUVFGcUlnSWdCeWdDTkVnTkFBc01BUXNnQWlBVWFpSURJQVpLQkVBZ0J5d0Erd1FoQkNBSExBRDZCQ0VESUFjb0FzUUVRUUFnQnlnQ3lBUVFHeG9nQmlBQ2F5QURiU0VDSUFjc0FQc0VJZ05CQUV3TkFTQUNJQVJzSVFRQ1FDQUhMQUQ4QkNJQ1FRRkdCRUFnQnlnQ3hBUWhDaUFIS0FKVUlRMUJBQ0VDQTBBZ0NpQUNRUVYwSWdrZ0RTQUNJQVJxYWlJTExRQUFRUTl4Y21wQkFUb0FBQ0FLSUFrZ0N5MEFBRUVFZG5KcVFRRTZBQkFnQWtFQmFpSUNJQU5IRFFBTERBRUxJQWNvQXNRRUlRb2dCeWdDVkNFTklBUWdBbTBpQ1NBQ2JDQUVSd1JBUVFBaEFpQURRUUZIQkVBZ0EwRitjU0VMUVFBaEJBTkFJQW9nQWtFRmRDQU5JQUlnQ1dwcUxRQUFRUVIyY21wQkFUb0FBQ0FLSUFKQkFYSWlDRUVGZENBTklBZ2dDV3BxTFFBQVFRUjJjbXBCQVRvQUFDQUNRUUpxSVFJZ0JFRUNhaUlFSUF0SERRQUxDeUFEUVFGeFJRMEJJQW9nQWtFRmRDQU5JQUlnQ1dwcUxRQUFRUVIyY21wQkFUb0FBQXdCQzBFQUlRSWdBMEVCUndSQUlBTkJmbkVoQzBFQUlRUURRQ0FLSUEwZ0FpQUphbW90QUFCQkQzRWdBa0VGZEhKcVFRRTZBQUFnQ2lBQ1FRRnlJZ2hCQlhRZ0RTQUlJQWxxYWkwQUFFRVBjWEpxUVFFNkFBQWdBa0VDYWlFQ0lBUkJBbW9pQkNBTFJ3MEFDd3NnQTBFQmNVVU5BQ0FLSUEwZ0FpQUphbW90QUFCQkQzRWdBa0VGZEhKcVFRRTZBQUFMUVFBaEFpQURRUUJNRFFFRFFDQUhLQUxFQkNBQ2FpMEFBQVJBSUFjZ0J5Z0NxQWNpQTBFQmFqWUNxQWNnQXlBSEtBS3NCMm9nQWpvQUFDQUhMUUQ3QkNFREN5QUNRUUZxSWdJZ0EwRVlkRUVZZFVFRmRFZ05BQXNNQVFzZ0JpQUNJQU5xVGcwQ1FRQWhBaUFIS0FJMFFRQk1EUUFEUUNBSElBY29BcWdISWdOQkFXbzJBcWdISUFNZ0J5Z0NyQWRxSUFKQkFYRWdBa0VCZEhKQkFYTTZBQUFnQWtFQmFpSUNJQWNvQWpSSURRQUxDeUFITEFEN0JFRUJkQ0FITEFEOEJHMUJBazRFUUNBSElBY29BcWdISWdKQkFXbzJBcWdISUFJZ0J5Z0NyQWRxUWY4Qk9nQUFDeUFHSUFjc0FQb0VhaUVHREFBTEFBc0NmeUFITFFCUFJRUkFBa0FnQnlnQzBBUWlBMEVBVEEwQUlBY3NBUHNFUVFOMHR5RWRJQWNvQXN3RUlRUkJBQ0VDSUFOQkFVY0VRQ0FEUVg1eElRWkJBQ0VLQTBBZ0JDQUNRUU4wYWlBQ3QwUVlMVVJVK3lFSlFLSWdIYU01QXdBZ0JDQUNRUUZ5SWcxQkEzUnFJQTIzUkJndFJGVDdJUWxBb2lBZG96a0RBQ0FDUVFKcUlRSWdDa0VDYWlJS0lBWkhEUUFMQ3lBRFFRRnhSUTBBSUFRZ0FrRURkR29nQXJkRUdDMUVWUHNoQ1VDaUlCMmpPUU1BQ3lBSEtBTElCQ0lOUVFCS0JFQWdCeWdDRENJRFFYNXhJUWtnQTBFQmNTRUxJQWN1QWZnRXNpRVZJQWNvQXN3RUlRaEJBQ0VFQTBBQ1FDQURRUUJNSWd3TkFFUUFBQUFBQUFEd1B5QUhLZ0lrSWhhN295SWZJQllnRlpRZ0J5b0NNQ0FFc3BTU3V5SWdvaUVlSUFnZ0JFRURkR29yQXdBaEhTQUhLQUxVQkNBSEtBTGNCQ0FFYkVFQ2RHb2hCa0VBSVFKQkFDRUtJQU5CQVVjRVFBTkFJQVlnQWtFQ2RHb2dBcmNnQnlvQ0VMdWlSQmd0UkZUN0lSbEFvaUFlb2lBZG9CQXR0amdDQUNBR0lBSkJBWElpRTBFQ2RHb2dFN2NnQnlvQ0VMdWlSQmd0UkZUN0lSbEFvaUFlb2lBZG9CQXR0amdDQUNBQ1FRSnFJUUlnQ2tFQ2FpSUtJQWxIRFFBTEN5QUxCRUFnQmlBQ1FRSjBhaUFDdHlBSEtnSVF1NkpFR0MxRVZQc2hHVUNpSUI2aUlCMmdFQzIyT0FJQUN5QU1EUUFnQnlnQzRBUWdCeWdDNkFRZ0JHeEJBblJxSVFZZ0J5Z0NMTEloRmtFQUlRSURRQ0FHSUFKQkFuUnFJQUszSUFjcUFoQzdva1FZTFVSVSt5RVpRS0lnSHlBZ0lBY3FBaVFnRnBTN29LS2lJQjJnRUMyMk9BSUFJQUpCQVdvaUFpQURSdzBBQ3dzZ0JFRUJhaUlFSUExSERRQUxDMEVBSVEwQ1FDQUhMUUMwQkVVTkFDQUhRYmdIYWlFVElBY3FBZ2dnQnlvQ0JKVWhIQU5BSUFjb0FvZ0hRUUFnQnlnQ2pBZEJBblFRR3hvQ1FBSkFBa0FDUUFKQUFrQWdCeWdDT0NJRUlCRktCRUFnQnlnQ05DSUtRUUJNRFFGQkFDRURBMEFDUUNBRFFRRnhSUVJBSUFjb0F0d0VJUUlnQnlnQzFBUWhDU0FIS0FJTUlnWWdCR3l5SWhkRG1wa1pQcFFoRlFKL0lCZERtcGxaUDVRaUZvdERBQUFBVDEwRVFDQVdxQXdCQzBHQWdJQ0FlQXNoQ0NBR1FRQk1JUXNDZnlBVmkwTUFBQUJQWFFSQUlCV29EQUVMUVlDQWdJQjRDeUVNSUFzTkFTQUdJQkZzSVE4Z0NTQUNJQU5zUVFKMGFpRUxRd0FBZ0Q4Z0ZaVWhHQ0FJc2lFYUlBeXlJUnNnQnlnQ2lBY2hDU0FIS2dLNEJDRVZRUUFoQWdOQUFrQWdHeUFDSUE5cXNpSVdYZ1JBSUFrZ0FrRUNkQ0lJYWlJTUlCVWdDQ0FMYWlvQ0FKUWdHQ0FXbEpRZ0RDb0NBSkk0QWdBTUFRc2dDeUFDUVFKMElnaHFLZ0lBSVJrZ0ZpQWFYZ1JBSUFnZ0NXb2lDQ0FWSUJtVUlCZ2dGeUFXazVTVUlBZ3FBZ0NTT0FJQURBRUxJQWdnQ1dvaUNDQVZJQm1VSUFncUFnQ1NPQUlBQ3lBQ1FRRnFJZ0lnQmtjTkFBc01BUXNnQnlnQzZBUWhBaUFIS0FMZ0JDRUpJQWNvQWd3aUJpQUViTElpRjBPYW1SaytsQ0VWQW44Z0YwT2FtVmsvbENJV2kwTUFBQUJQWFFSQUlCYW9EQUVMUVlDQWdJQjRDeUVJSUFaQkFFd2hDd0ovSUJXTFF3QUFBRTlkQkVBZ0ZhZ01BUXRCZ0lDQWdIZ0xJUXdnQ3cwQUlBWWdFV3doRHlBSklBSWdBMnhCQW5ScUlRdERBQUNBUHlBVmxTRVlJQWl5SVJvZ0RMSWhHeUFIS0FLSUJ5RUpJQWNxQXJnRUlSVkJBQ0VDQTBBQ1FDQWJJQUlnRDJxeUloWmVCRUFnQ1NBQ1FRSjBJZ2hxSWd3Z0ZTQUlJQXRxS2dJQWxDQVlJQmFVbENBTUtnSUFramdDQUF3QkN5QUxJQUpCQW5RaUNHb3FBZ0FoR1NBV0lCcGVCRUFnQ0NBSmFpSUlJQlVnR1pRZ0dDQVhJQmFUbEpRZ0NDb0NBSkk0QWdBTUFRc2dDQ0FKYWlJSUlCVWdHWlFnQ0NvQ0FKSTRBZ0FMSUFKQkFXb2lBaUFHUncwQUN3c2dBMEVCYWlJRElBcEhEUUFMREFFTElBUWdGR29pQWlBUlNnUkFJQWNzQVBzRUlRSWdCeXdBK2dRaEN5QUhLQUxFQkVFQUlBY29Bc2dFRUJzYUlCRWdCR3NpRENBTGJTRUlJQWNzQVBzRUlnTkJBRXdpRHcwQ0lBSWdDR3doQmdKQUlBY3NBUHdFSWdKQkFVWUVRQ0FIS0FMRUJDRUVJQWNvQWxRaENrRUFJUUlEUUNBRUlBSkJCWFFpQ1NBS0lBSWdCbXBxSWc0dEFBQkJEM0Z5YWtFQk9nQUFJQVFnQ1NBT0xRQUFRUVIyY21wQkFUb0FFQ0FDUVFGcUlnSWdBMGNOQUFzTUFRc2dCeWdDeEFRaEJDQUhLQUpVSVFvZ0JpQUNiU0lKSUFKc0lBWkhCRUJCQUNFQ0lBTkJBVWNFUUNBRFFYNXhJUTVCQUNFR0EwQWdCQ0FDUVFWMElBb2dBaUFKYW1vdEFBQkJCSFp5YWtFQk9nQUFJQVFnQWtFQmNpSVFRUVYwSUFvZ0NTQVFhbW90QUFCQkJIWnlha0VCT2dBQUlBSkJBbW9oQWlBR1FRSnFJZ1lnRGtjTkFBc0xJQU5CQVhGRkRRRWdCQ0FDUVFWMElBb2dBaUFKYW1vdEFBQkJCSFp5YWtFQk9nQUFEQUVMUVFBaEFpQURRUUZIQkVBZ0EwRitjU0VPUVFBaEJnTkFJQVFnQ2lBQ0lBbHFhaTBBQUVFUGNTQUNRUVYwY21wQkFUb0FBQ0FFSUFKQkFYSWlFRUVGZENBS0lBa2dFR3BxTFFBQVFROXhjbXBCQVRvQUFDQUNRUUpxSVFJZ0JrRUNhaUlHSUE1SERRQUxDeUFEUVFGeFJRMEFJQVFnQ2lBQ0lBbHFhaTBBQUVFUGNTQUNRUVYwY21wQkFUb0FBQXNnRHcwQ0lBd2dDQ0FMYkdzaENTQURRUVYwSWdKQkFTQUNRUUZLR3lFTUlBY29Bc1FFSVE5QkFDRURRUUFoQ2dOQUFrQWdBeUFQYWkwQUFFVU5BQ0FEUVFGMklRSWdDa0VCYWlFS0lBTkJBWEVFUUNBSEtBTG9CQ0VHSUFjb0F1QUVJUXNnQnlnQ0RDSUVJQWNzQVBvRWJMSWlGME9hbVJrK2xDRVZBbjhnRjBPYW1Way9sQ0lXaTBNQUFBQlBYUVJBSUJhb0RBRUxRWUNBZ0lCNEN5RUlJQVJCQUV3aERnSi9JQldMUXdBQUFFOWRCRUFnRmFnTUFRdEJnSUNBZ0hnTElSQWdEZzBCSUFRZ0NXd2hEaUFMSUFJZ0JteEJBblJxSVF0REFBQ0FQeUFWbFNFWUlBaXlJUm9nRUxJaEd5QUhLQUtJQnlFR0lBY3FBcmdFSVJWQkFDRUNBMEFDUUNBYklBSWdEbXF5SWhaZUJFQWdCaUFDUVFKMElnaHFJaEFnRlNBSUlBdHFLZ0lBbENBWUlCYVVsQ0FRS2dJQWtqZ0NBQXdCQ3lBTElBSkJBblFpQ0dvcUFnQWhHU0FXSUJwZUJFQWdCaUFJYWlJSUlCVWdHWlFnR0NBWElCYVRsSlFnQ0NvQ0FKSTRBZ0FNQVFzZ0JpQUlhaUlJSUJVZ0daUWdDQ29DQUpJNEFnQUxJQUpCQVdvaUFpQUVSdzBBQ3d3QkN5QUhLQUxjQkNFR0lBY29BdFFFSVFzZ0J5Z0NEQ0lFSUFjc0FQb0ViTElpRjBPYW1SaytsQ0VWQW44Z0YwT2FtVmsvbENJV2kwTUFBQUJQWFFSQUlCYW9EQUVMUVlDQWdJQjRDeUVJSUFSQkFFd2hEZ0ovSUJXTFF3QUFBRTlkQkVBZ0ZhZ01BUXRCZ0lDQWdIZ0xJUkFnRGcwQUlBUWdDV3doRGlBTElBSWdCbXhCQW5ScUlRdERBQUNBUHlBVmxTRVlJQWl5SVJvZ0VMSWhHeUFIS0FLSUJ5RUdJQWNxQXJnRUlSVkJBQ0VDQTBBQ1FDQWJJQUlnRG1xeUloWmVCRUFnQmlBQ1FRSjBJZ2hxSWhBZ0ZTQUlJQXRxS2dJQWxDQVlJQmFVbENBUUtnSUFramdDQUF3QkN5QUxJQUpCQW5RaUNHb3FBZ0FoR1NBV0lCcGVCRUFnQmlBSWFpSUlJQlVnR1pRZ0dDQVhJQmFUbEpRZ0NDb0NBSkk0QWdBTUFRc2dCaUFJYWlJSUlCVWdHWlFnQ0NvQ0FKSTRBZ0FMSUFKQkFXb2lBaUFFUncwQUN3c2dBMEVCYWlJRElBeEhEUUFMREFFTElCRWdBaUFFYWs0TkF5QUhLQUkwSWdwQkFFd05BQ0FSSUFKcklRdEJBQ0VEQTBBQ1FDQURRUUZ4UlFSQUlBY29BdWdFSVFJZ0J5Z0M0QVFoQ1NBSEtBSU1JZ1lnQkd5eUloZERtcGtaUHBRaEZRSi9JQmREbXBsWlA1UWlGb3REQUFBQVQxMEVRQ0FXcUF3QkMwR0FnSUNBZUFzaERDQUdRUUJNSVFnQ2Z5QVZpME1BQUFCUFhRUkFJQldvREFFTFFZQ0FnSUI0Q3lFUElBZ05BU0FHSUF0c0lRNGdDU0FDSUFOc1FRSjBhaUVJUXdBQWdEOGdGWlVoR0NBTXNpRWFJQSt5SVJzZ0J5Z0NpQWNoQ1NBSEtnSzRCQ0VWUVFBaEFnTkFBa0FnR3lBQ0lBNXFzaUlXWGdSQUlBa2dBa0VDZENJTWFpSVBJQlVnQ0NBTWFpb0NBSlFnR0NBV2xKUWdEeW9DQUpJNEFnQU1BUXNnQ0NBQ1FRSjBJZ3hxS2dJQUlSa2dGaUFhWGdSQUlBa2dER29pRENBVklCbVVJQmdnRnlBV2s1U1VJQXdxQWdDU09BSUFEQUVMSUFrZ0RHb2lEQ0FWSUJtVUlBd3FBZ0NTT0FJQUN5QUNRUUZxSWdJZ0JrY05BQXNNQVFzZ0J5Z0MzQVFoQWlBSEtBTFVCQ0VKSUFjb0Fnd2lCaUFFYkxJaUYwT2FtUmsrbENFVkFuOGdGME9hbVZrL2xDSVdpME1BQUFCUFhRUkFJQmFvREFFTFFZQ0FnSUI0Q3lFTUlBWkJBRXdoQ0FKL0lCV0xRd0FBQUU5ZEJFQWdGYWdNQVF0QmdJQ0FnSGdMSVE4Z0NBMEFJQVlnQzJ3aERpQUpJQUlnQTJ4QkFuUnFJUWhEQUFDQVB5QVZsU0VZSUF5eUlSb2dEN0loR3lBSEtBS0lCeUVKSUFjcUFyZ0VJUlZCQUNFQ0EwQUNRQ0FiSUFJZ0RtcXlJaFplQkVBZ0NTQUNRUUowSWd4cUlnOGdGU0FJSUF4cUtnSUFsQ0FZSUJhVWxDQVBLZ0lBa2pnQ0FBd0JDeUFJSUFKQkFuUWlER29xQWdBaEdTQVdJQnBlQkVBZ0NTQU1haUlNSUJVZ0daUWdHQ0FYSUJhVGxKUWdEQ29DQUpJNEFnQU1BUXNnQ1NBTWFpSU1JQlVnR1pRZ0RDb0NBSkk0QWdBTElBSkJBV29pQWlBR1J3MEFDd3NnQTBFQmFpSURJQXBIRFFBTEN5QUtRZi8vQTNFTkFRdEJBU0VLQ3dKQUlBY29BZ3dpQTBFQVRBMEFRd0FBZ0Q4Z0NrSC8vd054czVVaEZTQUhLQUtJQnlFS1FRQWhCRUVBSVFJZ0EwRUJhMEVEVHdSQUlBTkJmSEVoQzBFQUlRWURRQ0FLSUFKQkFuUWlDV29pQ0NBVklBZ3FBZ0NVT0FJQUlBb2dDVUVFY21vaUNDQVZJQWdxQWdDVU9BSUFJQW9nQ1VFSWNtb2lDQ0FWSUFncUFnQ1VPQUlBSUFvZ0NVRU1jbW9pQ1NBVklBa3FBZ0NVT0FJQUlBSkJCR29oQWlBR1FRUnFJZ1lnQzBjTkFBc0xJQU5CQTNFaUJrVU5BQU5BSUFvZ0FrRUNkR29pQ1NBVklBa3FBZ0NVT0FJQUlBSkJBV29oQWlBRVFRRnFJZ1FnQmtjTkFBc0xBa0FnQnkwQVRnUkFJQk1nSENBRElBY29Bb2dISUFjb0FwQUhFREFoQXd3QkN5QUhLQUtRQnlBSEtBS0lCeUFIS0FLVUJ5SUNJQWNvQW93SElnUWdBaUFFU0J0QkFuUVFHaG9MSUFOQkFFd2lCZzBDSUFOQkFYRWhDeUFIS0FLZ0J5RUtJQWNvQXBBSElRbEJBQ0VDSUFOQkFVWU5BU0FEUVg1eElRaEJBQ0VFQTBBZ0NpQUNJQTFxUVFGMGFnSi9JQWtnQWtFQ2RHb3FBZ0JEQUFBQVI1UWlGWXREQUFBQVQxMEVRQ0FWcUF3QkMwR0FnSUNBZUFzN0FRQWdDaUFDUVFGeUlnd2dEV3BCQVhScUFuOGdDU0FNUVFKMGFpb0NBRU1BQUFCSGxDSVZpME1BQUFCUFhRUkFJQldvREFFTFFZQ0FnSUI0Q3pzQkFDQUNRUUpxSVFJZ0JFRUNhaUlFSUFoSERRQUxEQUVMSUFkQkFEb0F0QVFNQXdzZ0MwVU5BQ0FLSUFJZ0RXcEJBWFJxQW44Z0NTQUNRUUowYWlvQ0FFTUFBQUJIbENJVmkwTUFBQUJQWFFSQUlCV29EQUVMUVlDQWdJQjRDenNCQUFzQ1FBSi9Ba0FDUUFKQUFrQUNRQUpBQWtBZ0J5Z0NJRUVCYXc0RkFBRUNDQU1JQ3lBR0RRY2dCeWdDbUFjaEJFRUFJUUlnQTBFQlJ3UkFJQU5CZm5FaEJrRUFJUW9EUUNBRUlBSWdEV3BxQW44Z0J5Z0NrQWNnQWtFQ2RHb3FBZ0JEQUFDQVA1SkRBQUFBUTVRaUZVTUFBSUJQWFNBVlF3QUFBQUJnY1FSQUlCV3BEQUVMUVFBTE9nQUFJQVFnQWtFQmNpSUpJQTFxYWdKL0lBY29BcEFISUFsQkFuUnFLZ0lBUXdBQWdEK1NRd0FBQUVPVUloVkRBQUNBVDEwZ0ZVTUFBQUFBWUhFRVFDQVZxUXdCQzBFQUN6b0FBQ0FDUVFKcUlRSWdDa0VDYWlJS0lBWkhEUUFMQ3lBRFFRRnhSUTBISUFRZ0FpQU5hbW9oQkNBSEtBS1FCeUFDUVFKMGFpb0NBRU1BQUlBL2trTUFBQUJEbENJVlF3QUFnRTlkSUJWREFBQUFBR0J4UlEwRElBUWdGYWs2QUFBTUJ3c2dCZzBHSUFjb0FwZ0hJUVJCQUNFQ0lBTkJBVWNFUUNBRFFYNXhJUVpCQUNFS0EwQWdCQ0FDSUExcWFnSi9JQWNvQXBBSElBSkJBblJxS2dJQVF3QUFBRU9VSWhWREFBQ0FUMTBnRlVNQUFBQUFZSEVFUUNBVnFRd0JDMEVBQ3pvQUFDQUVJQUpCQVhJaUNTQU5hbW9DZnlBSEtBS1FCeUFKUVFKMGFpb0NBRU1BQUFCRGxDSVZRd0FBZ0U5ZElCVkRBQUFBQUdCeEJFQWdGYWtNQVF0QkFBczZBQUFnQWtFQ2FpRUNJQXBCQW1vaUNpQUdSdzBBQ3dzZ0EwRUJjVVVOQmlBRUlBSWdEV3BxSVFRZ0J5Z0NrQWNnQWtFQ2RHb3FBZ0JEQUFBQVE1UWlGVU1BQUlCUFhTQVZRd0FBQUFCZ2NVVU5BeUFFSUJXcE9nQUFEQVlMSUFZTkJTQUhLQUtZQnlFR0lBY29BcEFISVFwQkFDRUNJQU5CQVVjRVFDQURRWDV4SVFsQkFDRUVBMEFnQmlBQ0lBMXFRUUYwYWdKL0lBb2dBa0VDZEdvcUFnQkRBQUNBUDVKREFBQUFSNVFpRlVNQUFJQlBYU0FWUXdBQUFBQmdjUVJBSUJXcERBRUxRUUFMT3dFQUlBWWdBa0VCY2lJTElBMXFRUUYwYWdKL0lBb2dDMEVDZEdvcUFnQkRBQUNBUDVKREFBQUFSNVFpRlVNQUFJQlBYU0FWUXdBQUFBQmdjUVJBSUJXcERBRUxRUUFMT3dFQUlBSkJBbW9oQWlBRVFRSnFJZ1FnQ1VjTkFBc0xJQU5CQVhGRkRRVWdCaUFDSUExcVFRRjBhaUVFSUFvZ0FrRUNkR29xQWdCREFBQ0FQNUpEQUFBQVI1UWlGVU1BQUlCUFhTQVZRd0FBQUFCZ2NVVU5BeUFWcVF3RUN5QUdEUVFnQnlnQ21BY2hDaUFIS0FLUUJ5RUpRUUFoQkVFQUlRSWdBMEVCYTBFRFR3UkFJQU5CZkhFaEMwRUFJUVlEUUNBS0lBSWdEV3BCQW5ScUlBa2dBa0VDZEdvcUFnQTRBZ0FnQ2lBQ1FRRnlJZ2dnRFdwQkFuUnFJQWtnQ0VFQ2RHb3FBZ0E0QWdBZ0NpQUNRUUp5SWdnZ0RXcEJBblJxSUFrZ0NFRUNkR29xQWdBNEFnQWdDaUFDUVFOeUlnZ2dEV3BCQW5ScUlBa2dDRUVDZEdvcUFnQTRBZ0FnQWtFRWFpRUNJQVpCQkdvaUJpQUxSdzBBQ3dzZ0EwRURjU0lHUlEwRUEwQWdDaUFDSUExcVFRSjBhaUFKSUFKQkFuUnFLZ0lBT0FJQUlBSkJBV29oQWlBRVFRRnFJZ1FnQmtjTkFBc01CQXNnQkVFQU9nQUFEQU1MSUFSQkFEb0FBQXdDQzBFQUN5RUNJQVFnQWpzQkFBc2dBeUFOYWlFTklCRkJBV29oRVNBSExRQzBCQTBBQ3dzZ0J5QU5OZ0xBQkNBSEtBSVlJQTFzREFFTElBZEJBRG9BdEFSQkFRc2hBaUFCTFFBTVJRMEFJQUVvQWdRaUEwVU5BQ0FERUNFTElBRkI0QUZxSkFBZ0FpSUJSUVJBUVg4aEFVSEEyUUFvQWdBaUFrVU5BU0FTSUFBMkFoQWdBa0h5SENBU1FSQnFFQndNQVF0QkFDRUFBa0FDZndKQUFrQWdCeWdDSUVFQmF3NEZBUUVCQUFFREN5QUhRYUFIYWd3QkN5QUhRWmdIYWdzb0FnQWhBQXNnQlNBQUlBRVFHaG9MSUJKQk1Hb2tBQ0FCQ3cwQUlBRWdBQ2dDQUdvb0FnQUw4UU1DQ1g4TWZVRUNJUU1DUUNBQVFRbElEUUFnQUNBQklBSVFjRUVJSVFNZ0FFRWhTUVJBREFFTFFTQWhCQU5BSUFBZ0F5QUJJQUlRYnlBRUlnTkJBblFpQkNBQVNBMEFDd3NDUUNBQUlBTkJBblJIQkVCQkFDRUFJQU5CQUV3TkFRTkFJQUVnQUVFQ2RDSUNRUVJ5YWlJRktnSUFJUXdnQVNBQUlBTnFRUUowSWdaQkJISnFJZ1FxQWdBaERTQUJJQUpxSWdJZ0Fpb0NBQ0lPSUFFZ0Jtb2lBaW9DQUNJUGtqZ0NBQ0FGSUF3Z0RaSTRBZ0FnQWlBT0lBK1RPQUlBSUFRZ0RDQU5remdDQUNBQVFRSnFJZ0FnQTBnTkFBc01BUXNnQTBFQVRBMEFRUUFoQUFOQUlBRWdBQ0FEYWlJRUlBTnFJZ0pCQW5RaUIwRUVjbW9pQ0NvQ0FDRVFJQUVnQWlBRGFrRUNkQ0lKUVFSeWFpSUtLZ0lBSVJFZ0FTQUFRUUowSWdKQkJISnFJZ3NxQWdBaEVpQUJJQVJCQW5RaUJFRUVjbW9pQlNvQ0FDRVRJQUVnQW1vaUFpQUNLZ0lBSWhRZ0FTQUVhaUlHS2dJQUloV1NJZ3dnQVNBSGFpSUVLZ0lBSWhZZ0FTQUphaUlDS2dJQUloZVNJZzJTT0FJQUlBc2dFaUFUa2lJT0lCQWdFWklpRDVJNEFnQWdCQ0FNSUEyVE9BSUFJQWdnRGlBUGt6Z0NBQ0FHSUJRZ0ZaTWlEQ0FRSUJHVElnMlRPQUlBSUFVZ0VpQVRreUlPSUJZZ0Y1TWlENUk0QWdBZ0FpQU1JQTJTT0FJQUlBb2dEaUFQa3pnQ0FDQUFRUUpxSWdBZ0EwZ05BQXNMQzg0SEF3cC9BWDRCZlNBQlFRQTJBZ0FDUUFKL0FrQWdBRUVKVGdSQVFRRWhDUU5BSUFCQkFYVWhBQUpBSUFraUEwRUFUQTBBUVFBaENVRUFJUVFnQTBFQmEwRURUd1JBSUFOQmZIRWhCa0VBSVFjRFFDQUJJQU1nQkdwQkFuUnFJQUVnQkVFQ2RHb29BZ0FnQUdvMkFnQWdBU0FFUVFGeUlnVWdBMnBCQW5ScUlBRWdCVUVDZEdvb0FnQWdBR28yQWdBZ0FTQUVRUUp5SWdVZ0EycEJBblJxSUFFZ0JVRUNkR29vQWdBZ0FHbzJBZ0FnQVNBRVFRTnlJZ1VnQTJwQkFuUnFJQUVnQlVFQ2RHb29BZ0FnQUdvMkFnQWdCRUVFYWlFRUlBZEJCR29pQnlBR1J3MEFDd3NnQTBFRGNTSUhSUTBBQTBBZ0FTQURJQVJxUVFKMGFpQUJJQVJCQW5ScUtBSUFJQUJxTmdJQUlBUkJBV29oQkNBSlFRRnFJZ2tnQjBjTkFBc0xJQU5CQVhRaENTQURRUVIwSWdjZ0FFZ05BQXNnQTBFQ2RDRUVJQUFnQjBZTkFVRUJJUU1nQ1VFQlRBMERBMEFnQTBFQmRDRUZJQUVnQTBFQ2RHb29BZ0FoQ0VFQUlRQURRQ0FDSUFnZ0FFRUJkR29pREVFQ2RHb2lCeWtDQUNFTklBSWdBU0FBUVFKMGFpZ0NBQ0FGYWlJS1FRSjBhaUlHS2dJRUlRNGdCeUFHS2dJQU9BSUFJQWNnRGpnQ0JDQUdJQTAzQWdBZ0FpQUVJQXhxUVFKMGFpSUhLUUlBSVEwZ0FpQUVJQXBxUVFKMGFpSUdLZ0lBSVE0Z0J5QUdLZ0lFT0FJRUlBY2dEamdDQUNBR0lBMDNBZ0FnQUVFQmFpSUFJQU5IRFFBTElBTkJBV29pQXlBSlJ3MEFDd3dEQ3lBQVFRaEhEUUpCQWlFRVFRRWhDVUVFREFFTElBbEJBRXdOQVNBRFFRTjBDeUVIUVFBaEF3TkFBa0FnQTBVRVFDQUJLQUlBSVFZTUFRc2dBMEVCZENFTUlBRWdBMEVDZEdvb0FnQWhCa0VBSVFBRFFDQUNJQVlnQUVFQmRHb2lDa0VDZEdvaUJTa0NBQ0VOSUFJZ0FTQUFRUUowYWlnQ0FDQU1haUlMUVFKMGFpSUlLZ0lFSVE0Z0JTQUlLZ0lBT0FJQUlBVWdEamdDQkNBSUlBMDNBZ0FnQWlBRUlBcHFJZ3BCQW5ScUlnVXBBZ0FoRFNBQ0lBY2dDMm9pQzBFQ2RHb2lDQ29DQUNFT0lBVWdDQ29DQkRnQ0JDQUZJQTQ0QWdBZ0NDQU5Od0lBSUFJZ0JDQUthaUlLUVFKMGFpSUZLUUlBSVEwZ0FpQUxJQVJySWd0QkFuUnFJZ2dxQWdBaERpQUZJQWdxQWdRNEFnUWdCU0FPT0FJQUlBZ2dEVGNDQUNBQ0lBUWdDbXBCQW5ScUlnVXBBZ0FoRFNBQ0lBY2dDMnBCQW5ScUlnZ3FBZ0FoRGlBRklBZ3FBZ1E0QWdRZ0JTQU9PQUlBSUFnZ0RUY0NBQ0FBUVFGcUlnQWdBMGNOQUFzTElBSWdCaUFESUFscVFRRjBhaUlHUVFKMGFpSUFLUUlBSVEwZ0FpQUVJQVpxUVFKMGFpSUdLZ0lFSVE0Z0FDQUdLZ0lBT0FJQUlBQWdEamdDQkNBR0lBMDNBZ0FnQTBFQmFpSURJQWxIRFFBTEN3c2NBQ0FBSUFGQkNDQUNweUFDUWlDSXB5QURweUFEUWlDSXB4QVNDNjBFQVFOL0lBQWdBU2dDQ0NBRUVDQUVRQUpBSUFFb0FnUWdBa2NOQUNBQktBSWNRUUZHRFFBZ0FTQUROZ0ljQ3c4TEFrQWdBQ0FCS0FJQUlBUVFJQVJBQWtBZ0FpQUJLQUlRUndSQUlBRW9BaFFnQWtjTkFRc2dBMEVCUncwQ0lBRkJBVFlDSUE4TElBRWdBellDSUNBQktBSXNRUVJIQkVBZ0FFRVFhaUlGSUFBb0FneEJBM1JxSVFkQkFDRURJQUVDZndKQUEwQUNRQ0FGSUFkUERRQWdBVUVBT3dFMElBVWdBU0FDSUFKQkFTQUVFRFVnQVMwQU5nMEFBa0FnQVMwQU5VVU5BQ0FCTFFBMEJFQkJBU0VESUFFb0FoaEJBVVlOQkVFQklRWWdBQzBBQ0VFQ2NRMEJEQVFMUVFFaEJpQUFMUUFJUVFGeFJRMERDeUFGUVFocUlRVU1BUXNMUVFRZ0JrVU5BUm9MUVFNTE5nSXNJQU5CQVhFTkFnc2dBU0FDTmdJVUlBRWdBU2dDS0VFQmFqWUNLQ0FCS0FJa1FRRkhEUUVnQVNnQ0dFRUNSdzBCSUFGQkFUb0FOZzhMSUFBb0Fnd2hCU0FBUVJCcUlnWWdBU0FDSUFNZ0JCQXhJQVZCQWtnTkFDQUdJQVZCQTNScUlRWWdBRUVZYWlFRkFrQWdBQ2dDQ0NJQVFRSnhSUVJBSUFFb0FpUkJBVWNOQVFzRFFDQUJMUUEyRFFJZ0JTQUJJQUlnQXlBRUVERWdCVUVJYWlJRklBWkpEUUFMREFFTElBQkJBWEZGQkVBRFFDQUJMUUEyRFFJZ0FTZ0NKRUVCUmcwQ0lBVWdBU0FDSUFNZ0JCQXhJQVZCQ0dvaUJTQUdTUTBBREFJTEFBc0RRQ0FCTFFBMkRRRWdBU2dDSkVFQlJnUkFJQUVvQWhoQkFVWU5BZ3NnQlNBQklBSWdBeUFFRURFZ0JVRUlhaUlGSUFaSkRRQUxDd3RzQVFKL0lBQWdBU2dDQ0VFQUVDQUVRQ0FCSUFJZ0F4QTNEd3NnQUNnQ0RDRUVJQUJCRUdvaUJTQUJJQUlnQXhBL0FrQWdCRUVDU0EwQUlBVWdCRUVEZEdvaEJDQUFRUmhxSVFBRFFDQUFJQUVnQWlBREVEOGdBUzBBTmcwQklBQkJDR29pQUNBRVNRMEFDd3NMTVFBZ0FDQUJLQUlJUVFBUUlBUkFJQUVnQWlBREVEY1BDeUFBS0FJSUlnQWdBU0FDSUFNZ0FDZ0NBQ2dDSEJFRkFBc1lBQ0FBSUFFb0FnaEJBQkFnQkVBZ0FTQUNJQU1RTndzTHVnTUJCWDhqQUVGQWFpSUVKQUFDZjBFQklBQWdBVUVBRUNBTkFCcEJBQ0FCUlEwQUdpTUFRVUJxSWdNa0FDQUJLQUlBSWdWQkJHc29BZ0FoQmlBRlFRaHJLQUlBSVFjZ0EwRUFOZ0lVSUFOQnRNOEFOZ0lRSUFNZ0FUWUNEQ0FEUWVUUEFEWUNDRUVBSVFVZ0EwRVlha0VBUVNjUUd4b2dBU0FIYWlFQkFrQWdCa0hrendCQkFCQWdCRUFnQTBFQk5nSTRJQVlnQTBFSWFpQUJJQUZCQVVFQUlBWW9BZ0FvQWhRUkJnQWdBVUVBSUFNb0FpQkJBVVliSVFVTUFRc2dCaUFEUVFocUlBRkJBVUVBSUFZb0FnQW9BaGdSQkFBQ1FBSkFJQU1vQWl3T0FnQUJBZ3NnQXlnQ0hFRUFJQU1vQWloQkFVWWJRUUFnQXlnQ0pFRUJSaHRCQUNBREtBSXdRUUZHR3lFRkRBRUxJQU1vQWlCQkFVY0VRQ0FES0FJd0RRRWdBeWdDSkVFQlJ3MEJJQU1vQWloQkFVY05BUXNnQXlnQ0dDRUZDeUFEUVVCckpBQkJBQ0FGSWdGRkRRQWFJQVJCQ0dvaUEwRUVja0VBUVRRUUd4b2dCRUVCTmdJNElBUkJmellDRkNBRUlBQTJBaEFnQkNBQk5nSUlJQUVnQXlBQ0tBSUFRUUVnQVNnQ0FDZ0NIQkVGQUNBRUtBSWdJZ0JCQVVZRVFDQUNJQVFvQWhnMkFnQUxJQUJCQVVZTElRQWdCRUZBYXlRQUlBQUxDUUFnQVNBQUVRSUFDd1FBSUFBTEJRQVFCd0FMVkFFQmZ5TUFRVEJySWdJa0FDQUNJQUVvQWlBMkFpZ2dBaUFCS1FJWU53TWdJQUlnQVNrQ0VEY0RHQ0FDSUFFcEFnZzNBeEFnQWlBQktRSUFOd01JSUFKQkNHb2dBQkVCQUNFQUlBSkJNR29rQUNBQUM2MFlBeEovQVh3Q2ZpTUFRYkFFYXlJTEpBQWdDMEVBTmdJc0FrQWdBYjBpR1VJQVV3UkFRUUVoRUVHS0NDRVRJQUdhSWdHOUlSa01BUXNnQkVHQUVIRUVRRUVCSVJCQmpRZ2hFd3dCQzBHUUNFR0xDQ0FFUVFGeEloQWJJUk1nRUVVaEZRc0NRQ0FaUW9DQWdJQ0FnSUQ0L3dDRFFvQ0FnSUNBZ0lENC93QlJCRUFnQUVFZ0lBSWdFRUVEYWlJRElBUkIvLzk3Y1JBZklBQWdFeUFRRUI0Z0FFRzVDa0cvRHlBRlFTQnhJZ1ViUVl3TVFaNFFJQVViSUFFZ0FXSWJRUU1RSGlBQVFTQWdBaUFESUFSQmdNQUFjeEFmSUFJZ0F5QUNJQU5LR3lFSkRBRUxJQXRCRUdvaEVRSkFBbjhDUUNBQklBdEJMR29RUnlJQklBR2dJZ0ZFQUFBQUFBQUFBQUJpQkVBZ0N5QUxLQUlzSWdaQkFXczJBaXdnQlVFZ2NpSU9RZUVBUncwQkRBTUxJQVZCSUhJaURrSGhBRVlOQWlBTEtBSXNJUXBCQmlBRElBTkJBRWdiREFFTElBc2dCa0VkYXlJS05nSXNJQUZFQUFBQUFBQUFzRUdpSVFGQkJpQURJQU5CQUVnYkN5RU1JQXRCTUdvZ0MwSFFBbW9nQ2tFQVNCc2lEU0VIQTBBZ0J3Si9JQUZFQUFBQUFBQUE4RUZqSUFGRUFBQUFBQUFBQUFCbWNRUkFJQUdyREFFTFFRQUxJZ00yQWdBZ0IwRUVhaUVISUFFZ0E3aWhSQUFBQUFCbHpjMUJvaUlCUkFBQUFBQUFBQUFBWWcwQUN3SkFJQXBCQUV3RVFDQUtJUU1nQnlFR0lBMGhDQXdCQ3lBTklRZ2dDaUVEQTBBZ0EwRWRJQU5CSFVrYklRTUNRQ0FIUVFScklnWWdDRWtOQUNBRHJTRWFRZ0FoR1FOQUlBWWdHVUwvLy8vL0Q0TWdCalVDQUNBYWhud2lHU0FaUW9DVTY5d0RnQ0laUW9DVTY5d0RmbjArQWdBZ0JrRUVheUlHSUFoUERRQUxJQm1uSWdaRkRRQWdDRUVFYXlJSUlBWTJBZ0FMQTBBZ0NDQUhJZ1pKQkVBZ0JrRUVheUlIS0FJQVJRMEJDd3NnQ3lBTEtBSXNJQU5ySWdNMkFpd2dCaUVISUFOQkFFb05BQXNMSUF4QkdXcEJDVzRoQnlBRFFRQklCRUFnQjBFQmFpRVBJQTVCNWdCR0lSSURRRUVBSUFOcklnTkJDU0FEUVFsSkd5RUpBa0FnQmlBSVN3UkFRWUNVNjl3RElBbDJJUlJCZnlBSmRFRi9jeUVXUVFBaEF5QUlJUWNEUUNBSElBTWdCeWdDQUNJWElBbDJhallDQUNBV0lCZHhJQlJzSVFNZ0IwRUVhaUlISUFaSkRRQUxJQWdvQWdBaEJ5QURSUTBCSUFZZ0F6WUNBQ0FHUVFScUlRWU1BUXNnQ0NnQ0FDRUhDeUFMSUFzb0Fpd2dDV29pQXpZQ0xDQU5JQWdnQjBWQkFuUnFJZ2dnRWhzaUJ5QVBRUUowYWlBR0lBWWdCMnRCQW5VZ0Qwb2JJUVlnQTBFQVNBMEFDd3RCQUNFREFrQWdCaUFJVFEwQUlBMGdDR3RCQW5WQkNXd2hBMEVLSVFjZ0NDZ0NBQ0lKUVFwSkRRQURRQ0FEUVFGcUlRTWdDU0FIUVFwc0lnZFBEUUFMQ3lBTVFRQWdBeUFPUWVZQVJodHJJQTVCNXdCR0lBeEJBRWR4YXlJSElBWWdEV3RCQW5WQkNXeEJDV3RJQkVCQkJFR2tBaUFLUVFCSUd5QUxhaUFIUVlESUFHb2lDVUVKYlNJUFFRSjBha0hRSDJzaENrRUtJUWNnQ1NBUFFRbHNheUlKUVFkTUJFQURRQ0FIUVFwc0lRY2dDVUVCYWlJSlFRaEhEUUFMQ3dKQUlBb29BZ0FpRWlBU0lBZHVJZzhnQjJ4cklnbEZJQXBCQkdvaUZDQUdSbkVOQUFKQUlBOUJBWEZGQkVCRUFBQUFBQUFBUUVNaEFTQUhRWUNVNjl3RFJ3MEJJQWdnQ2s4TkFTQUtRUVJyTFFBQVFRRnhSUTBCQzBRQkFBQUFBQUJBUXlFQkMwUUFBQUFBQUFEZ1AwUUFBQUFBQUFEd1AwUUFBQUFBQUFENFB5QUdJQlJHRzBRQUFBQUFBQUQ0UHlBSklBZEJBWFlpRkVZYklBa2dGRWtiSVJnQ1FDQVZEUUFnRXkwQUFFRXRSdzBBSUJpYUlSZ2dBWm9oQVFzZ0NpQVNJQWxySWdrMkFnQWdBU0FZb0NBQllRMEFJQW9nQnlBSmFpSUROZ0lBSUFOQmdKVHIzQU5QQkVBRFFDQUtRUUEyQWdBZ0NDQUtRUVJySWdwTEJFQWdDRUVFYXlJSVFRQTJBZ0FMSUFvZ0NpZ0NBRUVCYWlJRE5nSUFJQU5CLzVQcjNBTkxEUUFMQ3lBTklBaHJRUUoxUVFsc0lRTkJDaUVISUFnb0FnQWlDVUVLU1EwQUEwQWdBMEVCYWlFRElBa2dCMEVLYkNJSFR3MEFDd3NnQ2tFRWFpSUhJQVlnQmlBSFN4c2hCZ3NEUUNBR0lnY2dDRTBpQ1VVRVFDQUhRUVJySWdZb0FnQkZEUUVMQ3dKQUlBNUI1d0JIQkVBZ0JFRUljU0VLREFFTElBTkJmM05CZnlBTVFRRWdEQnNpQmlBRFNpQURRWHRLY1NJS0d5QUdhaUVNUVg5QmZpQUtHeUFGYWlFRklBUkJDSEVpQ2cwQVFYY2hCZ0pBSUFrTkFDQUhRUVJyS0FJQUlnNUZEUUJCQ2lFSlFRQWhCaUFPUVFwd0RRQURRQ0FHSWdwQkFXb2hCaUFPSUFsQkNtd2lDWEJGRFFBTElBcEJmM01oQmdzZ0J5QU5hMEVDZFVFSmJDRUpJQVZCWDNGQnhnQkdCRUJCQUNFS0lBd2dCaUFKYWtFSmF5SUdRUUFnQmtFQVNoc2lCaUFHSUF4S0d5RU1EQUVMUVFBaENpQU1JQU1nQ1dvZ0JtcEJDV3NpQmtFQUlBWkJBRW9iSWdZZ0JpQU1TaHNoREF0QmZ5RUpJQXhCL2YvLy93ZEIvdi8vL3djZ0NpQU1jaUlTRzBvTkFTQU1JQkpCQUVkcVFRRnFJUTRDUUNBRlFWOXhJaFZCeGdCR0JFQWdBMEgvLy8vL0J5QU9hMG9OQXlBRFFRQWdBMEVBU2hzaEJnd0JDeUFSSUFNZ0EwRWZkU0lHYWlBR2M2MGdFUkFxSWdaclFRRk1CRUFEUUNBR1FRRnJJZ1pCTURvQUFDQVJJQVpyUVFKSURRQUxDeUFHUVFKcklnOGdCVG9BQUNBR1FRRnJRUzFCS3lBRFFRQklHem9BQUNBUklBOXJJZ1pCLy8vLy93Y2dEbXRLRFFJTElBWWdEbW9pQXlBUVFmLy8vLzhIYzBvTkFTQUFRU0FnQWlBRElCQnFJZ1VnQkJBZklBQWdFeUFRRUI0Z0FFRXdJQUlnQlNBRVFZQ0FCSE1RSHdKQUFrQUNRQ0FWUWNZQVJnUkFJQXRCRUdvaUJrRUljaUVESUFaQkNYSWhDaUFOSUFnZ0NDQU5TeHNpQ1NFSUEwQWdDRFVDQUNBS0VDb2hCZ0pBSUFnZ0NVY0VRQ0FHSUF0QkVHcE5EUUVEUUNBR1FRRnJJZ1pCTURvQUFDQUdJQXRCRUdwTERRQUxEQUVMSUFZZ0NrY05BQ0FMUVRBNkFCZ2dBeUVHQ3lBQUlBWWdDaUFHYXhBZUlBaEJCR29pQ0NBTlRRMEFDeUFTQkVBZ0FFR1dHRUVCRUI0TElBY2dDRTBOQVNBTVFRQk1EUUVEUUNBSU5RSUFJQW9RS2lJR0lBdEJFR3BMQkVBRFFDQUdRUUZySWdaQk1Eb0FBQ0FHSUF0QkVHcExEUUFMQ3lBQUlBWWdERUVKSUF4QkNVZ2JFQjRnREVFSmF5RUdJQWhCQkdvaUNDQUhUdzBESUF4QkNVb2hBeUFHSVF3Z0F3MEFDd3dDQ3dKQUlBeEJBRWdOQUNBSElBaEJCR29nQnlBSVN4c2hDU0FMUVJCcUlnTkJDWEloRFNBRFFRaHlJUU1nQ0NFSEEwQWdEU0FITlFJQUlBMFFLaUlHUmdSQUlBdEJNRG9BR0NBRElRWUxBa0FnQnlBSVJ3UkFJQVlnQzBFUWFrME5BUU5BSUFaQkFXc2lCa0V3T2dBQUlBWWdDMEVRYWtzTkFBc01BUXNnQUNBR1FRRVFIaUFHUVFGcUlRWWdDaUFNY2tVTkFDQUFRWllZUVFFUUhnc2dBQ0FHSUEwZ0Jtc2lCaUFNSUFZZ0RFZ2JFQjRnRENBR2F5RU1JQWRCQkdvaUJ5QUpUdzBCSUF4QkFFNE5BQXNMSUFCQk1DQU1RUkpxUVJKQkFCQWZJQUFnRHlBUklBOXJFQjRNQWdzZ0RDRUdDeUFBUVRBZ0JrRUpha0VKUVFBUUh3c2dBRUVnSUFJZ0JTQUVRWURBQUhNUUh5QUNJQVVnQWlBRlNoc2hDUXdCQ3lBVElBVkJHblJCSDNWQkNYRnFJUXdDUUNBRFFRdExEUUJCRENBRGF5RUdSQUFBQUFBQUFEQkFJUmdEUUNBWVJBQUFBQUFBQURCQW9pRVlJQVpCQVdzaUJnMEFDeUFNTFFBQVFTMUdCRUFnR0NBQm1pQVlvYUNhSVFFTUFRc2dBU0FZb0NBWW9TRUJDeUFSSUFzb0Fpd2lCaUFHUVI5MUlnWnFJQVp6clNBUkVDb2lCa1lFUUNBTFFUQTZBQThnQzBFUGFpRUdDeUFRUVFKeUlRb2dCVUVnY1NFSUlBc29BaXdoQnlBR1FRSnJJZzBnQlVFUGFqb0FBQ0FHUVFGclFTMUJLeUFIUVFCSUd6b0FBQ0FFUVFoeElRWWdDMEVRYWlFSEEwQWdCeUlGQW44Z0FabEVBQUFBQUFBQTRFRmpCRUFnQWFvTUFRdEJnSUNBZ0hnTElnZEJnTThBYWkwQUFDQUljam9BQUNBQklBZTNvVVFBQUFBQUFBQXdRS0loQVFKQUlBVkJBV29pQnlBTFFSQnFhMEVCUncwQUFrQWdCZzBBSUFOQkFFb05BQ0FCUkFBQUFBQUFBQUFBWVEwQkN5QUZRUzQ2QUFFZ0JVRUNhaUVIQ3lBQlJBQUFBQUFBQUFBQVlnMEFDMEYvSVFsQi9mLy8vd2NnQ2lBUklBMXJJZ1ZxSWdacklBTklEUUFnQUVFZ0lBSWdCZ0ovQWtBZ0EwVU5BQ0FISUF0QkVHcHJJZ2hCQW1zZ0EwNE5BQ0FEUVFKcURBRUxJQWNnQzBFUWFtc2lDQXNpQjJvaUF5QUVFQjhnQUNBTUlBb1FIaUFBUVRBZ0FpQURJQVJCZ0lBRWN4QWZJQUFnQzBFUWFpQUlFQjRnQUVFd0lBY2dDR3RCQUVFQUVCOGdBQ0FOSUFVUUhpQUFRU0FnQWlBRElBUkJnTUFBY3hBZklBSWdBeUFDSUFOS0d5RUpDeUFMUWJBRWFpUUFJQWtMVmdFQmZ5TUFRVEJySWdFa0FDQUJRUWhxSUFBUkFnQkJKQkFkSWdBZ0FTZ0NLRFlDSUNBQUlBRXBBeUEzQWhnZ0FDQUJLUU1ZTndJUUlBQWdBU2tERURjQ0NDQUFJQUVwQXdnM0FnQWdBVUV3YWlRQUlBQUxCQUJDQUFzRUFFRUFDMVlCQVg4Z0FDZ0NQQ0VESXdCQkVHc2lBQ1FBSUFNZ0FhY2dBVUlnaUtjZ0FrSC9BWEVnQUVFSWFoQVJJZ0lFZjBHSTZBQWdBallDQUVGL0JVRUFDeUVDSUFBcEF3Z2hBU0FBUVJCcUpBQkNmeUFCSUFJYkMrOENBUWQvSXdCQklHc2lCQ1FBSUFRZ0FDZ0NIQ0lGTmdJUUlBQW9BaFFoQXlBRUlBSTJBaHdnQkNBQk5nSVlJQVFnQXlBRmF5SUJOZ0lVSUFFZ0Ftb2hCVUVDSVFjQ2Z3SkFBa0FnQUNnQ1BDQUVRUkJxSWdGQkFpQUVRUXhxRUFzaUF3Ui9RWWpvQUNBRE5nSUFRWDhGUVFBTFJRUkFBMEFnQlNBRUtBSU1JZ05HRFFJZ0EwRUFTQTBESUFFZ0F5QUJLQUlFSWdoTElnWkJBM1JxSWdrZ0F5QUlRUUFnQmh0cklnZ2dDU2dDQUdvMkFnQWdBVUVNUVFRZ0JodHFJZ2tnQ1NnQ0FDQUlhellDQUNBRklBTnJJUVVnQUNnQ1BDQUJRUWhxSUFFZ0Joc2lBU0FISUFacklnY2dCRUVNYWhBTElnTUVmMEdJNkFBZ0F6WUNBRUYvQlVFQUMwVU5BQXNMSUFWQmYwY05BUXNnQUNBQUtBSXNJZ0UyQWh3Z0FDQUJOZ0lVSUFBZ0FTQUFLQUl3YWpZQ0VDQUNEQUVMSUFCQkFEWUNIQ0FBUWdBM0F4QWdBQ0FBS0FJQVFTQnlOZ0lBUVFBZ0IwRUNSZzBBR2lBQ0lBRW9BZ1JyQ3lFQUlBUkJJR29rQUNBQUN3a0FJQUFvQWp3UUZRc1BBQ0FCSUFBb0FnQnFJQUk0QWdBTERRQWdBU0FBS0FJQWFpb0NBQXVkQVFFRGZ3Si9JQUFvQWdRaUFpRUFBa0FnQWtFRGNRUkFBMEFnQUMwQUFFVU5BaUFBUVFGcUlnQkJBM0VOQUFzTEEwQWdBQ0lCUVFScUlRQWdBU2dDQUNJRFFYOXpJQU5CZ1lLRUNHdHhRWUNCZ29SNGNVVU5BQXNnQVNBQ2F5QURRZjhCY1VVTkFSb0RRQ0FCTFFBQklRTWdBVUVCYWlJQUlRRWdBdzBBQ3dzZ0FDQUNhd3RCQVdvaUFCQW5JZ0VFZnlBQklBSWdBQkFhQlVFQUN3dHRBUU4vSXdCQkVHc2lBaVFBQWtBQ1FDQUFRUU5MRFFBZ0FFRUNkRUd3MlFCcUlnTW9BZ0FpQVVVTkFDQUJLQUx3QnlJQUJFQWdBQkFoQ3lBQkVDRWdBMEVBTmdJQURBRUxRY0RaQUNnQ0FDSUJSUTBBSUFJZ0FEWUNBQ0FCUWNvZElBSVFIQXNnQWtFUWFpUUFDOEVUQXdsL0FuMEJmaU1BUVRCcklnUWtBQUpBQWtCQnNOa0FLQUlBUlFSQVFiRFpBQ0VIREFFTFFiVFpBQ2dDQUVVRVFFRzAyUUFoQjBFQklRZ01BUXRCdU5rQUtBSUFSUVJBUWJqWkFDRUhRUUloQ0F3QkMwRzgyUUFvQWdCRkJFQkJ2TmtBSVFkQkF5RUlEQUVMUVg4aENFSEEyUUFvQWdBaUFFVU5BU0FFUVFRMkFnQWdBRUdSSWlBRUVCd01BUXRCK0FjUUhTRUJJQVFnQUNnQ0FEWUNDQ0FFSUFBcUFnUTRBZ3dnQkNBQUtnSUlPQUlRSUFRZ0FDb0NERGdDRkNBRUlBQW9BaEEyQWhnZ0JDQUFLZ0lVT0FJY0lBUWdBQ2dDR0RZQ0lDQUVJQUFvQWh3MkFpUWdCQ0FBS0FJZ05nSW9JQUZCZnpZQ1NDQUJRUUE2QUVRZ0FVR0FnSUQ4ZXpZQ1FDQUJRbjgzQXpnZ0FVS0FnSUQ4ZXpjRE1DQUJRb0NBZ1B4N053TW9JQUZDZ0lDQWdJQ0FnTUMvZnpjRElDQUJRdi8vLy84UE53TVlJQUZDZ0lDQS9IczNBeEFnQVVLQWdJRDhlemNEQ0NBQlFvQ0FnUHlMZ0lEQXYzODNBd0FnQVVJQU53Q25BU0FCUWdBM0FxQUJJQUZDQURjQ21BRWdBVUlBTndLUUFTQUJRZ0EzQW9nQklBRkNBRGNDZ0FFZ0FVSUFOd0o0SUFGQ0FEY0NjQ0FCUVFBMkF0Z0JJQUZDQURjQzBBRWdBVUlBTndMSUFTQUJRZ0EzQXNBQklBRkNBRGNDdUFFZ0FVSUFOd0t3QVNBQlFRQTJBa3dnQVVFQU9nQlFJQUZDQURjQ1ZDQUJRZ0EzQWx3Z0FVSUFOd0prSUFGQkFEc0JiQ0FCUWZRRGFrRUFRY0VBRUJzYUlBRkNBRGNDdkFRZ0FVSE5tYlB1QXpZQ3VBUWdBVUlBTndMRUJDQUJRZ0EzQXN3RUlBRkNBRGNDMUFRZ0FVSUFOd0xjQkNBQlFnQTNBdVFFSUFGQ0FEY0M3QVFnQVVJQU53S0lCeUFCUWdBM0FwQUhJQUZDQURjQ21BY2dBVUlBTndLZ0J5QUJRZ0EzQXFnSElBRkJBRFlDc0FjZ0FVSUFOd0s0QnlBQlFnQTNBc0FISUFGQ0FEY0N5QWNnQVVJQU53TFFCeUFCUWdBM0F0Z0hJQUZCQURZQzRBY2dBVUlBTndQd0J5QUJRZ0EzQStnSEl3QkJrQUZySWdVa0FDQUJLQUx3QnlJQUJFQWdBQkFoSUFGQ0FEY0Q4QWNMSUFFZ0JDb0NERGdDQUNBQklBUXFBaEE0QWdRZ0FTQUVLZ0lVT0FJSUlBRWdCQ2dDR0NJQU5nSU1JQUZEQUFDQVB5QUFzcFU0QWhBQ1FDQUVLQUlnSWdKQkJrOEVRRUVBSVFCQndOa0FLQUlBSWdORkRRRWdCU0FDTmdLQUFTQURRYnNnSUFWQmdBRnFFQndNQVFzZ0FrRUNkRUh3TG1vb0FnQWhBQXNnQVNBQU5nSVVRUUVoQWlBRUtBSWtJZ01oQUFKQUFrQUNRQUpBQWtBZ0F3NEdCQUFBQVFFQ0F3dEJBU0VBUVFBaEFnd0RDMEVDSVFCQkFDRUNEQUlMUVFRaEFFRUFJUUlNQVF0QkFDRUFRY0RaQUNnQ0FDSUNCRUFnQlNBRE5nSndJQUpCdXlBZ0JVSHdBR29RSENBRUtBSWtJUU1MUVFFaEFnc2dBU0FBTmdJWUlBUW9BaUFoQmlBQklBTTJBaUFnQVNBR05nSWNJQUZCRURZQ05DQUJRUUUyQWl3Z0FTQUJLZ0lJSWdzZ0FTZ0NETEtWSWdvNEFpUWdBU0FLSUFxU09BSXdJQUZEQUFDQVB5QUtsVGdDS0NBQklBUW9BZ2dpQUVFQVRFRUVkRFlDT0NBQlFRQkJBeUFBUVFCS0lna2JOZ0k4SUFRcUFod2hDaUFCSUFBMkFrZ2dBU0FLT0FKQUlBRWdDVG9BUkNBQklBUW9BaWhCL3dGeElnQkJBWFpCQVhFNkFFd2dBU0FBUVFKMlFRRnhPZ0JOSUFFZ0FTb0NBQ0lLSUF0YkJIOGdBU29DQkNBTFhBVkJBUXM2QUU0Z0FTQUFRUVIyUVFGeE9nQlFJQUVnQUVFRGRrRUJjVG9BVHdKQUlBRW9BaFJGQkVCQndOa0FLQUlBSWdCRkRRRWdCU0FHTmdJQUlBQkJpU0FnQlJBY0RBRUxJQUlFUUVIQTJRQW9BZ0FpQUVVTkFTQUZJQU0yQWhBZ0FFSFdIeUFGUVJCcUVCd01BUXNnQkNnQ0dDSUFRWUVJVGdSQVFjRFpBQ2dDQUNJQ1JRMEJJQVZCZ0FnMkFpUWdCU0FBTmdJZ0lBSkJyaDhnQlVFZ2FoQWNEQUVMSUFwREFBQjZSRjBFUUVIQTJRQW9BZ0FpQUVVTkFTQUZRb0NBZ0lDQWdOREh3QUEzQXpnZ0JTQUt1emtETUNBQVFaOFlJQVZCTUdvUVNnd0JDeUFLUXdDQXUwZGVCRUJCd05rQUtBSUFJZ0JGRFFFZ0JVS0FnSUNBZ0lEYys4QUFOd05JSUFVZ0NyczVBMEFnQUVIVUdDQUZRVUJyRUVvTUFRc2dBVUlBTndQd0J5QUJRUUFnQVVIMEIyb2lBQkJSUlFSQVFjRFpBQ2dDQUNJQVJRMEJRWWtaUVRrZ0FCQW9EQUVMQWtBQ2YwRUFJQUVvQXZRSElnTWlBa1VOQUJvZ0FxMGlES2NpQmlBQ1FRRnlRWUNBQkVrTkFCcEJmeUFHSUF4Q0lJaW5Hd3NpQmhBbklnSkZEUUFnQWtFRWF5MEFBRUVEY1VVTkFDQUNRUUFnQmhBYkdnc2dBVUVBTmdMMEJ5QUJJQUkyQXZBSElBRWdBaUFBRUZGRkJFQkJ3TmtBS0FJQUlnSkZEUUVnQlNBQUtBSUFOZ0pnSUFKQjFoNGdCVUhnQUdvUUhBd0JDeUFBS0FJQUlnQWdBMGNFUUVIQTJRQW9BZ0FpQWtVTkFTQUZJQUEyQWxRZ0JTQUROZ0pRSUFKQjdpQWdCVUhRQUdvUUhBd0JDeUFCTFFCTUJFQWdBU0FCS0FJTU5nS1FBU0FCS0FLY0FVRUFOZ0lBSUFGQkFEc0I1QUVnQVVJQU53TGNBU0FCUVJZMkF1Z0JBa0JCNU4wQUxRQUFRUUZ4RFFCQjVOMEFFQ05GRFFCQjNOc0FFQ1pCaUFJUUdocEI1TjBBRUNJTElBRkI3QUZxUWR6YkFFR0lBaEFhSVFBZ0FTQUJLQUlNSWdJZ0FDNEJCQ0lESUFJZ0EwZ2JJQUlnQUMwQUNSc2lBaUFBTGdFUUlnTWdBaUFEU0JzZ0FpQUFMUUFWR3lJQ0lBQXVBUndpQXlBQ0lBTklHeUFDSUFBdEFDRWJJZ0lnQUM0QktDSURJQUlnQTBnYklBSWdBQzBBTFJzaUFpQUFMZ0UwSWdNZ0FpQURTQnNnQWlBQUxRQTVHeUlDSUFCQlFHc3VBUUFpQXlBQ0lBTklHeUFDSUFBdEFFVWJJZ0lnQUM0QlRDSURJQUlnQTBnYklBSWdBQzBBVVJzaUFpQUFMZ0ZZSWdNZ0FpQURTQnNnQWlBQUxRQmRHeUlDSUFBdUFXUWlBeUFDSUFOSUd5QUNJQUF0QUdrYklnSWdBQzRCY0NJRElBSWdBMGdiSUFJZ0FDMEFkUnNpQWlBQUxnRjhJZ01nQWlBRFNCc2dBaUFBTFFDQkFSc2lBaUFBTGdHSUFTSURJQUlnQTBnYklBSWdBQzBBalFFYklnSWdBQzRCbEFFaUF5QUNJQU5JR3lBQ0lBQXRBSmtCR3lJQ0lBQXVBYUFCSWdNZ0FpQURTQnNnQWlBQUxRQ2xBUnNpQWlBQUxnR3NBU0lESUFJZ0EwZ2JJQUlnQUMwQXNRRWJJZ0lnQUM0QnVBRWlBeUFDSUFOSUd5QUNJQUF0QUwwQkd5SUNJQUF1QWNRQklnTWdBaUFEU0JzZ0FpQUFMUURKQVJzaUFpQUFMZ0hRQVNJRElBSWdBMGdiSUFJZ0FDMEExUUViSWdJZ0FDNEIzQUVpQXlBQ0lBTklHeUFDSUFBdEFPRUJHeUlDSUFBdUFlZ0JJZ01nQWlBRFNCc2dBaUFBTFFEdEFSc2lBaUFBTGdIMEFTSURJQUlnQTBnYklBSWdBQzBBK1FFYklnSWdBQzRCZ0FJaUF5QUNJQU5JR3lBQ0lBQXRBSVVDR3pZQ2ZBc2dBUzBBVFFSQUFrQkIyTnNBTFFBQVFRRnhEUUJCMk5zQUVDTkZEUUJCME5rQUVDWkJpQUlRR2hwQjJOc0FFQ0lMSUFGQmdBVnFRZERaQUVHSUFoQWFHZ3NnQVVFQVFZb2xRUUJCQUJCVEdnc2dCVUdRQVdva0FDQUhJQUUyQWdBTElBUkJNR29rQUNBSUN6NEFJQUJCMk5RQUtBSUFOZ0lnSUFCQjBOUUFLUUlBTndJWUlBQkJ5TlFBS1FJQU53SVFJQUJCd05RQUtRSUFOd0lJSUFCQnVOUUFLUUlBTndJQUM1RUxBaFY5REg4Z0FVRUFTZ1JBQTBBZ0FpQUJJQmxxSWgwZ0FXb2lHMEVDZEdvaUdrRUVhaW9DQUNFS0lBSWdBU0FiYWtFQ2RHb2lIa0VFYWlvQ0FDRU1JQUlnR1VFQ2RDSWJRUVJ5YWlJaUtnSUFJUTBnQWlBZFFRSjBhaUlkUVFScUtnSUFJUTRnQWlBYmFpSWJJQnNxQWdBaUR5QWRLZ0lBSWhDU0lnWWdHaW9DQUNJSUlCNHFBZ0FpQ1pJaUI1STRBZ0FnSWlBTklBNlNJZ1VnQ2lBTWtpSUVramdDQUNBYUlBVWdCSk00QWdRZ0dpQUdJQWVUT0FJQUlCMGdEU0FPa3lJR0lBZ2dDWk1pQjVJNEFnUWdIU0FQSUJDVElnVWdDaUFNa3lJRWt6Z0NBQ0FlSUFZZ0I1TTRBZ1FnSGlBRklBU1NPQUlBSUJsQkFtb2lHU0FCU0EwQUN3c2dBVUVDZENJaUlBRkJCV3dpSVVnRVFDQURLZ0lJSVFzZ0lpRVpBMEFnQWlBQklCbHFJaDBnQVdvaUcwRUNkR29pSEVFRWFpb0NBQ0VLSUFJZ0FTQWJha0VDZEdvaUdrRUVhaW9DQUNFTUlBSWdHVUVDZENJYlFRUnlhaUllS2dJQUlRMGdBaUFkUVFKMGFpSWRRUVJxS2dJQUlRNGdBaUFiYWlJYklCc3FBZ0FpRHlBZEtnSUFJaENTSWdnZ0hDb0NBQ0lKSUJvcUFnQWlCcElpQjVJNEFnQWdIaUFOSUE2U0lnVWdDaUFNa2lJRWtqZ0NBQ0FjSUFnZ0I1TTRBZ1FnSENBRUlBV1RPQUlBSUIwZ0N5QU5JQTZUSWdnZ0NTQUdreUlKa2lJRklBOGdFSk1pQmlBS0lBeVRJZ2VUSWdTU2xEZ0NCQ0FkSUFzZ0JDQUZrNVE0QWdBZ0dpQUxJQWtnQ0pNaUJTQUdJQWVTSWdTU2xEZ0NCQ0FhSUFzZ0JTQUVrNVE0QWdBZ0dVRUNhaUlaSUNGSURRQUxDeUFBSUFGQkEzUWlIVW9FUUVFQUlSa2dIU0ViQTBBZ0F5QVpRUUpxSWg1QkFuUnFLZ0lBSVJNZ0dVRUNkQ0FEYWlvQ0RDSVJqQ0VZSUFGQkFFd2lKRVVFUUNBRElCNUJBM1JxSWhrcUFnQWlFaUFSSUJHU0lnUWdHU29DQkNJVWxKTWhGU0FFSUJLVUlCU1RJZ3lNSVEwZ0FTQWJhaUVqSUJTTUlRNGdHeUVaQTBBZ0FpQUJJQmxxSWh3Z0FXb2lHa0VDZEdvaUgwRUVhaW9DQUNFV0lBSWdBU0FhYWtFQ2RHb2lJRUVFYWlvQ0FDRVhJQUlnR1VFQ2RDSWFRUVJ5YWlJaEtnSUFJUXNnQWlBY1FRSjBhaUljUVFScUtnSUFJUW9nQWlBYWFpSWFJQm9xQWdBaUR5QWNLZ0lBSWhDU0lnZ2dIeW9DQUNJSklDQXFBZ0FpQnBJaUI1STRBZ0FnSVNBTElBcVNJZ1VnRmlBWGtpSUVramdDQUNBZklCTWdCU0FFa3lJRmxDQVJJQWdnQjVNaUJKU1NPQUlFSUI4Z0V5QUVsQ0FGSUJpVWtqZ0NBQ0FjSUJJZ0N5QUtreUlJSUFrZ0JwTWlDWklpQlpRZ0ZDQVBJQkNUSWdZZ0ZpQVhreUlIa3lJRWxKSTRBZ1FnSENBU0lBU1VJQVVnRHBTU09BSUFJQ0FnRlNBSUlBbVRJZ1dVSUF3Z0JpQUhraUlFbEpJNEFnUWdJQ0FWSUFTVUlBVWdEWlNTT0FJQUlCbEJBbW9pR1NBalNBMEFDd3NnSkVVRVFDQURJQjVCQTNRaUdVRUljbW9xQWdBaUVTQVRJQk9TSWdRZ0F5QVpRUXh5YWlvQ0FDSVNsSk1oRkNBRUlCR1VJQktUSWdxTUlRd2dHeUFpYWlJWklBRnFJU01nRW93aERTQVRqQ0VPQTBBZ0FpQUJJQmxxSWh3Z0FXb2lHa0VDZEdvaUgwRUVhaW9DQUNFVklBSWdBU0FhYWtFQ2RHb2lJRUVFYWlvQ0FDRVdJQUlnR1VFQ2RDSWFRUVJ5YWlJaEtnSUFJUmNnQWlBY1FRSjBhaUljUVFScUtnSUFJUXNnQWlBYWFpSWFJQm9xQWdBaUR5QWNLZ0lBSWhDU0lnZ2dIeW9DQUNJSklDQXFBZ0FpQnBJaUI1STRBZ0FnSVNBWElBdVNJZ1VnRlNBV2tpSUVramdDQUNBZklCZ2dCU0FFa3lJRmxDQVRJQWdnQjVNaUJKU1NPQUlFSUI4Z0dDQUVsQ0FGSUE2VWtqZ0NBQ0FjSUJFZ0Z5QUxreUlJSUFrZ0JwTWlDWklpQlpRZ0VpQVBJQkNUSWdZZ0ZTQVdreUlIa3lJRWxKSTRBZ1FnSENBUklBU1VJQVVnRFpTU09BSUFJQ0FnRkNBSUlBbVRJZ1dVSUFvZ0JpQUhraUlFbEpJNEFnUWdJQ0FVSUFTVUlBVWdESlNTT0FJQUlCbEJBbW9pR1NBalNBMEFDd3NnSGlFWklCc2dIV29pR3lBQVNBMEFDd3NMNWdnQ0VIMExmeUFCSUFFcUFnUWlCeUFCS2dJTUlnU1NJZ01nQVNvQ0ZDSUlJQUVxQWh3aUJwSWlDWk00QWhRZ0FTQUJLZ0lBSWdvZ0FTb0NDQ0lGa2lJTUlBRXFBaEFpRFNBQktnSVlJZ3VTSWcrVE9BSVFJQUVnQXlBSmtqZ0NCQ0FCSUF3Z0Q1STRBZ0FnQVNBSElBU1RJZ2NnRFNBTGt5SUVremdDSENBQklBb2dCWk1pQXlBSUlBYVRJZ2lTT0FJWUlBRWdCeUFFa2pnQ0RDQUJJQU1nQ0pNNEFnZ2dBaW9DQ0NFSElBRWdBU29DSUNJSklBRXFBaWdpQ3BJaUJTQUJLZ0l3SWd3Z0FTb0NPQ0lOa2lJTGtqZ0NJQ0FCS2dJMElRUWdBU29DUENFRElBRXFBaVFoQ0NBQktnSXNJUVlnQVNBRklBdVRPQUkwSUFFZ0JDQURraUlGSUFnZ0JwSWlDNU00QWpBZ0FTQUxJQVdTT0FJa0lBRWdCeUFNSUEyVElnVWdDQ0FHa3lJSWt5SUdJQWtnQ3BNaUNTQUVJQU9USWdTU0lnT1NsRGdDUENBQklBY2dCaUFEazVRNEFqZ2dBU0FISUFnZ0JaSWlBeUFKSUFTVElnU1NsRGdDTENBQklBY2dCQ0FEazVRNEFpZ2dBRUVSVGdSQVFSQWhHQU5BSUFJZ0UwRUNhaUliUVFOMEloZHFJaFFxQWdBaEF5QVVLZ0lFSVFnZ0FpQWJRUUowYWlvQ0FDRUhJQk5CQW5RZ0Ftb3FBZ3doQkNBQklCaEJBblFpRTBFTWNtb2lGQ29DQUNFR0lBRWdFMEVFY21vaUdTb0NBQ0VKSUFFZ0UwRWNjbW9pR2lvQ0FDRUtJQUVnRTBFVWNtb2lGU29DQUNFRklBRWdFMm9pRmlBV0tnSUFJZ3dnQVNBVFFRaHlhaUlXS2dJQUlnMlNJZ3NnQVNBVFFSQnlhaUljS2dJQUlnOGdBU0FUUVJoeWFpSWRLZ0lBSWhDU0lnNlNPQUlBSUJrZ0NTQUdraUlSSUFVZ0NwSWlFcEk0QWdBZ0hDQUhJQXNnRHBNaUM1UWdCQ0FSSUJLVElnNlVremdDQUNBVklBY2dEcFFnQkNBTGxKSTRBZ0FnRmlBRElBd2dEWk1pRENBRklBcVRJZ3FUSWdXVUlBZ2dDU0FHa3lJR0lBOGdFSk1pQ1pJaURaU1RPQUlBSUJRZ0F5QU5sQ0FJSUFXVWtqZ0NBQ0FkSUFNZ0NDQUVJQVNTSWdXVWt5SU5JQXdnQ3BJaUNwUWdCaUFKa3lJR0lBVWdBNVFnQ0pNaUE1U1RPQUlBSUJvZ0RTQUdsQ0FESUFxVWtqZ0NBQ0FDSUJkQkNISnFLZ0lBSVFNZ0FpQVhRUXh5YWlvQ0FDRUlJQUVnRTBFc2Ntb2lGeW9DQUNFR0lBRWdFMEVrY21vaUZDb0NBQ0VKSUFFZ0UwRThjbW9pR1NvQ0FDRUtJQUVnRTBFMGNtb2lHaW9DQUNFRklBRWdFMEVnY21vaUZTQVZLZ0lBSWd3Z0FTQVRRU2h5YWlJVktnSUFJZzJTSWdzZ0FTQVRRVEJ5YWlJV0tnSUFJZzhnQVNBVFFUaHlhaUlUS2dJQUloQ1NJZzZTT0FJQUlCUWdDU0FHa2lJUklBVWdDcElpRXBJNEFnQWdGaUFFakNBTElBNlRJZ3VVSUFjZ0VTQVNreUlPbEpNNEFnQWdHaUFISUF1VUlBUWdEcFNUT0FJQUlCVWdBeUFNSUEyVElnUWdCU0FLa3lJS2t5SUZsQ0FJSUFrZ0JwTWlCaUFQSUJDVElnbVNJZ3lVa3pnQ0FDQVhJQU1nREpRZ0NDQUZsSkk0QWdBZ0V5QURJQWdnQnlBSGtpSUhsSk1pQlNBRUlBcVNJZ1NVSUFZZ0NaTWlCaUFISUFPVUlBaVRJZ2VVa3pnQ0FDQVpJQVVnQnBRZ0J5QUVsSkk0QWdBZ0d5RVRJQmhCRUdvaUdDQUFTQTBBQ3dzTEd3QkJsTmNBS0FJQUlnQUVRRUdZMXdBZ0FEWUNBQ0FBRUNFTEN3c0FJQUFFUUNBQUVDRUxDejRBQWtCQjJOc0FMUUFBUVFGeERRQkIyTnNBRUNORkRRQkIwTmtBRUNaQmlBSVFHaHBCMk5zQUVDSUxJQUJCREd4QjJka0FhaUFCUVFCSE9nQUFDejRBQWtCQjVOMEFMUUFBUVFGeERRQkI1TjBBRUNORkRRQkIzTnNBRUNaQmlBSVFHaHBCNU4wQUVDSUxJQUJCREd4QjVkc0FhaUFCUVFCSE9nQUFDd3NBSUFFZ0FpQUFFUWdBQ3hBQVFjRFpBRUdneXdBb0FnQTJBZ0FMQ3dCQndOa0FRUUEyQWdBTEJ3QWdBQkVIQUF1alpRTWtmd2w5QW53akFFRVFheUlaSkFBZ0FBSi9JQUlvQWdBZ0FpQUNMUUFMSWdCQkdIUkJHSFZCQUVnaUJ4c2hIU0FDS0FJRUlBQWdCeHNoSGlNQVFSQnJJaUVrQUNBQlFRSjBRYkRaQUdvb0FnQWhCQ01BUVJCckloOGtBQUpBSUFRdEFFeEZCRUJCd05rQUtBSUFJZ0JGRFFGQnl4cEJQeUFBRUNnTUFRc2dCQzBBdEFRRVFFSEEyUUFvQWdBaUFFVU5BVUhvR1VFaElBQVFLQXdCQ3lBRVFiZ0hhaUVsSUFRcUFnQWdCQ29DQ0pVaUxVTUFBSEJDbENFdVF3QUFnRDhnTFpVaEx5QUVLQUtRQVNFQUEwQkJBU0VESUI0Q2Z5QUVMUUJPUlFSQUlBUW9BaFFnQUd3TUFRc2dKU0F2SUFBZ0JDZ0N3QUZCQUJBd1FRUnFJQVFvQWhSc0N5SUFJQUFnSGtzYklocEZEUUVDUUNBRUtBSWNJZ0JCQVd0QkJFOEVRQ0FBUVFWSERRRWdCQ2dDd0FFZ0hTQWFFQm9hREFFTElBUW9Bc2dCSUIwZ0doQWFHZ3NnR2lBRUtBSVVJZ0J1SWhBZ0FHd2dHa2NFUUVIQTJRQW9BZ0FpQWdSQUlCOGdBRFlDQkNBZklCbzJBZ0FnQWtIZUlpQWZFQndMSUFRZ0JDZ0NERFlDa0FFTUFnc0NRQUpBQWtBQ1FBSkFJQVFvQWh4QkFXc09CQUFCQWdNRUN5QVFRUUJNRFFNZ0JDZ0N5QUVoQWlBRUtBTEFBU0VGUVFBaEFDQVFRUUZIQkVBZ0VFRitjU0VJUVFBaEJ3TkFJQVVnQUVFQ2RHb2dBQ0FDYWkwQUFFR0FBV3V5UXdBQUFEeVVPQUlBSUFVZ0FFRUJjaUlNUVFKMGFpQUNJQXhxTFFBQVFZQUJhN0pEQUFBQVBKUTRBZ0FnQUVFQ2FpRUFJQWRCQW1vaUJ5QUlSdzBBQ3dzZ0VFRUJjVVVOQXlBRklBQkJBblJxSUFBZ0Ftb3RBQUJCZ0FGcnNrTUFBQUE4bERnQ0FBd0RDeUFRUVFCTURRSWdCQ2dDeUFFaEFpQUVLQUxBQVNFSVFRQWhCMEVBSVFBZ0VFRUJhMEVEVHdSQUlCQkJmSEVoREVFQUlRVURRQ0FJSUFCQkFuUnFJQUFnQW1vc0FBQ3lRd0FBQUR5VU9BSUFJQWdnQUVFQmNpSUdRUUowYWlBQ0lBWnFMQUFBc2tNQUFBQThsRGdDQUNBSUlBQkJBbklpQmtFQ2RHb2dBaUFHYWl3QUFMSkRBQUFBUEpRNEFnQWdDQ0FBUVFOeUlnWkJBblJxSUFJZ0Jtb3NBQUN5UXdBQUFEeVVPQUlBSUFCQkJHb2hBQ0FGUVFScUlnVWdERWNOQUFzTElCQkJBM0VpQlVVTkFnTkFJQWdnQUVFQ2RHb2dBQ0FDYWl3QUFMSkRBQUFBUEpRNEFnQWdBRUVCYWlFQUlBZEJBV29pQnlBRlJ3MEFDd3dDQ3lBUVFRQk1EUUVnQkNnQ3lBRWhBaUFFS0FMQUFTRUZRUUFoQUNBUVFRRkhCRUFnRUVGK2NTRUlRUUFoQndOQUlBVWdBRUVDZEdvZ0FpQUFRUUYwYWk4QkFFR0FnQUpyc2tNQUFBQTRsRGdDQUNBRklBQkJBWElpREVFQ2RHb2dBaUFNUVFGMGFpOEJBRUdBZ0FKcnNrTUFBQUE0bERnQ0FDQUFRUUpxSVFBZ0IwRUNhaUlISUFoSERRQUxDeUFRUVFGeFJRMEJJQVVnQUVFQ2RHb2dBaUFBUVFGMGFpOEJBRUdBZ0FKcnNrTUFBQUE0bERnQ0FBd0JDeUFRUVFCTURRQWdCQ2dDeUFFaEFpQUVLQUxBQVNFSVFRQWhCMEVBSVFBZ0VFRUJhMEVEVHdSQUlCQkJmSEVoREVFQUlRVURRQ0FJSUFCQkFuUnFJQUlnQUVFQmRHb3VBUUN5UXdBQUFEaVVPQUlBSUFnZ0FFRUJjaUlHUVFKMGFpQUNJQVpCQVhScUxnRUFza01BQUFBNGxEZ0NBQ0FJSUFCQkFuSWlCa0VDZEdvZ0FpQUdRUUYwYWk0QkFMSkRBQUFBT0pRNEFnQWdDQ0FBUVFOeUlnWkJBblJxSUFJZ0JrRUJkR291QVFDeVF3QUFBRGlVT0FJQUlBQkJCR29oQUNBRlFRUnFJZ1VnREVjTkFBc0xJQkJCQTNFaUJVVU5BQU5BSUFnZ0FFRUNkR29nQWlBQVFRRjBhaTRCQUxKREFBQUFPSlE0QWdBZ0FFRUJhaUVBSUFkQkFXb2lCeUFGUncwQUN3c2dCQ2dDRENJQ0lBUW9BcEFCYXlFSEFrQWdCQzBBVGtVRVFDQVFRUUJNRFFFZ0JDZ0N1QUVoQ0NBRUtBTEFBU0VNUVFBaEJVRUFJUUFnRUVFQmEwRURUd1JBSUJCQmZIRWhDa0VBSVFZRFFDQUlJQUFnQjJwQkFuUnFJQXdnQUVFQ2RHb3FBZ0E0QWdBZ0NDQUFRUUZ5SWdrZ0IycEJBblJxSUF3Z0NVRUNkR29xQWdBNEFnQWdDQ0FBUVFKeUlna2dCMnBCQW5ScUlBd2dDVUVDZEdvcUFnQTRBZ0FnQ0NBQVFRTnlJZ2tnQjJwQkFuUnFJQXdnQ1VFQ2RHb3FBZ0E0QWdBZ0FFRUVhaUVBSUFaQkJHb2lCaUFLUncwQUN3c2dFRUVEY1NJR1JRMEJBMEFnQ0NBQUlBZHFRUUowYWlBTUlBQkJBblJxS2dJQU9BSUFJQUJCQVdvaEFDQUZRUUZxSWdVZ0JrY05BQXNNQVFzZ0VFR0FBVXdFUUNBRUlBSTJBcEFCREFNTEFrQWdCQzBBYkEwQUlBUW9BdGdIc2lBdUlBUXFBZ2lVWGtVTkFDQUVRZ0EzQStnSElBUkNBRGNENEFjZ0JFSUFOd1BZQnlBRUtBTElCMEVBSUFRb0Fzd0hRUUowRUJzYUlBUW9Bc0FIUVFBZ0JDZ0N4QWRCQW5RUUd4b2dCQ2dDMEFkQkFDQUVLQUxVQjBFQ2RCQWJHZ3NnSlNBdElCQWdCQ2dDd0FFZ0JDZ0N1QUVnQjBFQ2RHb1FNQ0FIYWlFUUlBUW9BZ3doQWdzZ0FpQVFUQVJBSUFSQkFUb0FyZ0VDUUNBRUxRQkVCRUJCQUNFR1FRQWhDVUVBSVE0akFFR0FBbXNpQlNRQUlBUkJBVG9BclFFZ0JDZ0NuQUVoQUNBRUtBS2tBU0VDSUFRb0Fnd2lCeUFFS0FLVUFTQUVLQUs0QVNBSFFRSjBFQm9nQUNBQ0VEMUJBQ0VDQWtBZ0JDZ0NEQ0lBUVFCTUJFQWdCRUdnQkdvaEdDQUVRWmdFYWlFYkRBRUxJQVFvQXJBQklRY2dCQ2dDbEFFaENDQUFRUUZIQkVBZ0FFRitjU0VNQTBBZ0J5QUNRUUowYWlBSUlBSkJBM1JxSWdNcUFnQWlKeUFubENBREtnSUVJaWNnSjVTU09BSUFJQWNnQWtFQmNpSURRUUowYWlBSUlBTkJBM1JxSWdNcUFnQWlKeUFubENBREtnSUVJaWNnSjVTU09BSUFJQUpCQW1vaEFpQUdRUUpxSWdZZ0RFY05BQXNMSUFCQkFYRUVRQ0FISUFKQkFuUnFJQWdnQWtFRGRHb2lBaW9DQUNJbklDZVVJQUlxQWdRaUp5QW5sSkk0QWdBTFF3QUFBQUFoSndKQUlBQkJCRWdOQUVFQklRSWdBRUVCZGlJTVFRRnJJZ1pCQVhFaEF5QUVLQUo4SVFnZ0JDZ0NzQUVoQnlBTVFRSkhCRUFnQmtGK2NTRUdBMEFnQnlBQ1FRSjBhaUlNSUFjZ0FDQUNhMEVDZEdvcUFnQWdEQ29DQUpJaUtEZ0NBQ0FISUFKQkFXb2lERUVDZEdvaUNpQUhJQUFnREd0QkFuUnFLZ0lBSUFvcUFnQ1NJaWs0QWdBZ0p5QW9JQ2NnS0dBYklDY2dBaUFJVGhzaUp5QXBJQ2NnS1dBYklDY2dDQ0FNVEJzaEp5QUNRUUpxSVFJZ0NVRUNhaUlKSUFaSERRQUxDeUFEUlEwQUlBY2dBa0VDZEdvaURDQUhJQUFnQW10QkFuUnFLZ0lBSUF3cUFnQ1NJaWc0QWdBZ0p5QW9JQ2NnS0dBYklDY2dBaUFJVGhzaEp3c2dCRUdnQkdvaEdDQUVRWmdFYWlFYlFRQWhBaUFBUVFCTURRQkRBQUIvUTBNQUFIOURJQ2VWSUNkREFBQUFBRnNiSVNrRFFDQUVLQUtZQkNBRUtBS2dCQ0FFS0FLVUJHeHFJQUpxQW44Q2ZTQXBJQVFvQXJBQklBSkJBblJxS2dJQWxDSW52Q0lBUVJkMlFmOEJjU0lIUVpVQlRRUkFJQWRCL1FCTkJIMGdKME1BQUFBQWxBVUNmU0FuSUNlTUlBQkJBRTRiSWlkREFBQUFTNUpEQUFBQXk1SWdKNU1pS0VNQUFBQS9YZ1JBSUNjZ0tKSkRBQUNBdjVJTUFRc2dKeUFva2lJbklDaERBQUFBdjE5RkRRQWFJQ2REQUFDQVA1SUxJaWNnSjR3Z0FFRUFUaHNMSVNjTFF3QUFBQUFnSjBNQUFBQUFYdzBBR2tNQUFIOURJQ2REQUFCL1ExNE5BQm9nSndzaUowTUFBSUJQWFNBblF3QUFBQUJnY1FSQUlDZXBEQUVMUVFBTE9nQUFJQUpCQVdvaUFpQUVLQUlNU0EwQUN3c2dCQ0FFS0FLVUJFRUJhaUlBUVFBZ0FDQUVLQUtjQkVnYk5nS1VCQ0FGUVRCcUlRd0RRQUpBQWtBZ0JDQU9RUXhzYWlJSUxRRDFBVVVOQUNBSUxnSHdBU0lpSUFRb0FneEtEUUFnQkNnQ2xBUWdDQ3dBOUFFaUJ3Si9RUUlnQkNnQ1NDSVdRUVJJRFFBYVFRUWdGa0VQU1EwQUdpQVdRUVZ1UVFGMEN5SWNJQlpxSWhFZ0NDd0E4d0VpQW1wQkFXc2dBbTFzSWlBZ0NDd0E4Z0ZzYXlJU1FRQklCRUFnQkNnQ25BUWdFbW9oRWd0QkFDRUFJQVFvQXFRRVFRQWdCQ2dDcUFRUUd4b0NRQ0FnUVFCTUJFQkJBQ0VYUVFBaERRd0JDeUFIUVFGR1FRUjBJU01nQWtFRmRDRW1RUUFoRFVFQUlSY0RRQ0FBSUFnc0FQUUJiMFVFUUNBRUtBS3NCRUVBSUNZUUd4b0xJQUJCQVdvaEJ5QUlMUUR5QVNJS1FSaDBRUmgxSWdOQkFFb0VRQ0FJTFFEekFTRUNRUUFoQmdOQUlBSkJHSFJCR0hWQkFFb0VRQ0FHSUJKcUlBQWdDbXhxSWdKQkFDQUVLQUtjQkNJRElBSWdBMGdiYXlFa1FRQWhDZ05BSUJzb0FnQWdHQ2dDQUNBa2JHb2lEeUFLUVFWMElnTWdJbW9pRTJvaUFpMEFBQ0lKSUFJdEFBRWlDMDFCQWlBSklBc2dDU0FMU3hzaUNTQUNMUUFDSWd0TEloUWJRUU1nQ1NBTElCUWJJZ2tnQWkwQUF5SUxTeUlVRzBFRUlBa2dDeUFVR3lJSklBSXRBQVFpQzBzaUZCdEJCU0FKSUFzZ0ZCc2lDU0FDTFFBRklndExJaFFiUVFZZ0NTQUxJQlFiSWdrZ0FpMEFCaUlMU3lJVUcwRUhJQUl0QUFjaUZTQUpJQXNnRkJzaUNVSC9BWEZKSWdzYlFRZ2dBaTBBQ0NJVUlBa2dGU0FMR3lJSlFmOEJjVWtpQ3h0QkNTQUNMUUFKSWhVZ0NTQVVJQXNiSWdsQi93RnhTU0lMRzBFS0lBSXRBQW9pRkNBSklCVWdDeHNpQ1VIL0FYRkpJZ3NiUVFzZ0FpMEFDeUlWSUFrZ0ZDQUxHeUlKUWY4QmNVa2lDeHRCRENBQ0xRQU1JaFFnQ1NBVklBc2JJZ2xCL3dGeFNTSUxHMEVOSUFJdEFBMGlGU0FKSUJRZ0N4c2lDVUgvQVhGSklnc2JRUTRnQWkwQURpSVVJQWtnRlNBTEd5SUpRZjhCY1VraUN4dEJEeUFDTFFBUElBa2dGQ0FMRzBIL0FYRkpHeUlVSVFJZ0NDd0E5QUVpQ1VFQlJnUkFJQThnRXlBamFtb2lBaTBBQUNJTElBSXRBQUVpRDAxQkFpQUxJQThnQ3lBUFN4c2lDeUFDTFFBQ0lnOUxJaE1iUVFNZ0N5QVBJQk1iSWdzZ0FpMEFBeUlQU3lJVEcwRUVJQXNnRHlBVEd5SUxJQUl0QUFRaUQwc2lFeHRCQlNBTElBOGdFeHNpQ3lBQ0xRQUZJZzlMSWhNYlFRWWdDeUFQSUJNYklnc2dBaTBBQmlJUFN5SVRHMEVISUFJdEFBY2lGU0FMSUE4Z0V4c2lDMEgvQVhGSklnOGJRUWdnQWkwQUNDSVRJQXNnRlNBUEd5SUxRZjhCY1VraUR4dEJDU0FDTFFBSkloVWdDeUFUSUE4YklndEIvd0Z4U1NJUEcwRUtJQUl0QUFvaUV5QUxJQlVnRHhzaUMwSC9BWEZKSWc4YlFRc2dBaTBBQ3lJVklBc2dFeUFQR3lJTFFmOEJjVWtpRHh0QkRDQUNMUUFNSWhNZ0N5QVZJQThiSWd0Qi93RnhTU0lQRzBFTklBSXRBQTBpRlNBTElCTWdEeHNpQzBIL0FYRkpJZzhiUVE0Z0FpMEFEaUlUSUFzZ0ZTQVBHeUlMUWY4QmNVa2lEeHRCRHlBQ0xRQVBJQXNnRXlBUEcwSC9BWEZKR3lFQ0N5QUhJQUFnQ1c4RWZ5QUpCU0FFS0FLc0JDQURJQlJxYWlJSklBa3RBQUJCQVdvNkFBQWdDQ3dBOUFFTGIwVUVRQ0FFS0FLc0JDQURRUkJ5SUFKcWFpSUNJQUl0QUFCQkFXbzZBQUFMSUFwQkFXb2lDaUFJTEFEekFTSUNTQTBBQ3lBSUxRRHlBU0VEQ3lBR1FRRnFJZ1lnQTBFWWRFRVlkU0lLU0EwQUN3c0NRQ0FJTFFEMEFTSUNRUmgwUVJoMUlnTkJBVW9FUUNBQUlBSndSUTBCQ3dKQUFrQWdDQ3dBOHdFaUFrRUFUQVJBUVFBaEN3d0JDMEVBSVF0QkFDRUdRUUFoQ1NBQUlBTnRJQUpCL3dGeGJDQVJUZzBBQTBBZ0NVRUZkQ0lQUVJCeUlTUkJBQ0VDQTBBZ0NDd0E4Z0ZCQW0xQkdIUkJHSFVpQ2lBRUtBS3NCQ0lESUFJZ0QycHFMUUFBU0FSQUlBUW9BcVFFSUFnc0FQTUJJQUFnQ0N3QTlBRnRiQ0FKYWtFQmRHb2dBam9BQUNBSUxBRHlBVUVDYlVFWWRFRVlkU0VLSUFRb0Fxd0VJUU1nQmtFQmFpRUdDeUFESUFJZ0pHcHFMUUFBSUFwS0JFQWdCQ2dDcEFRZ0NDd0E4d0VnQUNBSUxBRDBBVzFzSUFscVFRRjBhaUFDT2dBQklBWkJBV29oQmdzZ0FrRUJhaUlDUVJCSERRQUxJQXRCQW1vaEN5QUpRUUZxSWdrZ0NDd0E4d0VpQWs0TkFpQVJJQUFnQ0N3QTlBRnRJQUpzSUFscVNnMEFDd3dCQzBFQUlRWUxJQXNnRjJvaEZ5QUdJQTFxSVEwTElBY2lBQ0FnUncwQUN3c2dEYmNnRjdkRUFBQUFBQUFBNkQraVl3MEFBbjlCQWlBRUtBSklJZ0JCQkVnTkFCcEJCQ0FBUVE5SkRRQWFJQUJCQlc1QkFYUUxJUUlnQkNnQ1pDRURJQVZCQURZQy9BRWdCVUVBT2dEMEFTQUZRUUEyQXZBQklBVkJBRG9BNkFFZ0JVRUFOZ0xrQVNBRlFRQTZBTndCSUFWQkFEWUMyQUVnQlVFQU9nRFFBU0FGUVFBMkFzd0JJQVZCQURvQXhBRWdCVUVBTmdMQUFTQUZRUUE2QUxnQklBVkJBRFlDdEFFZ0JVRUFPZ0NzQVNBRlFRQTJBcWdCSUFWQkFEb0FvQUVnQlVFQU5nS2NBU0FGUVFBNkFKUUJJQVZCQURZQ2tBRWdCVUVBT2dDSUFTQUZRUUEyQW9RQklBVkJBRG9BZkNBRlFRQTJBbmdnQlVFQU9nQndJQVZCQURZQ2JDQUZRUUE2QUdRZ0JVRUFOZ0pnSUFWQkFEb0FXQ0FGUVFBMkFsUWdCVUVBT2dCTUlBVkJBRFlDU0NBRlFRQTZBRUFnQlVFQU5nSThJQVZCQURvQU5DQUZJQUk2QUNFZ0JTQUFPZ0FnSUFWQkFEc0JMQ0FGSUFNRWYwRUFCU0FDUWY0QmNTSUhJQUJCL3dGeFFRTnNhaUFIUVJ4c2FrRUJhaEFuSVFOQkFRczZBQ3dnQlNBRE5nSWtJQVZCQURzQk9DQUZJQU0yQWlnZ0JTQU1OZ0k4SUFWQkFEc0JOQ0FGSUF3MkFrZ2dCVUdBQWpzQlFDQUZRUU02QUZrZ0JTQU1OZ0pVSUFWQmdBUTdBVXdnQlNBQUlBSnFJZ2M2QURZZ0JTQUhPZ0JDSUFVZ0FrRUJkQ0lBT2dCT0lBVWdBRG9BV2lBRklBZEIvd0Z4SWdZN0FVUWdCU0FHUVFGMElnTTdBVkFnQlNBRElBQkIvZ0Z4SWdKcUlnTTdBVndnQlVHQUNEc0JaQ0FGSUF3MkFtQWdCVUVBT2dCWUlBVWdBRG9BWmlBRklBdzJBbXdnQlVHQUNqc0JjQ0FGSUFjNkFISWdCU0FNTmdKNElBVkJnQXc3QVh3Z0JTQUFPZ0IrSUFVZ0REWUNoQUVnQlVHQURqc0JpQUVnQlNBQU9nQ0tBU0FGSUF3MkFwQUJJQVZCQ0RvQWxRRWdCU0FDSUFOcUlnYzdBV2dnQlNBQ0lBZHFJZ2M3QVhRZ0JTQUdJQWRxSWdjN0FZQUJJQVVnQWlBSGFpSUhPd0dNQVNBRklBSWdCMm9pQnpzQm1BRWdCVUVBT2dDVUFTQUZJQUE2QUpZQklBVWdERFlDbkFFZ0JTQUFPZ0NpQVNBRlFZQVNPd0dnQVNBRklBdzJBcWdCSUFVZ0FEb0FyZ0VnQlVHQUZEc0JyQUVnQlNBTU5nSzBBU0FGSUFBNkFMb0JJQVZCZ0JZN0FiZ0JJQVZCRERvQXhRRWdCU0FNTmdMQUFTQUZJQUE2QU1ZQklBVWdBaUFIYWlJSE93R2tBU0FGSUFJZ0Iyb2lCenNCc0FFZ0JTQUNJQWRxSWdjN0Fid0JJQVVnQWlBSGFpSUhPd0hJQVNBRlFRMDZBTkVCSUFVZ0REWUN6QUVnQlVFQU9nREVBU0FGSUFJZ0Iyb2lCenNCMUFFZ0JTQUFPZ0RTQVNBRlFRNDZBTjBCSUFVZ0REWUMyQUVnQlVFQU9nRFFBU0FGSUFJZ0Iyb2lCenNCNEFFZ0JTQUFPZ0RlQVNBRlFRODZBT2tCSUFVZ0REWUM1QUVnQlVFQU9nRGNBU0FGSUFJZ0Iyb2lCenNCN0FFZ0JTQUFPZ0RxQVNBRklBSWdCMm83QWZnQklBVkJFRG9BOVFFZ0JTQU1OZ0x3QVNBRlFRQTZBT2dCSUFVZ0FEb0E5Z0VnQlNBTU5nTDhBU0FGUVFBNkFQUUJBa0FnRVVFQVRBMEFRUUFoQWlBY1FRRnJRUUFnRm10SEJFQWdFVUYrY1NFQVFRQWhBd05BSUFRb0FsUWdBbW9nQkNnQ3BBUWdBa0VCZEdvaUJ5MEFBVUVFZENBSExRQUFham9BQUNBQ1FRRnlJZ2NnQkNnQ1ZHb2dCQ2dDcEFRZ0IwRUJkR29pQnkwQUFVRUVkQ0FITFFBQWFqb0FBQ0FDUVFKcUlRSWdBMEVDYWlJRElBQkhEUUFMQ3lBUlFRRnhSUTBBSUFRb0FsUWdBbW9nQkNnQ3BBUWdBa0VCZEdvaUFDMEFBVUVFZENBQUxRQUFham9BQUFzZ0JVRWdhaUFFS0FKVUlnQWdBQ0FGTFFBZ2FpQUVLQUxVQVJBN0lnQkZCRUFDUUNBRUxRQlFSUTBBUVFBaEFpQUVLQUpJUVFCTURRQURRQ0FFS0FMVUFTQUNhaUlISUFKQlAzRkJzQ2hxTFFBQUlBY3RBQUJ6T2dBQUlBSkJBV29pQWlBRUtBSklTQTBBQ3dzQ1FFSEEyUUFvQWdBaUFrVU5BQ0FFS0FKSUlRY2dDQ2dDN0FFaEJpQUZJQTQyQWhnZ0JTQUdOZ0lVSUFVZ0J6WUNFQ0FDUWJFaklBVkJFR29RSEVIQTJRQW9BZ0FpQWtVTkFDQUZJQVFvQXRRQk5nSUFJQUpCNHlRZ0JSQWNDeUFFUVFFNkFLd0JJQVFnQkNnQ1NEWUMwQUVnQkNBSUtBTDBBVFlDNUFFZ0JDQUlLUUxzQVRjQzNBRWdCQ0FPTmdMb0FRc0NRQ0FGTFFBc1JRMEFJQVVvQWlRaUFrVU5BQ0FDRUNFTElBQkZEUUVnRGtFQmFpSU9RUlpIRFFJTUFRc2dEa0VCYWlJT1FSWkhEUUVMQ3lBRlFZQUNhaVFBREFFTFFRQWhBaU1BUWFBQ2F5SURKQUFnQkNnQ2dBUWdCQ2dDaUFRaUFDQUVLQUwwQTJ4QkFuUnFJQVFvQXJnQklBQWdCQ2dDdkFFaUJ5QUFJQWRJRzBFQ2RCQWFHaUFFUVFBZ0JDZ0M5QU1pQUVFQmFpQUFRUUpLR3lJQU5nTDBBd0pBSUFBRVFDQUVMUUJzUlEwQkN5QUVRUUU2QUswQklBUW9BdmdEUVFBZ0JDZ0MvQU5CQW5RUUd4b0NRQUpBQWtBQ1FDQUVLQUtFQkNJT1FRQk1CRUFnQkNnQ0RDRUhEQUVMSUFRb0Fnd2lCMEVBVEEwQklBUW9Bb2dFSVJFZ0JDZ0NnQVFoRnlBSFFYeHhJUTBnQjBFRGNTRUpJQVFvQXZnRElRVWdCMEVCYTBFRFNTRVdBMEFnRnlBQ0lCRnNRUUowYWlFSVFRQWhBRUVBSVFaQkFDRUtJQlpGQkVBRFFDQUZJQVpCQW5RaURHb2lDeUFJSUF4cUtnSUFJQXNxQWdDU09BSUFJQVVnREVFRWNpSUxhaUlTSUFnZ0Myb3FBZ0FnRWlvQ0FKSTRBZ0FnQlNBTVFRaHlJZ3RxSWhJZ0NDQUxhaW9DQUNBU0tnSUFramdDQUNBRklBeEJESElpREdvaUN5QUlJQXhxS2dJQUlBc3FBZ0NTT0FJQUlBWkJCR29oQmlBS1FRUnFJZ29nRFVjTkFBc0xJQWtFUUFOQUlBVWdCa0VDZENJTWFpSUtJQWdnREdvcUFnQWdDaW9DQUpJNEFnQWdCa0VCYWlFR0lBQkJBV29pQUNBSlJ3MEFDd3NnQWtFQmFpSUNJQTVIRFFBTEMwRUFJUVlnQjBFQVNnMEJDeUFFS0FMNEF5RUtEQUVMSUFRb0F2Z0RJUW9nQjBFQmEwRURUd1JBSUFkQmZIRWhBa0VBSVE0RFFDQUtJQVpCQW5RaUFHb2lCU0FGS2dJQVF3QUFnRDZVT0FJQUlBb2dBRUVFY21vaUJTQUZLZ0lBUXdBQWdENlVPQUlBSUFvZ0FFRUljbW9pQlNBRktnSUFRd0FBZ0Q2VU9BSUFJQW9nQUVFTWNtb2lBQ0FBS2dJQVF3QUFnRDZVT0FJQUlBWkJCR29oQmlBT1FRUnFJZzRnQWtjTkFBc0xJQWRCQTNFaUFrVU5BRUVBSVFBRFFDQUtJQVpCQW5ScUlnVWdCU29DQUVNQUFJQStsRGdDQUNBR1FRRnFJUVlnQUVFQmFpSUFJQUpIRFFBTEN5QUVLQUtrQVNFQUlBUW9BcHdCSVFJZ0J5QUVLQUtVQVNBS0lBZEJBblFRR2lBQ0lBQVFQU0FFS0FJTUlnSkJBRXdOQUNBRUtBS3dBU0VBSUFRb0FwUUJJUWRCQUNFR0lBSkJBVWNFUUNBQ1FYNXhJUVZCQUNFT0EwQWdBQ0FHUVFKMGFpQUhJQVpCQTNScUlnZ3FBZ0FpSnlBbmxDQUlLZ0lFSWljZ0o1U1NPQUlBSUFBZ0JrRUJjaUlJUVFKMGFpQUhJQWhCQTNScUlnZ3FBZ0FpSnlBbmxDQUlLZ0lFSWljZ0o1U1NPQUlBSUFaQkFtb2hCaUFPUVFKcUlnNGdCVWNOQUFzTElBSkJBWEVFUUNBQUlBWkJBblJxSUFjZ0JrRURkR29pQUNvQ0FDSW5JQ2VVSUFBcUFnUWlKeUFubEpJNEFnQUxJQUpCQkVnTkFFRUJJUVlnQWtFQmRpSUFRUUZySWdWQkFYRWhDQ0FFS0FLd0FTRUhJQUJCQWtjRVFDQUZRWDV4SVFWQkFDRUFBMEFnQnlBR1FRSjBhaUlNSUFjZ0FpQUdhMEVDZEdvcUFnQWdEQ29DQUpJNEFnQWdCeUFHUVFGcUlneEJBblJxSWdvZ0J5QUNJQXhyUVFKMGFpb0NBQ0FLS2dJQWtqZ0NBQ0FHUVFKcUlRWWdBRUVDYWlJQUlBVkhEUUFMQ3lBSVJRMEFJQWNnQmtFQ2RHb2lBQ0FISUFJZ0JtdEJBblJxS2dJQUlBQXFBZ0NTT0FJQUN3SkFJQVFvQW9RQklnQkJBRXdOQUNBRUtBS01CQ0FFS0FJTUlnSWdCQ2dDakFFZ0FHdHNRUUowYWlBRUtBSzRBU0FDUVFKMEVCb2FJQVFnQkNnQ2hBRWlBRUVCYXpZQ2hBRWdBRUVCU2cwQUlBUkJBVG9BYlFzZ0JDMEFiUVJBUWNEWkFDZ0NBQ0lBQkVCQjlTRkJHeUFBRUNnTElBUW9BZ3hCRUcwaEd5QURRZEFBYWlFSlFRQWhGd0pBQWtBRFFBSkFJQVFnRjBFTWJHb2lFUzBBOVFGRkRRQWdFUzBBOUFGQkFrWU5BQ0FFS0FKMElCRXVBZkFCUncwQUlBUW9BckFCUVFBZ0JDZ0N0QUZCQW5RUUd4b2dCQ0FFS0FJNElnQkJCSFFpQWpZQ2lBRWdCQ0FDTmdLQUFTQUFRUUJNRFFBRFFFRUFJUVVnQWlJTVFRRnJJZ0loRGtFQUlRZEJBQ0VXQWtBQ1FBSkFJQXdnQkNnQ2VFRUVkRW9OQUFOQUlBUW9BbGdnQlVFQmFpSUlJQkVzQVBNQmJFd05BU0FFS0FLVUFTQUVLQUtNQkNBT0lCdHNRUUowYWlBRUtBSU1RUUowRUJvYUlBUW9BZ3doQ2dKQUlCRXNBUElCSWlCQkFrZ05BQ0FLUVFCTURRQWdDa0YrY1NFUFFRRWhEU0FLUVFGeElTSWdCQ2dDbEFFaEN5QUVLQUtNQkNFU0EwQWdEVUVFZENBT2FpQWJiQ0VZUVFBaEJrRUFJUUFnQ2tFQlJ3UkFBMEFnQ3lBR1FRSjBhaUljSUJJZ0JpQVlha0VDZEdvcUFnQWdIQ29DQUpJNEFnQWdDeUFHUVFGeUloeEJBblJxSWlNZ0VpQVlJQnhxUVFKMGFpb0NBQ0FqS2dJQWtqZ0NBQ0FHUVFKcUlRWWdBRUVDYWlJQUlBOUhEUUFMQ3lBaUJFQWdDeUFHUVFKMGFpSUFJQklnQmlBWWFrRUNkR29xQWdBZ0FDb0NBSkk0QWdBTElBMUJBV29pRFNBZ1J3MEFDd3NnQ2lBRUtBS1VBU0FFS0FLY0FTQUVLQUtrQVJBOUFrQWdCQ2dDRENJS1FRQk1EUUFnQkNnQ3NBRWhBQ0FFS0FLVUFTRU5RUUFoQmlBS1FRRkhCRUFnQ2tGK2NTRUxRUUFoRGdOQUlBQWdCa0VDZEdvZ0RTQUdRUU4wYWlJU0tnSUFJaWNnSjVRZ0Vpb0NCQ0luSUNlVWtqZ0NBQ0FBSUFaQkFYSWlFa0VDZEdvZ0RTQVNRUU4wYWlJU0tnSUFJaWNnSjVRZ0Vpb0NCQ0luSUNlVWtqZ0NBQ0FHUVFKcUlRWWdEa0VDYWlJT0lBdEhEUUFMQ3lBS1FRRnhCRUFnQUNBR1FRSjBhaUFOSUFaQkEzUnFJZ0FxQWdBaUp5QW5sQ0FBS2dJRUlpY2dKNVNTT0FJQUN5QUtRUVJJRFFCQkFTRUdJQXBCQVhZaUFFRUJheUlOUVFGeElRc2dCQ2dDc0FFaERpQUFRUUpIQkVBZ0RVRitjU0VOUVFBaEFBTkFJQTRnQmtFQ2RHb2lFaUFPSUFvZ0JtdEJBblJxS2dJQUlCSXFBZ0NTT0FJQUlBNGdCa0VCYWlJU1FRSjBhaUlZSUE0Z0NpQVNhMEVDZEdvcUFnQWdHQ29DQUpJNEFnQWdCa0VDYWlFR0lBQkJBbW9pQUNBTlJ3MEFDd3NnQzBVTkFDQU9JQVpCQW5ScUlnQWdEaUFLSUFaclFRSjBhaW9DQUNBQUtnSUFramdDQUF0QkFDRUtRUUFoQUNBUkxBRHpBU0lPUVFCS0JFQURRQUovSUFRcUFpaTdJQVFxQWlRZ0VTNEI4QUd5bEx1aUVEZ2dDa0VFZExlZ0lqQ1pSQUFBQUFBQUFPQkJZd1JBSURDcURBRUxRWUNBZ0lCNEN5RUdRUTlCRGtFTlFReEJDMEVLUVFsQkNFRUhRUVpCQlVFRVFRTkJBaUFFS0FLd0FTQUdRUUowYWlJR0tnSUF1eUl3UkFBQUFBQUFBQUFBSURCRUFBQUFBQUFBQUFCa0d5SXdJQVlxQWdTN0lqRmpJZzBnTVNBd0lBMGJJakFnQmlvQ0NMc2lNV01pRFJzZ01TQXdJQTBiSWpBZ0Jpb0NETHNpTVdNaURSc2dNU0F3SUEwYklqQWdCaW9DRUxzaU1XTWlEUnNnTVNBd0lBMGJJakFnQmlvQ0ZMc2lNV01pRFJzZ01TQXdJQTBiSWpBZ0Jpb0NHTHNpTVdNaURSc2dNU0F3SUEwYklqQWdCaW9DSExzaU1XTWlEUnNnTVNBd0lBMGJJakFnQmlvQ0lMc2lNV01pRFJzZ01TQXdJQTBiSWpBZ0Jpb0NKTHNpTVdNaURSc2dNU0F3SUEwYklqQWdCaW9DS0xzaU1XTWlEUnNnTVNBd0lBMGJJakFnQmlvQ0xMc2lNV01pRFJzZ01TQXdJQTBiSWpBZ0Jpb0NNTHNpTVdNaURSc2dNU0F3SUEwYklqQWdCaW9DTkxzaU1XTWlEUnNnTVNBd0lBMGJJakFnQmlvQ09Mc2lNV01pRFJzZ0Jpb0NQTHNnTVNBd0lBMGJaQnNoQmlBS1FRRnhCSDhnQkNnQ1ZDQUZJQTVzSUFwQkFYWnFhaUFHUVFSMElBQnFPZ0FBUVFBRklBWUxJUUFnQ2tFQmFpSUtJQkVzQVBNQklnNUJBWFJJRFFBTEN5QVdJQVFvQWp3aUFDQUZJQTVzVG5KRkJFQWdCQ2dDWENFR1FRQWhGaUFEUVFBMkFwd0NJQU5CQURvQWxBSWdBMEVBTmdLUUFpQURRUUE2QUlnQ0lBTkJBRFlDaEFJZ0EwRUFPZ0Q4QVNBRFFRQTJBdmdCSUFOQkFEb0E4QUVnQTBFQU5nTHNBU0FEUVFBNkFPUUJJQU5CQURZQzRBRWdBMEVBT2dEWUFTQURRUUEyQXRRQklBTkJBRG9BekFFZ0EwRUFOZ0xJQVNBRFFRQTZBTUFCSUFOQkFEWUN2QUVnQTBFQU9nQzBBU0FEUVFBMkFyQUJJQU5CQURvQXFBRWdBMEVBTmdLa0FTQURRUUE2QUp3QklBTkJBRFlDbUFFZ0EwRUFPZ0NRQVNBRFFRQTJBb3dCSUFOQkFEb0FoQUVnQTBFQU5nS0FBU0FEUVFBNkFIZ2dBMEVBTmdKMElBTkJBRG9BYkNBRFFRQTJBbWdnQTBFQU9nQmdJQU5CQURZQ1hDQURRUUE2QUZRZ0F5QUFRUUZySWdvNkFFRWdBMEVCT2dCQUlBTkJBRHNCVEVFQUlRNGdCa1VFUUVFQklRNGdDa0gvQVhFaUJpQUdRUnhzYWtFRWFoQW5JUVlMSUFNZ0Rqb0FUQ0FESUFZMkFrUWdBMEVBT3dGWUlBTWdCallDU0NBRElBQTZBRllnQXlBSk5nSmNJQU5CQURzQlZDQURJQUE2QUdJZ0F5QUpOZ0pvSUFOQmdBSTdBV0FnQTBFRE9nQjVJQU1nQ1RZQ2RDQURRWUFFT3dGc0lBTWdDa0VCZENJR09nQnVJQU1nQmpvQWVpQURJQUJCL3dGeElnNDdBV1FnQXlBT1FRRjBJZzA3QVhBZ0F5QU5JQVpCL2dGeElncHFJZzA3QVh3Z0EwR0FDRHNCaEFFZ0F5QUpOZ0tBQVNBRFFRQTZBSGdnQXlBR09nQ0dBU0FESUFrMkFvd0JJQU5CZ0FvN0FaQUJJQU1nQURvQWtnRWdBeUFKTmdLWUFTQURRWUFNT3dHY0FTQURJQVk2QUo0QklBTWdDVFlDcEFFZ0EwR0FEanNCcUFFZ0F5QUdPZ0NxQVNBRElBazJBckFCSUFOQkNEb0F0UUVnQXlBS0lBMXFJZ0E3QVlnQklBTWdBQ0FLYWlJQU93R1VBU0FESUFBZ0Rtb2lBRHNCb0FFZ0F5QUFJQXBxSWdBN0Fhd0JJQU1nQUNBS2FpSUFPd0c0QVNBRFFRQTZBTFFCSUFNZ0Jqb0F0Z0VnQXlBSk5nSzhBU0FESUFZNkFNSUJJQU5CZ0JJN0FjQUJJQU1nQ1RZQ3lBRWdBeUFHT2dET0FTQURRWUFVT3dITUFTQURJQWsyQXRRQklBTWdCam9BMmdFZ0EwR0FGanNCMkFFZ0EwRU1PZ0RsQVNBRElBazJBdUFCSUFNZ0Jqb0E1Z0VnQXlBQUlBcHFJZ0E3QWNRQklBTWdBQ0FLYWlJQU93SFFBU0FESUFBZ0Ntb2lBRHNCM0FFZ0F5QUFJQXBxSWdBN0FlZ0JJQU5CRFRvQThRRWdBeUFKTmdMc0FTQURRUUE2QU9RQklBTWdBQ0FLYWlJQU93SDBBU0FESUFZNkFQSUJJQU5CRGpvQS9RRWdBeUFKTmdMNEFTQURRUUE2QVBBQklBTWdBQ0FLYWlJQU93R0FBaUFESUFZNkFQNEJJQU5CRHpvQWlRSWdBeUFKTmdLRUFpQURRUUE2QVB3QklBTWdBQ0FLYWlJQU93R01BaUFESUFZNkFJb0NJQU1nQUNBS2Fqc0JtQUlnQTBFUU9nQ1ZBaUFESUFrMkFwQUNJQU5CQURvQWlBSWdBeUFHT2dDV0FpQURJQWsyQXB3Q0lBTkJBRG9BbEFKQkZ5RUdBa0FnQTBGQWF5QUVLQUpVSWdBZ0FDQURMUUJBYWlBRUtBTFVBUkE3RFFBZ0JDZ0MxQUV0QUFBaUFFRUJhMEgvQVhGQml3RkxEUUFnQkNnQ1BDRUhRUmRCQUNBRUtBSjRJZ1lnRVN3QThnRWdFU3dBOHdFaUNnSi9RUUlnQUVFRVNRMEFHa0VFSUFCQkQwa05BQm9nQUVFRmJrRUJkQXNnQUNBSGFtcHFRUUZySUFwdGJDSUhTQ0FHSUFjZ0JDZ0NPRUVCZEdwS2NpSUhHeUVHSUFkRklSWWdBQ0VIQ3dKQUlBTXRBRXhGRFFBZ0F5Z0NSQ0lBUlEwQUlBQVFJUXNnQmcwQ0lBUW9BandoQUFzQ2YwRUNJQWRCQkVnTkFCcEJCQ0FIUVE5SkRRQWFJQWRCQlc1QkFYUUxJUVlDUUNBV0JFQWdBQ0FIYWlBR2FrRUJhaUFGSUJFc0FQTUJiRWdOQkNBSVFZQUlSZzBFREFFTFFRQWhGaUFJUVlBSVJnMEVDeUFJSWdVZ0VTd0E4Z0ZzUVFSMElBSnFJZzRnQkNnQ2VFRUVkRWdOQUFzTElCWkZEUUVMSUFRb0FtUWhDaUFEUVFBMkFwd0NJQU5CQURvQWxBSWdBMEVBTmdLUUFpQURRUUE2QUlnQ0lBTkJBRFlDaEFJZ0EwRUFPZ0Q4QVNBRFFRQTJBdmdCSUFOQkFEb0E4QUVnQTBFQU5nTHNBU0FEUVFBNkFPUUJJQU5CQURZQzRBRWdBMEVBT2dEWUFTQURRUUEyQXRRQklBTkJBRG9BekFFZ0EwRUFOZ0xJQVNBRFFRQTZBTUFCSUFOQkFEWUN2QUVnQTBFQU9nQzBBU0FEUVFBMkFyQUJJQU5CQURvQXFBRWdBMEVBTmdLa0FTQURRUUE2QUp3QklBTkJBRFlDbUFFZ0EwRUFPZ0NRQVNBRFFRQTJBb3dCSUFOQkFEb0FoQUVnQTBFQU5nS0FBU0FEUVFBNkFIZ2dBMEVBTmdKMElBTkJBRG9BYkNBRFFRQTJBbWdnQTBFQU9nQmdJQU5CQURZQ1hDQURRUUE2QUZRZ0F3Si9RUUlnQjBFRVNBMEFHa0VFSUFkQkQwa05BQm9nQjBFRmJrRUJkQXNpQURvQVFTQURJQWM2QUVBZ0EwRUFPd0ZNSUFNZ0NnUi9RUUFGSUFCQi9nRnhJZ1VnQjBIL0FYRkJBMnhxSUFWQkhHeHFRUUZxRUNjaENrRUJDem9BVENBRElBbzJBa1FnQTBFQU93RllJQU1nQ2pZQ1NDQURJQWsyQWx3Z0EwRUFPd0ZVSUFNZ0NUWUNhQ0FEUVlBQ093RmdJQU5CQXpvQWVTQURJQWsyQW5RZ0EwR0FCRHNCYkNBRElBQWdCMm9pQ0RvQVZpQURJQWc2QUdJZ0F5QUFRUUYwSWdBNkFHNGdBeUFBT2dCNklBTWdDRUgvQVhFaUJqc0JaQ0FESUFaQkFYUWlDanNCY0NBRElBb2dBRUgrQVhFaUJXb2lDanNCZkNBRFFZQUlPd0dFQVNBRElBazJBb0FCSUFOQkFEb0FlQ0FESUFBNkFJWUJJQU1nQ1RZQ2pBRWdBMEdBQ2pzQmtBRWdBeUFJT2dDU0FTQURJQWsyQXBnQklBTkJnQXc3QVp3QklBTWdBRG9BbmdFZ0F5QUpOZ0trQVNBRFFZQU9Pd0dvQVNBRElBQTZBS29CSUFNZ0NUWUNzQUVnQTBFSU9nQzFBU0FESUFVZ0Ntb2lDRHNCaUFFZ0F5QUZJQWhxSWdnN0FaUUJJQU1nQmlBSWFpSUlPd0dnQVNBRElBVWdDR29pQ0RzQnJBRWdBeUFGSUFocUlnZzdBYmdCSUFOQkFEb0F0QUVnQXlBQU9nQzJBU0FESUFrMkFyd0JJQU1nQURvQXdnRWdBMEdBRWpzQndBRWdBeUFKTmdMSUFTQURJQUE2QU00QklBTkJnQlE3QWN3QklBTWdDVFlDMUFFZ0F5QUFPZ0RhQVNBRFFZQVdPd0hZQVNBRFFRdzZBT1VCSUFNZ0NUWUM0QUVnQXlBQU9nRG1BU0FESUFVZ0NHb2lDRHNCeEFFZ0F5QUZJQWhxSWdnN0FkQUJJQU1nQlNBSWFpSUlPd0hjQVNBRElBVWdDR29pQ0RzQjZBRWdBMEVOT2dEeEFTQURJQWsyQXV3QklBTkJBRG9BNUFFZ0F5QUZJQWhxSWdnN0FmUUJJQU1nQURvQThnRWdBMEVPT2dEOUFTQURJQWsyQXZnQklBTkJBRG9BOEFFZ0F5QUZJQWhxSWdnN0FZQUNJQU1nQURvQS9nRWdBMEVQT2dDSkFpQURJQWsyQW9RQ0lBTkJBRG9BL0FFZ0F5QUZJQWhxSWdnN0FZd0NJQU1nQURvQWlnSWdBeUFGSUFocU93R1lBaUFEUVJBNkFKVUNJQU1nQ1RZQ2tBSWdBMEVBT2dDSUFpQURJQUE2QUpZQ0lBTWdDVFlDbkFJZ0EwRUFPZ0NVQWlBRFFVQnJJQVFvQWxRZ0JDZ0NQR29pQUNBQUlBTXRBRUJxSUFRb0F0UUJFRHRGSUFkQkFFcHhJZ0FFUUFKQUlBUXRBRkJGRFFCQkFDRUdJQWRCQVVjRVFDQUhRWDV4SVFWQkFDRUtBMEFnQkNnQzFBRWdCbW9pQ0NBR1FUNXhRYkFvYWkwQUFDQUlMUUFBY3pvQUFDQUdRUUZ5SWdnZ0JDZ0MxQUZxSWc0Z0NFRS9jVUd3S0dvdEFBQWdEaTBBQUhNNkFBQWdCa0VDYWlFR0lBcEJBbW9pQ2lBRlJ3MEFDd3NnQjBFQmNVVU5BQ0FFS0FMVUFTQUdhaUlGSUFaQlAzRkJzQ2hxTFFBQUlBVXRBQUJ6T2dBQUN3SkFRY0RaQUNnQ0FDSUZSUTBBSUJFb0F1d0JJUWdnQXlBWE5nSTRJQU1nQ0RZQ05DQURJQWMyQWpBZ0JVR3hJeUFEUVRCcUVCeEJ3TmtBS0FJQUlnVkZEUUFnQXlBRUtBTFVBVFlDSUNBRlFlTWtJQU5CSUdvUUhBc2dCQ0FITmdMUUFTQUVRUUU2QUt3QklBUWdFU2dDOUFFMkF1UUJJQVFnRVNrQzdBRTNBdHdCSUFRZ0Z6WUM2QUVMQWtBZ0F5MEFURVVOQUNBREtBSkVJZ2RGRFFBZ0J4QWhDeUFBRFFRTElBUWdCQ2dDZ0FGQkFXczJBb0FCSUF4QkFVb05BQXNMSUJkQkFXb2lGMEVXUncwQUN5QUVRUUEyQW93QlFjRFpBQ2dDQUNJQUJFQWdBeUFFS0FMVUFTMEFBRFlDRUNBQVFhVWtJQU5CRUdvUUhBc2dCRUYvTmdLTUFTQUVRWDgyQXRBQkRBRUxJQVJCQURZQ2pBRUxJQVJCQURzQmJDQUVLQUt3QVVFQUlBUW9BclFCUVFKMEVCc2FJQVJCQURZQ2dBRWdCRUVBTmdLSUFRdEJBQ0VGQWtBZ0JDMEFiRVVFUUFOQUFrQWdCQ0FGUVF4c2FpSUFMUUQxQVVVTkFDQUVLQUkwSWdKQkFFb0VRQ0FBTGdId0FiSWhLU0FFS0FJc0lRZ2dCQ29DUUNFcUlBUW9BckFCSVFjZ0JDb0NNQ0VySUFRcUFpUWhMQ0FFS2dJb3V5RXdRUUFoQmlBQ0lRQURRQ0FxSUFjZ0NBSi9JREFnTENBcGxDQXJJQWF5bEpLN29oQTRJakdaUkFBQUFBQUFBT0JCWXdSQUlER3FEQUVMUVlDQWdJQjRDeUlNYWtFQ2RHb3FBZ0NVSVNjZ0J5QU1RUUowYWlvQ0FDRW9Ba0FDUUNBR1FRRnhSUVJBSUNjZ0tHQU5BUXdDQ3lBbklDaGZSUTBCQ3lBQVFRRnJJUUFMSUFaQkFXb2lCaUFDUncwQUN5QUFJQUpIRFFFTElBUWdCRUhzQVdvaUJ5QUZRUXhzYWk0QkJEWUNkQ0FFSUFRb0FuQWlBRUVCYWpZQ2NDQUFRUUJJRFFOQkFDRUFRY0RaQUNnQ0FDSUNCRUJCMnlGQkdTQUNFQ2dMSUFSQkFUb0FiQ0FFS0FMVUFVRUFJQVFvQXRnQkVCc2FJQVFvQWpnaEJVRUFJUVlEUUFKQUlBUWdCa0VNYkdvaUFpMEE5UUZGRFFBZ0Fpd0E5QUVpQ0VFQlNnMEFJQUlzQVBJQklBaHNJZ0lnQUNBQUlBSklHeUVBQ3lBR1FRRnFJZ1pCRmtjTkFBc2dCeEE4SVFJZ0JFRUFOZ0p3SUFSQnhBRWdBbTFCQVdvZ0FHd2dCVUVCZEdvaUFEWUNqQUVnQkNBQU5nSjRJQVFnQURZQ2hBRU1Bd3NnQlVFQmFpSUZRUlpIRFFBTElBUkJBRFlDY0F3QkMwRUJJUUlDUUFKQUEwQUNRQ0FFSUFWQkRHeHFJZ0F0QVBVQkJFQWdCQ2dDTkNJSFFRQk1EUUVnQUM0QjhBR3lJU2tnQkNnQ0xDRU1JQVFxQWtBaEtpQUVLQUt3QVNFSUlBUXFBakFoS3lBRUtnSWtJU3dnQkNvQ0tMc2hNRUVBSVFZZ0J5RUFBMEFnS2lBSUlBd0NmeUF3SUN3Z0taUWdLeUFHc3BTU3U2SVFPQ0l4bVVRQUFBQUFBQURnUVdNRVFDQXhxZ3dCQzBHQWdJQ0FlQXNpQ21wQkFuUnFLZ0lBbENFbklBZ2dDa0VDZEdvcUFnQWhLQUpBQWtBZ0JrRUJjVVVFUUNBbklDaGZEUUVNQWdzZ0p5QW9ZRVVOQVFzZ0FFRUJheUVBQ3lBR1FRRnFJZ1lnQjBjTkFBc2dBQ0FIUmcwQkN5QUZRUlZKSVFJZ0JVRUJhaUlGUVJaSERRRU1BZ3NMSUFJTkFRc2dCRUVBTmdKd0RBRUxJQVFnQkNnQ2NDSUFRUUZxTmdKd0lBQkJBRWdOQUNBRUtBS01BVUVDU0EwQUlBUWdCQ2dDZUNBRUtBS0VBU0lBYTBFQmFpSUNOZ0o0UWNEWkFDZ0NBQ0lIQkVBZ0F5QUNOZ0lFSUFNZ0FEWUNBQ0FIUWFBZUlBTVFIQXNnQkVFQk5nS0VBU0FFUVFBMkFuQUxJQU5Cb0FKcUpBQUxBa0FnRUNBRUtBSU1JZ2hySWd4QkFFd05BQ0FFS0FLNEFTRUNRUUFoQjBFQUlRQWdFQ0FJUVg5emFrRURUd1JBSUF4QmZIRWhCa0VBSVFVRFFDQUNJQUJCQW5ScUlBSWdBQ0FJYWtFQ2RHb3FBZ0E0QWdBZ0FpQUFRUUZ5SWdOQkFuUnFJQUlnQXlBSWFrRUNkR29xQWdBNEFnQWdBaUFBUVFKeUlnTkJBblJxSUFJZ0F5QUlha0VDZEdvcUFnQTRBZ0FnQWlBQVFRTnlJZ05CQW5ScUlBSWdBeUFJYWtFQ2RHb3FBZ0E0QWdBZ0FFRUVhaUVBSUFWQkJHb2lCU0FHUncwQUN3c2dERUVEY1NJRlJRMEFBMEFnQWlBQVFRSjBhaUFDSUFBZ0NHcEJBblJxS2dJQU9BSUFJQUJCQVdvaEFDQUhRUUZxSWdjZ0JVY05BQXNMSUI0Z0dtc2hIaUFhSUIxcUlSMGdCQ0FJSUF4cklnQTJBcEFCREFFTEN5QUVJQUlnRUdzMkFwQUJDeUFmUVJCcUpBQUNRQ0FEUlFSQVFYOGhBRUhBMlFBb0FnQWlBa1VOQVNBaElBRTJBZ0FnQWtHZUhTQWhFQndNQVF0QkFDRUFRY3paQUMwQUFFVUVRRUhFMlFCQ0FEY0NBRUhNMlFCQkFUb0FBQXNnQkNnQzBBRWlBVVVOQUNBRVFRQTJBdEFCUVg4aEFDQUJRWDlHRFFBZ0JDZ0MxQUVoQUVISTJRQWdBVFlDQUVIRTJRQWdBRFlDQUNBQlFRQktCRUJCc05jQUlBQWdBUkFhR2dzZ0FTRUFDeUFoUVJCcUpBQWdBRUVBU2dSQUlCbEJzTmNBTmdJTUlCa2dBRFlDQ0VHNEppQVpRUWhxRUFZTUFRc2dHVUd3MXdBMkFnd2dHVUVBTmdJSVFiZ21JQmxCQ0dvUUJnczJBZ0FnR1VFUWFpUUFDNzBCQVFSL0l3QkJJR3NpQXlRQUlBSW9BZ0FpQkVGd1NRUkFBa0FDUUNBRVFRdFBCRUFnQkVFUWFrRndjU0lHRUIwaEJTQURJQVpCZ0lDQWdIaHlOZ0lRSUFNZ0JUWUNDQ0FESUFRMkFnd01BUXNnQXlBRU9nQVRJQU5CQ0dvaEJTQUVSUTBCQ3lBRklBSkJCR29nQkJBYUdnc2dCQ0FGYWtFQU9nQUFJQU5CR0dvZ0FTQURRUWhxSUFBUkFBQWdBeWdDR0JBS0lBTW9BaGdpQUJBSklBTXNBQk5CQUVnRVFDQURLQUlJRUNFTElBTkJJR29rQUNBQUR3c1FOQUFMb1FRQkIzOGpBRUVRYXlJSUpBQWdBU0FDS0FJQUlBSWdBaTBBQ3lJRlFSaDBRUmgxUVFCSUlnWWJJQUlvQWdRZ0JTQUdHeUFESUFSQkFFRUJFRlFoQlFKQUFrQkJvTmNBTFFBQVFRRnhEUUJCb05jQUVDTkZEUUJCbE5jQVFnQTNBZ0JCbk5jQVFRQTJBZ0FnQlFSQUlBVkJBRWdOQWtHVTF3QWdCUkFkSWdZMkFnQkJuTmNBSUFVZ0Jtb2lDVFlDQUNBR1FRQWdCUkFiR2tHWTF3QWdDVFlDQUF0Qm9OY0FFQ0lMQWtBQ1FDQUZRWmpYQUNnQ0FDSUhRWlRYQUNnQ0FDSUdheUlKU3dSQUlBVWdDV3NpQzBHYzF3QW9BZ0FpQ2lBSGEwMEVRRUdZMXdBZ0N3Ui9JQWRCQUNBTEVCc2dDMm9GSUFjTE5nSUFEQU1MSUFWQkFFZ05BU0FGSUFvZ0Jtc2lCMEVCZENJS0lBVWdDa3NiUWYvLy8vOEhJQWRCLy8vLy93TkpHeUlLRUIwaUJ5QUpha0VBSUFzUUd4b2dDVUVBU2dSQUlBY2dCaUFKRUJvYUMwR2Mxd0FnQnlBS2FqWUNBRUdZMXdBZ0JTQUhhallDQUVHVTF3QWdCellDQUNBR1JRMENJQVlRSVF3Q0N5QUZJQWxQRFFGQm1OY0FJQVVnQm1vMkFnQU1BUXNRTkFBTElBZ2dBU0FDS0FJQUlBSWdBaTBBQ3lJQlFSaDBRUmgxUVFCSUlnWWJJQUlvQWdRZ0FTQUdHeUFESUFSQmxOY0FLQUlBUVFBUVZDSUNOZ0lFSUFnZ0JUWUNBQ01BUVJCcklnRWtBQ0FCSUFnMkFneEI4TlVBUVlvZUlBZ1FRaUFCUVJCcUpBQWdDRUdVMXdBb0FnQTJBZ3dnQ0NBQ05nSUlJQUJCdUNZZ0NFRUlhaEFHTmdJQUlBaEJFR29rQUE4TEVEUUFDeUlCQVg0Z0FTQUNyU0FEclVJZ2hvUWdCQ0FBRVFzQUlnVkNJSWluRUJNZ0JhY0xHZ0FnQUNBQktBSUlJQVVRSUFSQUlBRWdBaUFESUFRUU5nc0xOd0FnQUNBQktBSUlJQVVRSUFSQUlBRWdBaUFESUFRUU5nOExJQUFvQWdnaUFDQUJJQUlnQXlBRUlBVWdBQ2dDQUNnQ0ZCRUdBQXVUQWdFR2Z5QUFJQUVvQWdnZ0JSQWdCRUFnQVNBQ0lBTWdCQkEyRHdzZ0FTMEFOU0VISUFBb0Fnd2hCaUFCUVFBNkFEVWdBUzBBTkNFSUlBRkJBRG9BTkNBQVFSQnFJZ2tnQVNBQ0lBTWdCQ0FGRURVZ0J5QUJMUUExSWdweUlRY2dDQ0FCTFFBMElndHlJUWdDUUNBR1FRSklEUUFnQ1NBR1FRTjBhaUVKSUFCQkdHb2hCZ05BSUFFdEFEWU5BUUpBSUFzRVFDQUJLQUlZUVFGR0RRTWdBQzBBQ0VFQ2NRMEJEQU1MSUFwRkRRQWdBQzBBQ0VFQmNVVU5BZ3NnQVVFQU93RTBJQVlnQVNBQ0lBTWdCQ0FGRURVZ0FTMEFOU0lLSUFkeUlRY2dBUzBBTkNJTElBaHlJUWdnQmtFSWFpSUdJQWxKRFFBTEN5QUJJQWRCL3dGeFFRQkhPZ0ExSUFFZ0NFSC9BWEZCQUVjNkFEUUxwd0VBSUFBZ0FTZ0NDQ0FFRUNBRVFBSkFJQUVvQWdRZ0FrY05BQ0FCS0FJY1FRRkdEUUFnQVNBRE5nSWNDdzhMQWtBZ0FDQUJLQUlBSUFRUUlFVU5BQUpBSUFJZ0FTZ0NFRWNFUUNBQktBSVVJQUpIRFFFTElBTkJBVWNOQVNBQlFRRTJBaUFQQ3lBQklBSTJBaFFnQVNBRE5nSWdJQUVnQVNnQ0tFRUJhallDS0FKQUlBRW9BaVJCQVVjTkFDQUJLQUlZUVFKSERRQWdBVUVCT2dBMkN5QUJRUVEyQWl3TEM0Z0NBQ0FBSUFFb0FnZ2dCQkFnQkVBQ1FDQUJLQUlFSUFKSERRQWdBU2dDSEVFQlJnMEFJQUVnQXpZQ0hBc1BDd0pBSUFBZ0FTZ0NBQ0FFRUNBRVFBSkFJQUlnQVNnQ0VFY0VRQ0FCS0FJVUlBSkhEUUVMSUFOQkFVY05BaUFCUVFFMkFpQVBDeUFCSUFNMkFpQUNRQ0FCS0FJc1FRUkdEUUFnQVVFQU93RTBJQUFvQWdnaUFDQUJJQUlnQWtFQklBUWdBQ2dDQUNnQ0ZCRUdBQ0FCTFFBMUJFQWdBVUVETmdJc0lBRXRBRFJGRFFFTUF3c2dBVUVFTmdJc0N5QUJJQUkyQWhRZ0FTQUJLQUlvUVFGcU5nSW9JQUVvQWlSQkFVY05BU0FCS0FJWVFRSkhEUUVnQVVFQk9nQTJEd3NnQUNnQ0NDSUFJQUVnQWlBRElBUWdBQ2dDQUNnQ0dCRUVBQXNMd1FFQkJIOGpBRUVnYXlJRkpBQWdBaWdDQUNJR1FYQkpCRUFDUUFKQUlBWkJDMDhFUUNBR1FSQnFRWEJ4SWdnUUhTRUhJQVVnQ0VHQWdJQ0FlSEkyQWhBZ0JTQUhOZ0lJSUFVZ0JqWUNEQXdCQ3lBRklBWTZBQk1nQlVFSWFpRUhJQVpGRFFFTElBY2dBa0VFYWlBR0VCb2FDeUFHSUFkcVFRQTZBQUFnQlVFWWFpQUJJQVZCQ0dvZ0F5QUVJQUFSQkFBZ0JTZ0NHQkFLSUFVb0FoZ2lBQkFKSUFVc0FCTkJBRWdFUUNBRktBSUlFQ0VMSUFWQklHb2tBQ0FBRHdzUU5BQUxMUUVCZjBFa0VCMGlBRUlBTndNQUlBQkJBRFlDSUNBQVFnQTNBeGdnQUVJQU53TVFJQUJDQURjRENDQUFDd3U4VEJzQVFZQUlDNklnTFNzZ0lDQXdXREI0QUMwd1dDc3dXQ0F3V0Mwd2VDc3dlQ0F3ZUFCellXMXdiR1ZHYjNKdFlYUlBkWFFBYzJGdGNHeGxVbUYwWlU5MWRBQmJWVjBnUm1GemRHVnpkQUJiVFZSZElFWmhjM1JsYzNRQVcwUlVYU0JHWVhOMFpYTjBBRnRWWFNCR1lYTjBBRnROVkYwZ1JtRnpkQUJiUkZSZElFWmhjM1FBZFc1emFXZHVaV1FnYzJodmNuUUFkVzV6YVdkdVpXUWdhVzUwQUdsdWFYUUFabXh2WVhRQVUyRnRjR3hsUm05eWJXRjBBSFZwYm5RMk5GOTBBR2RsZEVSbFptRjFiSFJRWVhKaGJXVjBaWEp6QUhabFkzUnZjZ0IxYm5OcFoyNWxaQ0JqYUdGeUFITmhiWEJzWlVadmNtMWhkRWx1Y0FCellXMXdiR1ZTWVhSbFNXNXdBRjlmWTNoaFgyZDFZWEprWDJGamNYVnBjbVVnWkdWMFpXTjBaV1FnY21WamRYSnphWFpsSUdsdWFYUnBZV3hwZW1GMGFXOXVBRzVoYmdCaWIyOXNBSFI0Vkc5bloyeGxVSEp2ZEc5amIyd0FjbmhVYjJkbmJHVlFjbTkwYjJOdmJBQmxiWE5qY21sd2RHVnVPanAyWVd3QVcxVmRJRTV2Y20xaGJBQmJUVlJkSUU1dmNtMWhiQUJiUkZSZElFNXZjbTFoYkFCd1lYbHNiMkZrVEdWdVozUm9BR1JwYzJGaWJHVk1iMmNBWlc1aFlteGxURzluQUhWdWMybG5ibVZrSUd4dmJtY0FjM1JrT2pwM2MzUnlhVzVuQUdKaGMybGpYM04wY21sdVp3QnpkR1E2T25OMGNtbHVad0J6ZEdRNk9uVXhObk4wY21sdVp3QnpkR1E2T25Vek1uTjBjbWx1WndCcGJtWUFjMkZ0Y0d4bFVtRjBaUUJ6WVcxd2JHVnpVR1Z5Um5KaGJXVUFaRzkxWW14bEFHWnlaV1VBWlc1amIyUmxBR1JsWTI5a1pRQnZjR1Z5WVhScGJtZE5iMlJsQUhOdmRXNWtUV0Z5YTJWeVZHaHlaWE5vYjJ4a0FIWnZhV1FBVUhKdmRHOWpiMnhKWkFCSFIxZEJWa1ZmVDFCRlVrRlVTVTVIWDAxUFJFVmZWRmdBUjBkWFFWWkZYMDlRUlZKQlZFbE9SMTlOVDBSRlgxSllYMEZPUkY5VVdBQkhSMWRCVmtWZlQxQkZVa0ZVU1U1SFgwMVBSRVZmVWxnQVIwZFhRVlpGWDFCU1QxUlBRMDlNWDBSVVgwWkJVMVJGVTFRQVIwZFhRVlpGWDFCU1QxUlBRMDlNWDBGVlJFbENURVZmUmtGVFZFVlRWQUJIUjFkQlZrVmZVRkpQVkU5RFQweGZWVXhVVWtGVFQxVk9SRjlHUVZOVVJWTlVBRWRIVjBGV1JWOVFVazlVVDBOUFRGOUVWRjlHUVZOVUFFZEhWMEZXUlY5UVVrOVVUME5QVEY5QlZVUkpRa3hGWDBaQlUxUUFSMGRYUVZaRlgxQlNUMVJQUTA5TVgxVk1WRkpCVTA5VlRrUmZSa0ZUVkFCSFIxZEJWa1ZmVDFCRlVrRlVTVTVIWDAxUFJFVmZWVk5GWDBSVFV3QkhSMWRCVmtWZlQxQkZVa0ZVU1U1SFgwMVBSRVZmVkZoZlQwNU1XVjlVVDA1RlV3Qk9RVTRBUjBkWFFWWkZYMUJTVDFSUFEwOU1YMFJVWDA1UFVrMUJUQUJIUjFkQlZrVmZVRkpQVkU5RFQweGZRVlZFU1VKTVJWOU9UMUpOUVV3QVIwZFhRVlpGWDFCU1QxUlBRMDlNWDFWTVZGSkJVMDlWVGtSZlRrOVNUVUZNQUVsT1JnQkhSMWRCVmtWZlUwRk5VRXhGWDBaUFVrMUJWRjlWVGtSRlJrbE9SVVFBWlcxelkzSnBjSFJsYmpvNmJXVnRiM0o1WDNacFpYYzhjMmh2Y25RK0FHVnRjMk55YVhCMFpXNDZPbTFsYlc5eWVWOTJhV1YzUEhWdWMybG5ibVZrSUhOb2IzSjBQZ0JsYlhOamNtbHdkR1Z1T2pwdFpXMXZjbmxmZG1sbGR6eHBiblErQUdWdGMyTnlhWEIwWlc0Nk9tMWxiVzl5ZVY5MmFXVjNQSFZ1YzJsbmJtVmtJR2x1ZEQ0QVpXMXpZM0pwY0hSbGJqbzZiV1Z0YjNKNVgzWnBaWGM4Wm14dllYUStBR1Z0YzJOeWFYQjBaVzQ2T20xbGJXOXllVjkyYVdWM1BIVnBiblE0WDNRK0FHVnRjMk55YVhCMFpXNDZPbTFsYlc5eWVWOTJhV1YzUEdsdWREaGZkRDRBWlcxelkzSnBjSFJsYmpvNmJXVnRiM0o1WDNacFpYYzhkV2x1ZERFMlgzUStBR1Z0YzJOeWFYQjBaVzQ2T20xbGJXOXllVjkyYVdWM1BHbHVkREUyWDNRK0FHVnRjMk55YVhCMFpXNDZPbTFsYlc5eWVWOTJhV1YzUEhWcGJuUXpNbDkwUGdCbGJYTmpjbWx3ZEdWdU9qcHRaVzF2Y25sZmRtbGxkenhwYm5Rek1sOTBQZ0JsYlhOamNtbHdkR1Z1T2pwdFpXMXZjbmxmZG1sbGR6eGphR0Z5UGdCbGJYTmpjbWx3ZEdWdU9qcHRaVzF2Y25sZmRtbGxkengxYm5OcFoyNWxaQ0JqYUdGeVBnQnpkR1E2T21KaGMybGpYM04wY21sdVp6eDFibk5wWjI1bFpDQmphR0Z5UGdCbGJYTmpjbWx3ZEdWdU9qcHRaVzF2Y25sZmRtbGxkenh6YVdkdVpXUWdZMmhoY2o0QVpXMXpZM0pwY0hSbGJqbzZiV1Z0YjNKNVgzWnBaWGM4Ykc5dVp6NEFaVzF6WTNKcGNIUmxiam82YldWdGIzSjVYM1pwWlhjOGRXNXphV2R1WldRZ2JHOXVaejRBWlcxelkzSnBjSFJsYmpvNmJXVnRiM0o1WDNacFpYYzhaRzkxWW14bFBnQkhSMWRCVmtWZlVGSlBWRTlEVDB4ZlExVlRWRTlOWHprQVIwZFhRVlpGWDFCU1QxUlBRMDlNWDBOVlUxUlBUVjg0QUVkSFYwRldSVjlUUVUxUVRFVmZSazlTVFVGVVgxVTRBRWRIVjBGV1JWOVRRVTFRVEVWZlJrOVNUVUZVWDBrNEFFZEhWMEZXUlY5UVVrOVVUME5QVEY5RFZWTlVUMDFmTndCSFIxZEJWa1ZmVUZKUFZFOURUMHhmUTFWVFZFOU5YellBUjBkWFFWWkZYMU5CVFZCTVJWOUdUMUpOUVZSZlZURTJBRWRIVjBGV1JWOVRRVTFRVEVWZlJrOVNUVUZVWDBreE5nQkhSMWRCVmtWZlVGSlBWRTlEVDB4ZlExVlRWRTlOWHpVQVIwZFhRVlpGWDFCU1QxUlBRMDlNWDBOVlUxUlBUVjgwQUVkSFYwRldSVjlRVWs5VVQwTlBURjlEVlZOVVQwMWZNd0JIUjFkQlZrVmZVRkpQVkU5RFQweGZRMVZUVkU5Tlh6SUFSMGRYUVZaRlgxTkJUVkJNUlY5R1QxSk5RVlJmUmpNeUFFZEhWMEZXUlY5UVVrOVVUME5QVEY5RFZWTlVUMDFmTVFCSFIxZEJWa1ZmVUZKUFZFOURUMHhmUTFWVFZFOU5YekFBTGdBb2JuVnNiQ2tBUlhKeWIzSTZJR05oY0hSMWNtVWdjMkZ0Y0d4bElISmhkR1VnS0NWbklFaDZLU0J0ZFhOMElHSmxJRDQ5SUNWbklFaDZDZ0JGY25KdmNqb2dZMkZ3ZEhWeVpTQnpZVzF3YkdVZ2NtRjBaU0FvSldjZ1NIb3BJRzExYzNRZ1ltVWdQRDBnSldjZ1NIb0tBRVZ5Y205eU9pQm1ZV2xzWldRZ2RHOGdZMjl0Y0hWMFpTQjBhR1VnYzJsNlpTQnZaaUIwYUdVZ2NtVnhkV2x5WldRZ2JXVnRiM0o1Q2dCVWNuVnVZMkYwYVc1bklHUmhkR0VnWm5KdmJTQWxaQ0IwYnlBbFpDQmllWFJsY3dvQVEyRnVibTkwSUdSbFkyOWtaU0IzYUdsc1pTQjBjbUZ1YzIxcGRIUnBibWNLQUZSNElHbHpJR1JwYzJGaWJHVmtJQzBnWTJGdWJtOTBJSFJ5WVc1emJXbDBJR1JoZEdFZ2QybDBhQ0IwYUdseklFZEhWMkYyWlNCcGJuTjBZVzVqWlFvQVVuZ2dhWE1nWkdsellXSnNaV1FnTFNCallXNXViM1FnY21WalpXbDJaU0JrWVhSaElIZHBkR2dnZEdocGN5QkhSMWRoZG1VZ2FXNXpkR0Z1WTJVS0FGQnliM1J2WTI5c0lDVmtJR2x6SUc1dmRDQmxibUZpYkdWa0lDMGdiV0ZyWlNCemRYSmxJSFJ2SUdWdVlXSnNaU0JwZENCaVpXWnZjbVVnWTNKbFlYUnBibWNnZEdobElHbHVjM1JoYm1ObENnQk5iMjV2TFhSdmJtVWdjSEp2ZEc5amIyeHpJSGRwZEdnZ2RtRnlhV0ZpYkdVZ2JHVnVaM1JvSUdGeVpTQnViM1FnYzNWd2NHOXlkR1ZrQ2dCR1lXbHNaV1FnZEc4Z2FXNXBkR2xoYkdsNlpTQlVlQ0IwY21GdWMyMXBjM05wYjI0Z1ptOXlJRWRIVjJGMlpTQnBibk4wWVc1alpTQWxaQW9BU1c1MllXeHBaQ0JIUjFkaGRtVWdhVzV6ZEdGdVkyVWdKV1FLQUVaaGFXeGxaQ0IwYnlCbGJtTnZaR1VnWkdGMFlTQXRJRWRIVjJGMlpTQnBibk4wWVc1alpTQWxaQW9BUm1GcGJHVmtJSFJ2SUdSbFkyOWtaU0JrWVhSaElDMGdSMGRYWVhabElHbHVjM1JoYm1ObElDVmtDZ0JHWVdsc1pXUWdkRzhnWm5KbFpTQkhSMWRoZG1VZ2FXNXpkR0Z1WTJVZ0xTQnBiblpoYkdsa0lFZEhWMkYyWlNCcGJuTjBZVzVqWlNCcFpDQWxaQW9BYmlBOUlDVmtMQ0J1UVdOMGRXRnNJRDBnSldRS0FGSmxZMlZwZG1Wa0lHVnVaQ0J0WVhKclpYSXVJRVp5WVcxbGN5QnNaV1owSUQwZ0pXUXNJSEpsWTI5eVpHVmtJRDBnSldRS0FFVnljbTl5T2lCbVlXbHNaV1FnZEc4Z1lXeHNiMk5oZEdVZ2RHaGxJSEpsY1hWcGNtVmtJRzFsYlc5eWVUb2dKV1FLQUVsdWRtRnNhV1FnY0dGNWJHOWhaQ0JzWlc1bmRHZzZJQ1ZrTENCdFlYZzZJQ1ZrQ2dCSmJuWmhiR2xrSUhOaGJYQnNaWE1nY0dWeUlHWnlZVzFsT2lBbFpDd2diV0Y0T2lBbFpBb0FTVzUyWVd4cFpDQnZjaUIxYm5OMWNIQnZjblJsWkNCd2JHRjVZbUZqYXlCellXMXdiR1VnWm05eWJXRjBPaUFsWkFvQVNXNTJZV3hwWkNCdmNpQjFibk4xY0hCdmNuUmxaQ0JqWVhCMGRYSmxJSE5oYlhCc1pTQm1iM0p0WVhRNklDVmtDZ0JKYm5aaGJHbGtJSE5oYlhCc1pTQm1iM0p0WVhRNklDVmtDZ0JPWldkaGRHbDJaU0JrWVhSaElITnBlbVU2SUNWa0NnQkZjbkp2Y2pvZ1ptRnBiR1ZrSUhSdklHRnNiRzlqWVhSbElHMWxiVzl5ZVNBdElHaGxZWEJUYVhwbE1Eb2dKV1FzSUdobFlYQlRhWHBsT2lBbFpBb0FTVzUyWVd4cFpDQjJiMngxYldVNklDVmtDZ0JKYm5aaGJHbGtJSEJ5YjNSdlkyOXNJRWxFT2lBbFpBb0FVbVZqWldsMmFXNW5JSE52ZFc1a0lHUmhkR0VnTGk0dUNnQkJibUZzZVhwcGJtY2dZMkZ3ZEhWeVpXUWdaR0YwWVNBdUxnb0FSbUZwYkdWa0lIUnZJR055WldGMFpTQkhSMWRoZG1VZ2FXNXpkR0Z1WTJVZ0xTQnlaV0ZqYUdWa0lHMWhlR2x0ZFcwZ2JuVnRZbVZ5SUc5bUlHbHVjM1JoYm1ObGN5QW9KV1FwQ2dCR1lXbHNkWEpsSUdSMWNtbHVaeUJqWVhCMGRYSmxJQzBnY0hKdmRtbGtaV1FnWW5sMFpYTWdLQ1ZrS1NCaGNtVWdibTkwSUcxMWJIUnBjR3hsSUc5bUlITmhiWEJzWlNCemFYcGxJQ2dsWkNrS0FFUmxZMjlrWldRZ2JHVnVaM1JvSUQwZ0pXUXNJSEJ5YjNSdlkyOXNJRDBnSnlWekp5QW9KV1FwQ2dCRmNuSnZjam9nZEc5MFlXd2diR1Z1WjNSb0lDVmtJQ2h3WVhsc2IyRmtJQ1ZrSUNzZ1JVTkRJQ1ZrSUdKNWRHVnpLU0JwY3lCMGIyOGdiR0Z5WjJVZ0tDQStJQ1ZrS1FvQVJtRnBiR1ZrSUhSdklHTmhjSFIxY21VZ2MyOTFibVFnWkdGMFlTNGdVR3hsWVhObElIUnllU0JoWjJGcGJpQW9iR1Z1WjNSb0lEMGdKV1FwQ2dCU1pXTmxhWFpsWkNCemIzVnVaQ0JrWVhSaElITjFZMk5sYzNObWRXeHNlVG9nSnlWekp3b0FNVGxuWjNkaGRtVmZVMkZ0Y0d4bFJtOXliV0YwQUFBQUFQd29BQUNMRWdBQU1UZG5aM2RoZG1WZlVISnZkRzlqYjJ4SlpBRDhLQUFBckJJQUFERTNaMmQzWVhabFgxQmhjbUZ0WlhSbGNuTUFTQ2tBQU1nU0FBQnBBSFpwQUdscGFRQjJhV2xwQUdacGFRQjJhV2xtQUFEY0VnQUFhV2tBQUpnb0FBRGNFZ0FBUkNnQUFKZ29BQUIyYVdrQVRqRXdaVzF6WTNKcGNIUmxiakV4YldWdGIzSjVYM1pwWlhkSlkwVkZBQUJJS1FBQUdCTUFBR2dUQUFDWUtBQUE0Qk1BQU1BU0FBQ1lLQUFBVGpFd1pXMXpZM0pwY0hSbGJqTjJZV3hGQUFCSUtRQUFWQk1BQUU1VGRETmZYekl4TW1KaGMybGpYM04wY21sdVowbGpUbE5mTVRGamFHRnlYM1J5WVdsMGMwbGpSVVZPVTE4NVlXeHNiMk5oZEc5eVNXTkZSVVZGQUU1VGRETmZYekl5TVY5ZlltRnphV05mYzNSeWFXNW5YMk52YlcxdmJrbE1ZakZGUlVVQUFBQUFTQ2tBQUs4VEFBRE1LUUFBY0JNQUFBQUFBQUFCQUFBQTJCTUFBQUFBQUFCcGFXbHBhV2tBQUdnVEFBQ1lLQUFBNEJNQUFHbHBhV2tBQUFBQVJDZ0FBRVFvQUFEQUVnQUFtQ2dBUWJBb0M2Y2lscCswcnh1UjNzVkZkZWd1RHpKS1g3UldsY3QvYWxScVNQSUxlODM3azIwOGQxN0RNMGZBOFhFeU15YzFhRWNmVHF3alFsOEFONlJRYlVna2tYeWhUZ0FBQVJrQ01ockdBOTh6N2h0b3gwc0VaT0FPTkkzdmdSekJhZmpJQ0V4eEJZcGxMK0VrRHlFMWs0N2E4QktDUlIyMXduMXFKL201eVpvSmVFM2tjcVlHdjR0aVp0MHcvZUtZSmJNUWtTS0lOdENVem8rVzI3M3gwaE5jZ3poR1FCNUN0cVBEU0g1dWF6b29WUHFGdWozS1hwdWZDaFY1SzA3VTVheHo4NmRYQjNEQTk0eUFZdzFuU3Q3dE1jWCtHT09sbVhjbXVMUjhFVVNTMlNNZ2lTNDNQOUZibGJ6UHpaQ0hsN0xjL0w1aDhsYlRxeFFxWFo2RVBEbFRSMjFCb2g4dFE5aTNlNlIyeEJkSjdIOE1iL1pzb1R0U0taMVZxdnRnaHJHN3pENWF5MWxmc0p5cG9GRUw5UmJyZW5VczEwK3UxZW5tNTYzb2ROYjA2cWhRV0s4QkFnUUlFQ0JBZ0IwNmRPak5oeE1tVEpndFdyUjE2c21QQXdZTUdEQmd3SjBuVHB3bFNwUTFhdFMxZCs3Qm55TkdqQVVLRkNoUW9GMjZhZEs1Yjk2aFg3NWh3cGt2WHJ4bHlva1BIang0OFAzbjA3dHIxckYvL3VIZm8xdTJjZUxacjBPR0VTSkVpQTBhTkdqUXZXZk9nUjgrZlBqdHg1TTdkdXpGbHpObXpJVVhMbHk0YmRxcFQ1NGhRb1FWS2xTb1Rab3BVcVJWcWttU09YTGsxYmR6NXRHL1k4YVJQMzc4NWRlemUvYngvK1BicTB1V01XTEVsVGR1M0tWWHJrR0NHVEpreUkwSERodzRjT0RkcDFPbVVhSlpzbm55K2UvRG15dFdyRVdLQ1JJa1NKQTlldlQxOS9QNzY4dUxDeFlzV0xCOSt1blBneHMyYk5pdFI0NEJBZ1FJRUNCQWdCMDZkT2pOaHhNbVRKZ3RXclIxNnNtUEF3WU1HREJnd0owblRwd2xTcFExYXRTMWQrN0JueU5HakFVS0ZDaFFvRjI2YWRLNWI5NmhYNzVod3BrdlhyeGx5b2tQSGp4NDhQM24wN3RyMXJGLy91SGZvMXUyY2VMWnIwT0dFU0pFaUEwYU5HalF2V2ZPZ1I4K2ZQanR4NU03ZHV6Rmx6Tm16SVVYTGx5NGJkcXBUNTRoUW9RVktsU29UWm9wVXFSVnFrbVNPWExrMWJkejV0Ry9ZOGFSUDM3ODVkZXplL2J4LytQYnEwdVdNV0xFbFRkdTNLVlhya0dDR1RKa3lJMEhEaHc0Y09EZHAxT21VYUpac25ueStlL0RteXRXckVXS0NSSWtTSkE5ZXZUMTkvUDc2OHVMQ3hZc1dMQjkrdW5QZ3hzMmJOaXRSNDRCQWdBQUFBQUJBQUFBQVFBQUFBSUFBQUFDQUFBQUJBQUFBRTVUZEROZlh6SXhNbUpoYzJsalgzTjBjbWx1WjBsb1RsTmZNVEZqYUdGeVgzUnlZV2wwYzBsb1JVVk9VMTg1WVd4c2IyTmhkRzl5U1doRlJVVkZBQURNS1FBQWlCY0FBQUFBQUFBQkFBQUEyQk1BQUFBQUFBQk9VM1F6WDE4eU1USmlZWE5wWTE5emRISnBibWRKZDA1VFh6RXhZMmhoY2w5MGNtRnBkSE5KZDBWRlRsTmZPV0ZzYkc5allYUnZja2wzUlVWRlJRQUF6Q2tBQU9BWEFBQUFBQUFBQVFBQUFOZ1RBQUFBQUFBQVRsTjBNMTlmTWpFeVltRnphV05mYzNSeWFXNW5TVVJ6VGxOZk1URmphR0Z5WDNSeVlXbDBjMGxFYzBWRlRsTmZPV0ZzYkc5allYUnZja2xFYzBWRlJVVUFBQURNS1FBQU9CZ0FBQUFBQUFBQkFBQUEyQk1BQUFBQUFBQk9VM1F6WDE4eU1USmlZWE5wWTE5emRISnBibWRKUkdsT1UxOHhNV05vWVhKZmRISmhhWFJ6U1VScFJVVk9VMTg1WVd4c2IyTmhkRzl5U1VScFJVVkZSUUFBQU13cEFBQ1VHQUFBQUFBQUFBRUFBQURZRXdBQUFBQUFBRTR4TUdWdGMyTnlhWEIwWlc0eE1XMWxiVzl5ZVY5MmFXVjNTV0ZGUlFBQVNDa0FBUEFZQUFCT01UQmxiWE5qY21sd2RHVnVNVEZ0WlcxdmNubGZkbWxsZDBsb1JVVUFBRWdwQUFBWUdRQUFUakV3WlcxelkzSnBjSFJsYmpFeGJXVnRiM0o1WDNacFpYZEpjMFZGQUFCSUtRQUFRQmtBQUU0eE1HVnRjMk55YVhCMFpXNHhNVzFsYlc5eWVWOTJhV1YzU1hSRlJRQUFTQ2tBQUdnWkFBQk9NVEJsYlhOamNtbHdkR1Z1TVRGdFpXMXZjbmxmZG1sbGQwbHBSVVVBQUVncEFBQ1FHUUFBVGpFd1pXMXpZM0pwY0hSbGJqRXhiV1Z0YjNKNVgzWnBaWGRKYWtWRkFBQklLUUFBdUJrQUFFNHhNR1Z0YzJOeWFYQjBaVzR4TVcxbGJXOXllVjkyYVdWM1NXeEZSUUFBU0NrQUFPQVpBQUJPTVRCbGJYTmpjbWx3ZEdWdU1URnRaVzF2Y25sZmRtbGxkMGx0UlVVQUFFZ3BBQUFJR2dBQVRqRXdaVzF6WTNKcGNIUmxiakV4YldWdGIzSjVYM1pwWlhkSlprVkZBQUJJS1FBQU1Cb0FBRTR4TUdWdGMyTnlhWEIwWlc0eE1XMWxiVzl5ZVY5MmFXVjNTV1JGUlFBQVNDa0FBRmdhQUFBREFBQUFCQUFBQUFRQUFBQUdBQUFBZy9taUFFUk9iZ0Q4S1JVQTBWY25BTjAwOVFCaTI4QUFQSm1WQUVHUVF3QmpVZjRBdTk2ckFMZGh4UUE2YmlRQTBrMUNBRWtHNEFBSjZpNEFISkxSQU9zZC9nQXBzUndBNkQ2bkFQVTFnZ0JFdXk0QW5PbUVBTFFtY0FCQmZsOEExcEU1QUZPRE9RQ2M5RGtBaTErRUFDajV2UUQ0SHpzQTN2K1hBQStZQlFBUkwrOEFDbHFMQUcwZmJRRFBmallBQ2NzbkFFWlB0d0NlWmo4QUxlcGZBTG9uZFFEbDY4Y0FQWHZ4QVBjNUJ3Q1NVb29BKzJ2cUFCK3hYd0FJWFkwQU1BTldBSHY4UmdEd3Eyc0FJTHpQQURiMG1nRGpxUjBBWG1HUkFBZ2I1Z0NGbVdVQW9CUmZBSTFBYUFDQTJQOEFKM05OQUFZR01RREtWaFVBeWFoekFIdmlZQUJyak1BQUdjUkhBTTFud3dBSjZOd0FXWU1xQUl0MnhBQ21ISllBUksvZEFCbFgwUUNsUGdVQUJRZi9BRE4rUHdEQ011Z0FtRS9lQUx0OU1nQW1QY01BSG12dkFKLzRYZ0ExSHpvQWYvTEtBUEdISFFCOGtDRUFhaVI4QU5WdStnQXdMWGNBRlR0REFMVVV4Z0RER1owQXJjVENBQ3hOUVFBTUFGMEFobjFHQU9OeExRQ2J4cG9BTTJJQUFMVFNmQUMwcDVjQU4xWFZBTmMrOWdDakVCZ0FUWGI4QUdTZEtnQncxNnNBWTN6NEFIcXdWd0FYRmVjQXdFbFdBRHZXMlFDbmhEZ0FKQ1BMQU5hS2R3QmFWQ01BQUIrNUFQRUtHd0FaenQ4QW56SC9BR1llYWdDWlYyRUFyUHRIQUg1LzJBQWlaYmNBTXVpSkFPYS9ZQUR2eE0wQWJEWUpBRjAvMUFBVzN0Y0FXRHZlQU42YmtnRFNJaWdBS0lib0FPSllUUURHeWpJQUNPTVdBT0I5eXdBWHdGQUE4eDJuQUJqZ1d3QXVFelFBZ3hKaUFJTklBUUQxamxzQXJiQi9BQjdwOGdCSVNrTUFFR2ZUQUtyZDJBQ3VYMElBYW1IT0FBb29wQURUbWJRQUJxYnlBRngzZndDandvTUFZVHlJQUlwemVBQ3ZqRm9BYjllOUFDMm1Zd0QwdjhzQWpZSHZBQ2JCWndCVnlrVUF5dGsyQUNpbzBnRENZWTBBRXNsM0FBUW1GQUFTUnBzQXhGbkVBTWpGUkFCTnNwRUFBQmZ6QU5SRHJRQXBTZVVBL2RVUUFBQysvQUFlbE13QWNNN3VBQk0rOVFEczhZQUFzK2ZEQU1mNEtBQ1RCWlFBd1hFK0FDNEpzd0FMUmZNQWlCS2NBS3NnZXdBdXRaOEFSNUxDQUhzeUx3QU1WVzBBY3FlUUFHdm5Id0F4eTVZQWVSWktBRUY1NGdEMDM0a0E2SlNYQU9MbWhBQ1pNWmNBaU8xckFGOWZOZ0M3L1E0QVNKcTBBR2VrYkFCeGNrSUFqVjB5QUo4VnVBQzg1UWtBalRFbEFQZDBPUUF3QlJ3QURRd0JBRXNJYUFBczdsZ0FSNnFRQUhUbkFnQzkxaVFBOTMybUFHNUljZ0NmRnU4QWpwU21BTFNSOWdEUlUxRUF6d3J5QUNDWU13RDFTMzRBc21Ob0FOMCtYd0JBWFFNQWhZbC9BRlZTS1FBM1pNQUFiZGdRQURKSU1nQmJUSFVBVG5IVUFFVlViZ0FMQ2NFQUt2VnBBQlJtMVFBbkI1MEFYUVJRQUxRNzJ3RHFkc1VBaC9rWEFFbHJmUUFkSjdvQWxta3BBTWJNckFDdEZGUUFrT0pxQUlqWmlRQXNjbEFBQktTK0FIY0hsQUR6TUhBQUFQd25BT3B4cUFCbXdra0FaT0E5QUpmZGd3Q2pQNWNBUTVUOUFBMkdqQUF4UWQ0QWtqbWRBTjF3akFBWHQrY0FDTjg3QUJVM0t3QmNnS0FBV29DVEFCQVJrZ0FQNk5nQWJJQ3ZBTnYvU3dBNGtBOEFXUmgyQUdLbEZRQmh5N3NBeDRtNUFCQkF2UURTOGdRQVNYVW5BT3UyOWdEYklyc0FDaFNxQUlrbUx3QmtnM1lBQ1RzekFBNlVHZ0JST3FvQUhhUENBSy90cmdCY0poSUFiY0pOQUMxNm5BREFWcGNBQXorREFBbnc5Z0FyUUl3QWJUR1pBRG0wQndBTUlCVUEyTU5iQVBXU3hBREdyVXNBVHNxbEFLYzN6UURtcVRZQXE1S1VBTjFDYUFBWlk5NEFkb3p2QUdpTFVnRDgyemNBcnFHckFOOFZNUUFBcnFFQURQdmFBR1JOWmdEdEJiY0FLV1V3QUZkV3Z3Qkgvem9BYXZtNUFIVys4d0Fvazk4QXE0QXdBR2FNOWdBRXl4VUEraUlHQU5ua0hRQTlzNlFBVnh1UEFEYk5DUUJPUXVrQUU3NmtBRE1qdFFEd3Fob0FUMldvQU5MQnBRQUxQdzhBVzNqTkFDUDVkZ0I3aXdRQWlSZHlBTWFtVXdCdmJ1SUE3K3NBQUp0S1dBREUycmNBcW1hNkFIYlB6d0RSQWgwQXNmRXRBSXlad1FERHJYY0Foa2phQVBkZG9BREdnUFFBclBBdkFOM3NtZ0EvWEx3QTBONXRBSkRISHdBcTI3WUFveVU2QUFDdm1nQ3RVNU1BdGxjRUFDa3R0QUJMZ0g0QTJnZW5BSGFxRGdCN1dhRUFGaElxQU55M0xRRDY1ZjBBaWR2K0FJbSsvUURrZG13QUJxbjhBRDZBY0FDRmJoVUEvWWYvQUNnK0J3Qmhaek1BS2hpR0FFMjk2Z0N6NTY4QWoyMXVBSlZuT1FBeHYxc0FoTmRJQUREZkZnREhMVU1BSldFMUFNbHd6Z0F3eTdnQXYyejlBS1FBb2dBRmJPUUFXdDJnQUNGdlJ3QmlFdElBdVZ5RUFIQmhTUUJyVnVBQW1WSUJBRkJWTndBZTFiY0FNL0hFQUJOdVh3QmRNT1FBaFM2cEFCMnl3d0NoTWpZQUNMZWtBT3F4MUFBVzl5RUFqMm5rQUNmL2R3QU1BNEFBalVBdEFFL05vQUFncFprQXM2TFRBQzlkQ2dDMCtVSUFFZHJMQUgyKzBBQ2IyOEVBcXhlOUFNcWlnUUFJYWx3QUxsVVhBQ2NBVlFCL0ZQQUE0UWVHQUJRTFpBQ1dRWTBBaDc3ZUFOcjlLZ0JySmJZQWU0azBBQVh6L2dDNXY1NEFhR3BQQUVvcXFBQlB4Rm9BTGZpOEFOZGFtQUQweDVVQURVMk5BQ0E2cGdDa1YxOEFGRCt4QUlBNGxRRE1JQUVBY2QyR0FNbmV0Z0MvWVBVQVRXVVJBQUVIYXdDTXNLd0Fzc0RRQUZGVlNBQWUrdzRBbFhMREFLTUdPd0RBUURVQUJ0eDdBT0JGekFCT0tmb0Exc3JJQU9qelFRQjhaTjRBbTJUWUFObStNUUNrbDhNQWQxalVBR25qeFFEdzJoTUF1am84QUVZWVJnQlZkVjhBMHIzMUFHNlN4Z0NzTGwwQURrVHRBQncrUWdCaHhJY0FLZjNwQU9mVzh3QWlmTW9BYjVFMUFBamd4UUQvMTQwQWJtcmlBTEQ5eGdDVENNRUFmRjEwQUd1dHNnRE5icDBBUG5KN0FNWVJhZ0QzejZrQUtYUGZBTFhKdWdDM0FGRUE0cklOQUhTNkpBRGxmV0FBZE5pS0FBMFZMQUNCR0F3QWZtYVVBQUVwRmdDZmVuWUEvZjIrQUZaRjd3RFpmallBN05rVEFJdTZ1UURFbC93QU1hZ25BUEZ1d3dDVXhUWUEyS2hXQUxTb3RRRFB6QTRBRW9rdEFHOVhOQUFzVm9rQW1jN2pBTllndVFCclhxb0FQaXFjQUJGZnpBRDlDMG9BNGZUN0FJNDdiUURpaGl3QTZkU0VBUHkwcVFEdjd0RUFMalhKQUM4NVlRQTRJVVFBRzluSUFJSDhDZ0Q3U21vQUx4ellBRk8waEFCT21Zd0FWQ0xNQUNwVjNBREF4dFlBQ3htV0FCcHd1QUJwbFdRQUpscGdBRDlTN2dCL0VROEE5TFVSQVB6TDlRQTB2QzBBTkx6dUFPaGR6QURkWG1BQVo0NmJBSkl6N3dESkY3Z0FZVmliQU9GWHZBQlJnOFlBMkQ0UUFOMXhTQUF0SE4wQXJ4aWhBQ0VzUmdCWjg5Y0EyWHFZQUo1VXdBQlBodm9BVmdiOEFPVjVyZ0NKSWpZQU9LMGlBR2VUM0FCVjZLb0FnaVk0QU1ybm13QlJEYVFBbVRPeEFLblhEZ0JwQlVnQVpiTHdBSCtJcHdDSVRKY0ErZEUyQUNHU3N3Qjdna29BbU04aEFFQ2YzQURjUjFVQTRYUTZBR2ZyUWdEK25kOEFYdFJmQUh0bnBBQzZySG9BVmZhaUFDdUlJd0JCdWxVQVdXNElBQ0VxaGdBNVI0TUFpZVBtQU9XZTFBQkorMEFBLzFicEFCd1B5Z0RGV1lvQWxQb3JBTlBCeFFBUHhjOEEyMXF1QUVmRmhnQ0ZRMklBSVlZN0FDeDVsQUFRWVljQUtreDdBSUFzR2dCRHZ4SUFpQ2FRQUhnOGlRQ294T1FBNWR0N0FNUTZ3Z0FtOU9vQTkyZUtBQTJTdndCbG95c0FQWk94QUwxOEN3Q2tVZHdBSjkxakFHbmgzUUNhbEJrQXFDbVZBR2pPS0FBSjdiUUFSSjhnQUU2WXlnQndnbU1BZm53akFBKzVNZ0NuOVk0QUZGYm5BQ0h4Q0FDMW5Tb0FiMzVOQUtVWlVRQzErYXNBZ3QvV0FKYmRZUUFXTmdJQXhEcWZBSU9pb1FCeTdXMEFPWTE2QUlLNHFRQnJNbHdBUmlkYkFBQTA3UURTQUhjQS9QUlZBQUZaVFFEZ2NZQUFRZVBLQUFzL1FQc2grVDhBQUFBQUxVUjBQZ0FBQUlDWVJ2ZzhBQUFBWUZITWVEc0FBQUNBZ3h2d09RQUFBRUFnSlhvNEFBQUFnQ0tDNHpZQUFBQUFIZk5wTldBcUFFR3d5d0FMUVJrQUNnQVpHUmtBQUFBQUJRQUFBQUFBQUFrQUFBQUFDd0FBQUFBQUFBQUFHUUFSQ2hrWkdRTUtCd0FCQUFrTEdBQUFDUVlMQUFBTEFBWVpBQUFBR1JrWkFFR0J6QUFMSVE0QUFBQUFBQUFBQUJrQUNnMFpHUmtBRFFBQUFnQUpEZ0FBQUFrQURnQUFEZ0JCdTh3QUN3RU1BRUhIekFBTEZSTUFBQUFBRXdBQUFBQUpEQUFBQUFBQURBQUFEQUJCOWN3QUN3RVFBRUdCelFBTEZROEFBQUFFRHdBQUFBQUpFQUFBQUFBQUVBQUFFQUJCcjgwQUN3RVNBRUc3elFBTEhoRUFBQUFBRVFBQUFBQUpFZ0FBQUFBQUVnQUFFZ0FBR2dBQUFCb2FHZ0JCOHMwQUN3NGFBQUFBR2hvYUFBQUFBQUFBQ1FCQm84NEFDd0VVQUVHdnpnQUxGUmNBQUFBQUZ3QUFBQUFKRkFBQUFBQUFGQUFBRkFCQjNjNEFDd0VXQUVIcHpnQUx6UVVWQUFBQUFCVUFBQUFBQ1JZQUFBQUFBQllBQUJZQUFEQXhNak0wTlRZM09EbEJRa05FUlVaT01UQmZYMk40ZUdGaWFYWXhNVFpmWDNOb2FXMWZkSGx3WlY5cGJtWnZSUUFBQUFCd0tRQUFrQ2NBQURBcUFBQk9NVEJmWDJONGVHRmlhWFl4TVRkZlgyTnNZWE56WDNSNWNHVmZhVzVtYjBVQUFBQndLUUFBd0NjQUFMUW5BQUFBQUFBQU5DZ0FBQ0FBQUFBaEFBQUFJZ0FBQUNNQUFBQWtBQUFBVGpFd1gxOWplSGhoWW1sMk1USXpYMTltZFc1a1lXMWxiblJoYkY5MGVYQmxYMmx1Wm05RkFIQXBBQUFNS0FBQXRDY0FBSFlBQUFENEp3QUFRQ2dBQUdJQUFBRDRKd0FBVENnQUFHTUFBQUQ0SndBQVdDZ0FBR2dBQUFENEp3QUFaQ2dBQUdFQUFBRDRKd0FBY0NnQUFITUFBQUQ0SndBQWZDZ0FBSFFBQUFENEp3QUFpQ2dBQUdrQUFBRDRKd0FBbENnQUFHb0FBQUQ0SndBQW9DZ0FBR3dBQUFENEp3QUFyQ2dBQUcwQUFBRDRKd0FBdUNnQUFIZ0FBQUQ0SndBQXhDZ0FBSGtBQUFENEp3QUEwQ2dBQUdZQUFBRDRKd0FBM0NnQUFHUUFBQUQ0SndBQTZDZ0FBQUFBQUFBMEtRQUFJQUFBQUNVQUFBQWlBQUFBSXdBQUFDWUFBQUJPTVRCZlgyTjRlR0ZpYVhZeE1UWmZYMlZ1ZFcxZmRIbHdaVjlwYm1adlJRQUFBQUJ3S1FBQUVDa0FBTFFuQUFBQUFBQUE1Q2NBQUNBQUFBQW5BQUFBSWdBQUFDTUFBQUFvQUFBQUtRQUFBQ29BQUFBckFBQUFBQUFBQUxncEFBQWdBQUFBTEFBQUFDSUFBQUFqQUFBQUtBQUFBQzBBQUFBdUFBQUFMd0FBQUU0eE1GOWZZM2g0WVdKcGRqRXlNRjlmYzJsZlkyeGhjM05mZEhsd1pWOXBibVp2UlFBQUFBQndLUUFBa0NrQUFPUW5BQUFBQUFBQUZDb0FBQ0FBQUFBd0FBQUFJZ0FBQUNNQUFBQW9BQUFBTVFBQUFESUFBQUF6QUFBQVRqRXdYMTlqZUhoaFltbDJNVEl4WDE5MmJXbGZZMnhoYzNOZmRIbHdaVjlwYm1adlJRQUFBSEFwQUFEc0tRQUE1Q2NBQUZOME9YUjVjR1ZmYVc1bWJ3QUFBQUJJS1FBQUlDb0FRYmpVQUFzcC8vLy8vd0NBTzBjQWdEdEhBSUE3UndBRUFBQUFBRUJBQlFBQUFBVUFBQUFHQUFBQUFBQUFBQVVBUWV6VUFBc0JHZ0JCaE5VQUN3b2JBQUFBSEFBQUFQa3ZBRUdjMVFBTEFRSUFRYXpWQUFzSS8vLy8vLy8vLy84QVFmRFZBQXNCQlFCQi9OVUFDd0VkQUVHVTFnQUxEaHNBQUFBZUFBQUFDREFBQUFBRUFFR3MxZ0FMQVFFQVFieldBQXNGLy8vLy93b0FRWURYQUFzRHNEWlEiO2lmKCFpc0RhdGFVUkkod2FzbUJpbmFyeUZpbGUpKXt3YXNtQmluYXJ5RmlsZT1sb2NhdGVGaWxlKHdhc21CaW5hcnlGaWxlKX1mdW5jdGlvbiBnZXRCaW5hcnkoZmlsZSl7dHJ5e2lmKGZpbGU9PXdhc21CaW5hcnlGaWxlJiZ3YXNtQmluYXJ5KXtyZXR1cm4gbmV3IFVpbnQ4QXJyYXkod2FzbUJpbmFyeSl9dmFyIGJpbmFyeT10cnlQYXJzZUFzRGF0YVVSSShmaWxlKTtpZihiaW5hcnkpe3JldHVybiBiaW5hcnl9aWYocmVhZEJpbmFyeSl7cmV0dXJuIHJlYWRCaW5hcnkoZmlsZSl9ZWxzZXt0aHJvdyJib3RoIGFzeW5jIGFuZCBzeW5jIGZldGNoaW5nIG9mIHRoZSB3YXNtIGZhaWxlZCJ9fWNhdGNoKGVycil7YWJvcnQoZXJyKX19ZnVuY3Rpb24gZ2V0QmluYXJ5UHJvbWlzZSgpe2lmKCF3YXNtQmluYXJ5JiYoRU5WSVJPTk1FTlRfSVNfV0VCfHxFTlZJUk9OTUVOVF9JU19XT1JLRVIpKXtpZih0eXBlb2YgZmV0Y2g9PT0iZnVuY3Rpb24iJiYhaXNGaWxlVVJJKHdhc21CaW5hcnlGaWxlKSl7cmV0dXJuIGZldGNoKHdhc21CaW5hcnlGaWxlLHtjcmVkZW50aWFsczoic2FtZS1vcmlnaW4ifSkudGhlbihmdW5jdGlvbihyZXNwb25zZSl7aWYoIXJlc3BvbnNlWyJvayJdKXt0aHJvdyJmYWlsZWQgdG8gbG9hZCB3YXNtIGJpbmFyeSBmaWxlIGF0ICciK3dhc21CaW5hcnlGaWxlKyInIn1yZXR1cm4gcmVzcG9uc2VbImFycmF5QnVmZmVyIl0oKX0pLmNhdGNoKGZ1bmN0aW9uKCl7cmV0dXJuIGdldEJpbmFyeSh3YXNtQmluYXJ5RmlsZSl9KX1lbHNle2lmKHJlYWRBc3luYyl7cmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uKHJlc29sdmUscmVqZWN0KXtyZWFkQXN5bmMod2FzbUJpbmFyeUZpbGUsZnVuY3Rpb24ocmVzcG9uc2Upe3Jlc29sdmUobmV3IFVpbnQ4QXJyYXkocmVzcG9uc2UpKX0scmVqZWN0KX0pfX19cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oZnVuY3Rpb24oKXtyZXR1cm4gZ2V0QmluYXJ5KHdhc21CaW5hcnlGaWxlKX0pfWZ1bmN0aW9uIGNyZWF0ZVdhc20oKXt2YXIgaW5mbz17ImEiOmFzbUxpYnJhcnlBcmd9O2Z1bmN0aW9uIHJlY2VpdmVJbnN0YW5jZShpbnN0YW5jZSxtb2R1bGUpe3ZhciBleHBvcnRzPWluc3RhbmNlLmV4cG9ydHM7TW9kdWxlWyJhc20iXT1leHBvcnRzO3dhc21NZW1vcnk9TW9kdWxlWyJhc20iXVsiQSJdO3VwZGF0ZUdsb2JhbEJ1ZmZlckFuZFZpZXdzKHdhc21NZW1vcnkuYnVmZmVyKTt3YXNtVGFibGU9TW9kdWxlWyJhc20iXVsiQyJdO2FkZE9uSW5pdChNb2R1bGVbImFzbSJdWyJCIl0pO3JlbW92ZVJ1bkRlcGVuZGVuY3koIndhc20taW5zdGFudGlhdGUiKX1hZGRSdW5EZXBlbmRlbmN5KCJ3YXNtLWluc3RhbnRpYXRlIik7ZnVuY3Rpb24gcmVjZWl2ZUluc3RhbnRpYXRpb25SZXN1bHQocmVzdWx0KXtyZWNlaXZlSW5zdGFuY2UocmVzdWx0WyJpbnN0YW5jZSJdKX1mdW5jdGlvbiBpbnN0YW50aWF0ZUFycmF5QnVmZmVyKHJlY2VpdmVyKXtyZXR1cm4gZ2V0QmluYXJ5UHJvbWlzZSgpLnRoZW4oZnVuY3Rpb24oYmluYXJ5KXtyZXR1cm4gV2ViQXNzZW1ibHkuaW5zdGFudGlhdGUoYmluYXJ5LGluZm8pfSkudGhlbihmdW5jdGlvbihpbnN0YW5jZSl7cmV0dXJuIGluc3RhbmNlfSkudGhlbihyZWNlaXZlcixmdW5jdGlvbihyZWFzb24pe2VycigiZmFpbGVkIHRvIGFzeW5jaHJvbm91c2x5IHByZXBhcmUgd2FzbTogIityZWFzb24pO2Fib3J0KHJlYXNvbil9KX1mdW5jdGlvbiBpbnN0YW50aWF0ZUFzeW5jKCl7aWYoIXdhc21CaW5hcnkmJnR5cGVvZiBXZWJBc3NlbWJseS5pbnN0YW50aWF0ZVN0cmVhbWluZz09PSJmdW5jdGlvbiImJiFpc0RhdGFVUkkod2FzbUJpbmFyeUZpbGUpJiYhaXNGaWxlVVJJKHdhc21CaW5hcnlGaWxlKSYmdHlwZW9mIGZldGNoPT09ImZ1bmN0aW9uIil7cmV0dXJuIGZldGNoKHdhc21CaW5hcnlGaWxlLHtjcmVkZW50aWFsczoic2FtZS1vcmlnaW4ifSkudGhlbihmdW5jdGlvbihyZXNwb25zZSl7dmFyIHJlc3VsdD1XZWJBc3NlbWJseS5pbnN0YW50aWF0ZVN0cmVhbWluZyhyZXNwb25zZSxpbmZvKTtyZXR1cm4gcmVzdWx0LnRoZW4ocmVjZWl2ZUluc3RhbnRpYXRpb25SZXN1bHQsZnVuY3Rpb24ocmVhc29uKXtlcnIoIndhc20gc3RyZWFtaW5nIGNvbXBpbGUgZmFpbGVkOiAiK3JlYXNvbik7ZXJyKCJmYWxsaW5nIGJhY2sgdG8gQXJyYXlCdWZmZXIgaW5zdGFudGlhdGlvbiIpO3JldHVybiBpbnN0YW50aWF0ZUFycmF5QnVmZmVyKHJlY2VpdmVJbnN0YW50aWF0aW9uUmVzdWx0KX0pfSl9ZWxzZXtyZXR1cm4gaW5zdGFudGlhdGVBcnJheUJ1ZmZlcihyZWNlaXZlSW5zdGFudGlhdGlvblJlc3VsdCl9fWlmKE1vZHVsZVsiaW5zdGFudGlhdGVXYXNtIl0pe3RyeXt2YXIgZXhwb3J0cz1Nb2R1bGVbImluc3RhbnRpYXRlV2FzbSJdKGluZm8scmVjZWl2ZUluc3RhbmNlKTtyZXR1cm4gZXhwb3J0c31jYXRjaChlKXtlcnIoIk1vZHVsZS5pbnN0YW50aWF0ZVdhc20gY2FsbGJhY2sgZmFpbGVkIHdpdGggZXJyb3I6ICIrZSk7cmV0dXJuIGZhbHNlfX1pbnN0YW50aWF0ZUFzeW5jKCkuY2F0Y2gocmVhZHlQcm9taXNlUmVqZWN0KTtyZXR1cm57fX1mdW5jdGlvbiBjYWxsUnVudGltZUNhbGxiYWNrcyhjYWxsYmFja3Mpe3doaWxlKGNhbGxiYWNrcy5sZW5ndGg+MCl7dmFyIGNhbGxiYWNrPWNhbGxiYWNrcy5zaGlmdCgpO2lmKHR5cGVvZiBjYWxsYmFjaz09ImZ1bmN0aW9uIil7Y2FsbGJhY2soTW9kdWxlKTtjb250aW51ZX12YXIgZnVuYz1jYWxsYmFjay5mdW5jO2lmKHR5cGVvZiBmdW5jPT09Im51bWJlciIpe2lmKGNhbGxiYWNrLmFyZz09PXVuZGVmaW5lZCl7Z2V0V2FzbVRhYmxlRW50cnkoZnVuYykoKX1lbHNle2dldFdhc21UYWJsZUVudHJ5KGZ1bmMpKGNhbGxiYWNrLmFyZyl9fWVsc2V7ZnVuYyhjYWxsYmFjay5hcmc9PT11bmRlZmluZWQ/bnVsbDpjYWxsYmFjay5hcmcpfX19dmFyIHdhc21UYWJsZU1pcnJvcj1bXTtmdW5jdGlvbiBnZXRXYXNtVGFibGVFbnRyeShmdW5jUHRyKXt2YXIgZnVuYz13YXNtVGFibGVNaXJyb3JbZnVuY1B0cl07aWYoIWZ1bmMpe2lmKGZ1bmNQdHI+PXdhc21UYWJsZU1pcnJvci5sZW5ndGgpd2FzbVRhYmxlTWlycm9yLmxlbmd0aD1mdW5jUHRyKzE7d2FzbVRhYmxlTWlycm9yW2Z1bmNQdHJdPWZ1bmM9d2FzbVRhYmxlLmdldChmdW5jUHRyKX1yZXR1cm4gZnVuY312YXIgc3RydWN0UmVnaXN0cmF0aW9ucz17fTtmdW5jdGlvbiBydW5EZXN0cnVjdG9ycyhkZXN0cnVjdG9ycyl7d2hpbGUoZGVzdHJ1Y3RvcnMubGVuZ3RoKXt2YXIgcHRyPWRlc3RydWN0b3JzLnBvcCgpO3ZhciBkZWw9ZGVzdHJ1Y3RvcnMucG9wKCk7ZGVsKHB0cil9fWZ1bmN0aW9uIHNpbXBsZVJlYWRWYWx1ZUZyb21Qb2ludGVyKHBvaW50ZXIpe3JldHVybiB0aGlzWyJmcm9tV2lyZVR5cGUiXShIRUFQVTMyW3BvaW50ZXI+PjJdKX12YXIgYXdhaXRpbmdEZXBlbmRlbmNpZXM9e307dmFyIHJlZ2lzdGVyZWRUeXBlcz17fTt2YXIgdHlwZURlcGVuZGVuY2llcz17fTt2YXIgY2hhcl8wPTQ4O3ZhciBjaGFyXzk9NTc7ZnVuY3Rpb24gbWFrZUxlZ2FsRnVuY3Rpb25OYW1lKG5hbWUpe2lmKHVuZGVmaW5lZD09PW5hbWUpe3JldHVybiJfdW5rbm93biJ9bmFtZT1uYW1lLnJlcGxhY2UoL1teYS16QS1aMC05X10vZywiJCIpO3ZhciBmPW5hbWUuY2hhckNvZGVBdCgwKTtpZihmPj1jaGFyXzAmJmY8PWNoYXJfOSl7cmV0dXJuIl8iK25hbWV9ZWxzZXtyZXR1cm4gbmFtZX19ZnVuY3Rpb24gY3JlYXRlTmFtZWRGdW5jdGlvbihuYW1lLGJvZHkpe25hbWU9bWFrZUxlZ2FsRnVuY3Rpb25OYW1lKG5hbWUpO3ZhciBmbj1mdW5jdGlvbigpe3JldHVybiBib2R5LmFwcGx5KHRoaXMsYXJndW1lbnRzKX07dHJ5e09iamVjdC5kZWZpbmVQcm9wZXJ0eShmbiwibmFtZSIse3ZhbHVlOm5hbWV9KX1jYXRjaChlKXt9cmV0dXJuIGZufWZ1bmN0aW9uIGV4dGVuZEVycm9yKGJhc2VFcnJvclR5cGUsZXJyb3JOYW1lKXt2YXIgZXJyb3JDbGFzcz1jcmVhdGVOYW1lZEZ1bmN0aW9uKGVycm9yTmFtZSxmdW5jdGlvbihtZXNzYWdlKXt0aGlzLm5hbWU9ZXJyb3JOYW1lO3RoaXMubWVzc2FnZT1tZXNzYWdlO3ZhciBzdGFjaz1uZXcgRXJyb3IobWVzc2FnZSkuc3RhY2s7aWYoc3RhY2shPT11bmRlZmluZWQpe3RoaXMuc3RhY2s9dGhpcy50b1N0cmluZygpKyJcbiIrc3RhY2sucmVwbGFjZSgvXkVycm9yKDpbXlxuXSopP1xuLywiIil9fSk7ZXJyb3JDbGFzcy5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZShiYXNlRXJyb3JUeXBlLnByb3RvdHlwZSk7ZXJyb3JDbGFzcy5wcm90b3R5cGUuY29uc3RydWN0b3I9ZXJyb3JDbGFzcztlcnJvckNsYXNzLnByb3RvdHlwZS50b1N0cmluZz1mdW5jdGlvbigpe2lmKHRoaXMubWVzc2FnZT09PXVuZGVmaW5lZCl7cmV0dXJuIHRoaXMubmFtZX1lbHNle3JldHVybiB0aGlzLm5hbWUrIjogIit0aGlzLm1lc3NhZ2V9fTtyZXR1cm4gZXJyb3JDbGFzc312YXIgSW50ZXJuYWxFcnJvcj11bmRlZmluZWQ7ZnVuY3Rpb24gdGhyb3dJbnRlcm5hbEVycm9yKG1lc3NhZ2Upe3Rocm93IG5ldyBJbnRlcm5hbEVycm9yKG1lc3NhZ2UpfWZ1bmN0aW9uIHdoZW5EZXBlbmRlbnRUeXBlc0FyZVJlc29sdmVkKG15VHlwZXMsZGVwZW5kZW50VHlwZXMsZ2V0VHlwZUNvbnZlcnRlcnMpe215VHlwZXMuZm9yRWFjaChmdW5jdGlvbih0eXBlKXt0eXBlRGVwZW5kZW5jaWVzW3R5cGVdPWRlcGVuZGVudFR5cGVzfSk7ZnVuY3Rpb24gb25Db21wbGV0ZSh0eXBlQ29udmVydGVycyl7dmFyIG15VHlwZUNvbnZlcnRlcnM9Z2V0VHlwZUNvbnZlcnRlcnModHlwZUNvbnZlcnRlcnMpO2lmKG15VHlwZUNvbnZlcnRlcnMubGVuZ3RoIT09bXlUeXBlcy5sZW5ndGgpe3Rocm93SW50ZXJuYWxFcnJvcigiTWlzbWF0Y2hlZCB0eXBlIGNvbnZlcnRlciBjb3VudCIpfWZvcih2YXIgaT0wO2k8bXlUeXBlcy5sZW5ndGg7KytpKXtyZWdpc3RlclR5cGUobXlUeXBlc1tpXSxteVR5cGVDb252ZXJ0ZXJzW2ldKX19dmFyIHR5cGVDb252ZXJ0ZXJzPW5ldyBBcnJheShkZXBlbmRlbnRUeXBlcy5sZW5ndGgpO3ZhciB1bnJlZ2lzdGVyZWRUeXBlcz1bXTt2YXIgcmVnaXN0ZXJlZD0wO2RlcGVuZGVudFR5cGVzLmZvckVhY2goZnVuY3Rpb24oZHQsaSl7aWYocmVnaXN0ZXJlZFR5cGVzLmhhc093blByb3BlcnR5KGR0KSl7dHlwZUNvbnZlcnRlcnNbaV09cmVnaXN0ZXJlZFR5cGVzW2R0XX1lbHNle3VucmVnaXN0ZXJlZFR5cGVzLnB1c2goZHQpO2lmKCFhd2FpdGluZ0RlcGVuZGVuY2llcy5oYXNPd25Qcm9wZXJ0eShkdCkpe2F3YWl0aW5nRGVwZW5kZW5jaWVzW2R0XT1bXX1hd2FpdGluZ0RlcGVuZGVuY2llc1tkdF0ucHVzaChmdW5jdGlvbigpe3R5cGVDb252ZXJ0ZXJzW2ldPXJlZ2lzdGVyZWRUeXBlc1tkdF07KytyZWdpc3RlcmVkO2lmKHJlZ2lzdGVyZWQ9PT11bnJlZ2lzdGVyZWRUeXBlcy5sZW5ndGgpe29uQ29tcGxldGUodHlwZUNvbnZlcnRlcnMpfX0pfX0pO2lmKDA9PT11bnJlZ2lzdGVyZWRUeXBlcy5sZW5ndGgpe29uQ29tcGxldGUodHlwZUNvbnZlcnRlcnMpfX1mdW5jdGlvbiBfX2VtYmluZF9maW5hbGl6ZV92YWx1ZV9vYmplY3Qoc3RydWN0VHlwZSl7dmFyIHJlZz1zdHJ1Y3RSZWdpc3RyYXRpb25zW3N0cnVjdFR5cGVdO2RlbGV0ZSBzdHJ1Y3RSZWdpc3RyYXRpb25zW3N0cnVjdFR5cGVdO3ZhciByYXdDb25zdHJ1Y3Rvcj1yZWcucmF3Q29uc3RydWN0b3I7dmFyIHJhd0Rlc3RydWN0b3I9cmVnLnJhd0Rlc3RydWN0b3I7dmFyIGZpZWxkUmVjb3Jkcz1yZWcuZmllbGRzO3ZhciBmaWVsZFR5cGVzPWZpZWxkUmVjb3Jkcy5tYXAoZnVuY3Rpb24oZmllbGQpe3JldHVybiBmaWVsZC5nZXR0ZXJSZXR1cm5UeXBlfSkuY29uY2F0KGZpZWxkUmVjb3Jkcy5tYXAoZnVuY3Rpb24oZmllbGQpe3JldHVybiBmaWVsZC5zZXR0ZXJBcmd1bWVudFR5cGV9KSk7d2hlbkRlcGVuZGVudFR5cGVzQXJlUmVzb2x2ZWQoW3N0cnVjdFR5cGVdLGZpZWxkVHlwZXMsZnVuY3Rpb24oZmllbGRUeXBlcyl7dmFyIGZpZWxkcz17fTtmaWVsZFJlY29yZHMuZm9yRWFjaChmdW5jdGlvbihmaWVsZCxpKXt2YXIgZmllbGROYW1lPWZpZWxkLmZpZWxkTmFtZTt2YXIgZ2V0dGVyUmV0dXJuVHlwZT1maWVsZFR5cGVzW2ldO3ZhciBnZXR0ZXI9ZmllbGQuZ2V0dGVyO3ZhciBnZXR0ZXJDb250ZXh0PWZpZWxkLmdldHRlckNvbnRleHQ7dmFyIHNldHRlckFyZ3VtZW50VHlwZT1maWVsZFR5cGVzW2krZmllbGRSZWNvcmRzLmxlbmd0aF07dmFyIHNldHRlcj1maWVsZC5zZXR0ZXI7dmFyIHNldHRlckNvbnRleHQ9ZmllbGQuc2V0dGVyQ29udGV4dDtmaWVsZHNbZmllbGROYW1lXT17cmVhZDpmdW5jdGlvbihwdHIpe3JldHVybiBnZXR0ZXJSZXR1cm5UeXBlWyJmcm9tV2lyZVR5cGUiXShnZXR0ZXIoZ2V0dGVyQ29udGV4dCxwdHIpKX0sd3JpdGU6ZnVuY3Rpb24ocHRyLG8pe3ZhciBkZXN0cnVjdG9ycz1bXTtzZXR0ZXIoc2V0dGVyQ29udGV4dCxwdHIsc2V0dGVyQXJndW1lbnRUeXBlWyJ0b1dpcmVUeXBlIl0oZGVzdHJ1Y3RvcnMsbykpO3J1bkRlc3RydWN0b3JzKGRlc3RydWN0b3JzKX19fSk7cmV0dXJuW3tuYW1lOnJlZy5uYW1lLCJmcm9tV2lyZVR5cGUiOmZ1bmN0aW9uKHB0cil7dmFyIHJ2PXt9O2Zvcih2YXIgaSBpbiBmaWVsZHMpe3J2W2ldPWZpZWxkc1tpXS5yZWFkKHB0cil9cmF3RGVzdHJ1Y3RvcihwdHIpO3JldHVybiBydn0sInRvV2lyZVR5cGUiOmZ1bmN0aW9uKGRlc3RydWN0b3JzLG8pe2Zvcih2YXIgZmllbGROYW1lIGluIGZpZWxkcyl7aWYoIShmaWVsZE5hbWUgaW4gbykpe3Rocm93IG5ldyBUeXBlRXJyb3IoJ01pc3NpbmcgZmllbGQ6ICAiJytmaWVsZE5hbWUrJyInKX19dmFyIHB0cj1yYXdDb25zdHJ1Y3RvcigpO2ZvcihmaWVsZE5hbWUgaW4gZmllbGRzKXtmaWVsZHNbZmllbGROYW1lXS53cml0ZShwdHIsb1tmaWVsZE5hbWVdKX1pZihkZXN0cnVjdG9ycyE9PW51bGwpe2Rlc3RydWN0b3JzLnB1c2gocmF3RGVzdHJ1Y3RvcixwdHIpfXJldHVybiBwdHJ9LCJhcmdQYWNrQWR2YW5jZSI6OCwicmVhZFZhbHVlRnJvbVBvaW50ZXIiOnNpbXBsZVJlYWRWYWx1ZUZyb21Qb2ludGVyLGRlc3RydWN0b3JGdW5jdGlvbjpyYXdEZXN0cnVjdG9yfV19KX1mdW5jdGlvbiBfX2VtYmluZF9yZWdpc3Rlcl9iaWdpbnQocHJpbWl0aXZlVHlwZSxuYW1lLHNpemUsbWluUmFuZ2UsbWF4UmFuZ2Upe31mdW5jdGlvbiBnZXRTaGlmdEZyb21TaXplKHNpemUpe3N3aXRjaChzaXplKXtjYXNlIDE6cmV0dXJuIDA7Y2FzZSAyOnJldHVybiAxO2Nhc2UgNDpyZXR1cm4gMjtjYXNlIDg6cmV0dXJuIDM7ZGVmYXVsdDp0aHJvdyBuZXcgVHlwZUVycm9yKCJVbmtub3duIHR5cGUgc2l6ZTogIitzaXplKX19ZnVuY3Rpb24gZW1iaW5kX2luaXRfY2hhckNvZGVzKCl7dmFyIGNvZGVzPW5ldyBBcnJheSgyNTYpO2Zvcih2YXIgaT0wO2k8MjU2OysraSl7Y29kZXNbaV09U3RyaW5nLmZyb21DaGFyQ29kZShpKX1lbWJpbmRfY2hhckNvZGVzPWNvZGVzfXZhciBlbWJpbmRfY2hhckNvZGVzPXVuZGVmaW5lZDtmdW5jdGlvbiByZWFkTGF0aW4xU3RyaW5nKHB0cil7dmFyIHJldD0iIjt2YXIgYz1wdHI7d2hpbGUoSEVBUFU4W2NdKXtyZXQrPWVtYmluZF9jaGFyQ29kZXNbSEVBUFU4W2MrK11dfXJldHVybiByZXR9dmFyIEJpbmRpbmdFcnJvcj11bmRlZmluZWQ7ZnVuY3Rpb24gdGhyb3dCaW5kaW5nRXJyb3IobWVzc2FnZSl7dGhyb3cgbmV3IEJpbmRpbmdFcnJvcihtZXNzYWdlKX1mdW5jdGlvbiByZWdpc3RlclR5cGUocmF3VHlwZSxyZWdpc3RlcmVkSW5zdGFuY2Usb3B0aW9ucz17fSl7aWYoISgiYXJnUGFja0FkdmFuY2UiaW4gcmVnaXN0ZXJlZEluc3RhbmNlKSl7dGhyb3cgbmV3IFR5cGVFcnJvcigicmVnaXN0ZXJUeXBlIHJlZ2lzdGVyZWRJbnN0YW5jZSByZXF1aXJlcyBhcmdQYWNrQWR2YW5jZSIpfXZhciBuYW1lPXJlZ2lzdGVyZWRJbnN0YW5jZS5uYW1lO2lmKCFyYXdUeXBlKXt0aHJvd0JpbmRpbmdFcnJvcigndHlwZSAiJytuYW1lKyciIG11c3QgaGF2ZSBhIHBvc2l0aXZlIGludGVnZXIgdHlwZWlkIHBvaW50ZXInKX1pZihyZWdpc3RlcmVkVHlwZXMuaGFzT3duUHJvcGVydHkocmF3VHlwZSkpe2lmKG9wdGlvbnMuaWdub3JlRHVwbGljYXRlUmVnaXN0cmF0aW9ucyl7cmV0dXJufWVsc2V7dGhyb3dCaW5kaW5nRXJyb3IoIkNhbm5vdCByZWdpc3RlciB0eXBlICciK25hbWUrIicgdHdpY2UiKX19cmVnaXN0ZXJlZFR5cGVzW3Jhd1R5cGVdPXJlZ2lzdGVyZWRJbnN0YW5jZTtkZWxldGUgdHlwZURlcGVuZGVuY2llc1tyYXdUeXBlXTtpZihhd2FpdGluZ0RlcGVuZGVuY2llcy5oYXNPd25Qcm9wZXJ0eShyYXdUeXBlKSl7dmFyIGNhbGxiYWNrcz1hd2FpdGluZ0RlcGVuZGVuY2llc1tyYXdUeXBlXTtkZWxldGUgYXdhaXRpbmdEZXBlbmRlbmNpZXNbcmF3VHlwZV07Y2FsbGJhY2tzLmZvckVhY2goZnVuY3Rpb24oY2Ipe2NiKCl9KX19ZnVuY3Rpb24gX19lbWJpbmRfcmVnaXN0ZXJfYm9vbChyYXdUeXBlLG5hbWUsc2l6ZSx0cnVlVmFsdWUsZmFsc2VWYWx1ZSl7dmFyIHNoaWZ0PWdldFNoaWZ0RnJvbVNpemUoc2l6ZSk7bmFtZT1yZWFkTGF0aW4xU3RyaW5nKG5hbWUpO3JlZ2lzdGVyVHlwZShyYXdUeXBlLHtuYW1lOm5hbWUsImZyb21XaXJlVHlwZSI6ZnVuY3Rpb24od3Qpe3JldHVybiEhd3R9LCJ0b1dpcmVUeXBlIjpmdW5jdGlvbihkZXN0cnVjdG9ycyxvKXtyZXR1cm4gbz90cnVlVmFsdWU6ZmFsc2VWYWx1ZX0sImFyZ1BhY2tBZHZhbmNlIjo4LCJyZWFkVmFsdWVGcm9tUG9pbnRlciI6ZnVuY3Rpb24ocG9pbnRlcil7dmFyIGhlYXA7aWYoc2l6ZT09PTEpe2hlYXA9SEVBUDh9ZWxzZSBpZihzaXplPT09Mil7aGVhcD1IRUFQMTZ9ZWxzZSBpZihzaXplPT09NCl7aGVhcD1IRUFQMzJ9ZWxzZXt0aHJvdyBuZXcgVHlwZUVycm9yKCJVbmtub3duIGJvb2xlYW4gdHlwZSBzaXplOiAiK25hbWUpfXJldHVybiB0aGlzWyJmcm9tV2lyZVR5cGUiXShoZWFwW3BvaW50ZXI+PnNoaWZ0XSl9LGRlc3RydWN0b3JGdW5jdGlvbjpudWxsfSl9ZnVuY3Rpb24gX19lbWJpbmRfcmVnaXN0ZXJfY29uc3RhbnQobmFtZSx0eXBlLHZhbHVlKXtuYW1lPXJlYWRMYXRpbjFTdHJpbmcobmFtZSk7d2hlbkRlcGVuZGVudFR5cGVzQXJlUmVzb2x2ZWQoW10sW3R5cGVdLGZ1bmN0aW9uKHR5cGUpe3R5cGU9dHlwZVswXTtNb2R1bGVbbmFtZV09dHlwZVsiZnJvbVdpcmVUeXBlIl0odmFsdWUpO3JldHVybltdfSl9dmFyIGVtdmFsX2ZyZWVfbGlzdD1bXTt2YXIgZW12YWxfaGFuZGxlX2FycmF5PVt7fSx7dmFsdWU6dW5kZWZpbmVkfSx7dmFsdWU6bnVsbH0se3ZhbHVlOnRydWV9LHt2YWx1ZTpmYWxzZX1dO2Z1bmN0aW9uIF9fZW12YWxfZGVjcmVmKGhhbmRsZSl7aWYoaGFuZGxlPjQmJjA9PT0tLWVtdmFsX2hhbmRsZV9hcnJheVtoYW5kbGVdLnJlZmNvdW50KXtlbXZhbF9oYW5kbGVfYXJyYXlbaGFuZGxlXT11bmRlZmluZWQ7ZW12YWxfZnJlZV9saXN0LnB1c2goaGFuZGxlKX19ZnVuY3Rpb24gY291bnRfZW12YWxfaGFuZGxlcygpe3ZhciBjb3VudD0wO2Zvcih2YXIgaT01O2k8ZW12YWxfaGFuZGxlX2FycmF5Lmxlbmd0aDsrK2kpe2lmKGVtdmFsX2hhbmRsZV9hcnJheVtpXSE9PXVuZGVmaW5lZCl7Kytjb3VudH19cmV0dXJuIGNvdW50fWZ1bmN0aW9uIGdldF9maXJzdF9lbXZhbCgpe2Zvcih2YXIgaT01O2k8ZW12YWxfaGFuZGxlX2FycmF5Lmxlbmd0aDsrK2kpe2lmKGVtdmFsX2hhbmRsZV9hcnJheVtpXSE9PXVuZGVmaW5lZCl7cmV0dXJuIGVtdmFsX2hhbmRsZV9hcnJheVtpXX19cmV0dXJuIG51bGx9ZnVuY3Rpb24gaW5pdF9lbXZhbCgpe01vZHVsZVsiY291bnRfZW12YWxfaGFuZGxlcyJdPWNvdW50X2VtdmFsX2hhbmRsZXM7TW9kdWxlWyJnZXRfZmlyc3RfZW12YWwiXT1nZXRfZmlyc3RfZW12YWx9dmFyIEVtdmFsPXt0b1ZhbHVlOmZ1bmN0aW9uKGhhbmRsZSl7aWYoIWhhbmRsZSl7dGhyb3dCaW5kaW5nRXJyb3IoIkNhbm5vdCB1c2UgZGVsZXRlZCB2YWwuIGhhbmRsZSA9ICIraGFuZGxlKX1yZXR1cm4gZW12YWxfaGFuZGxlX2FycmF5W2hhbmRsZV0udmFsdWV9LHRvSGFuZGxlOmZ1bmN0aW9uKHZhbHVlKXtzd2l0Y2godmFsdWUpe2Nhc2UgdW5kZWZpbmVkOntyZXR1cm4gMX1jYXNlIG51bGw6e3JldHVybiAyfWNhc2UgdHJ1ZTp7cmV0dXJuIDN9Y2FzZSBmYWxzZTp7cmV0dXJuIDR9ZGVmYXVsdDp7dmFyIGhhbmRsZT1lbXZhbF9mcmVlX2xpc3QubGVuZ3RoP2VtdmFsX2ZyZWVfbGlzdC5wb3AoKTplbXZhbF9oYW5kbGVfYXJyYXkubGVuZ3RoO2VtdmFsX2hhbmRsZV9hcnJheVtoYW5kbGVdPXtyZWZjb3VudDoxLHZhbHVlOnZhbHVlfTtyZXR1cm4gaGFuZGxlfX19fTtmdW5jdGlvbiBfX2VtYmluZF9yZWdpc3Rlcl9lbXZhbChyYXdUeXBlLG5hbWUpe25hbWU9cmVhZExhdGluMVN0cmluZyhuYW1lKTtyZWdpc3RlclR5cGUocmF3VHlwZSx7bmFtZTpuYW1lLCJmcm9tV2lyZVR5cGUiOmZ1bmN0aW9uKGhhbmRsZSl7dmFyIHJ2PUVtdmFsLnRvVmFsdWUoaGFuZGxlKTtfX2VtdmFsX2RlY3JlZihoYW5kbGUpO3JldHVybiBydn0sInRvV2lyZVR5cGUiOmZ1bmN0aW9uKGRlc3RydWN0b3JzLHZhbHVlKXtyZXR1cm4gRW12YWwudG9IYW5kbGUodmFsdWUpfSwiYXJnUGFja0FkdmFuY2UiOjgsInJlYWRWYWx1ZUZyb21Qb2ludGVyIjpzaW1wbGVSZWFkVmFsdWVGcm9tUG9pbnRlcixkZXN0cnVjdG9yRnVuY3Rpb246bnVsbH0pfWZ1bmN0aW9uIGVuc3VyZU92ZXJsb2FkVGFibGUocHJvdG8sbWV0aG9kTmFtZSxodW1hbk5hbWUpe2lmKHVuZGVmaW5lZD09PXByb3RvW21ldGhvZE5hbWVdLm92ZXJsb2FkVGFibGUpe3ZhciBwcmV2RnVuYz1wcm90b1ttZXRob2ROYW1lXTtwcm90b1ttZXRob2ROYW1lXT1mdW5jdGlvbigpe2lmKCFwcm90b1ttZXRob2ROYW1lXS5vdmVybG9hZFRhYmxlLmhhc093blByb3BlcnR5KGFyZ3VtZW50cy5sZW5ndGgpKXt0aHJvd0JpbmRpbmdFcnJvcigiRnVuY3Rpb24gJyIraHVtYW5OYW1lKyInIGNhbGxlZCB3aXRoIGFuIGludmFsaWQgbnVtYmVyIG9mIGFyZ3VtZW50cyAoIithcmd1bWVudHMubGVuZ3RoKyIpIC0gZXhwZWN0cyBvbmUgb2YgKCIrcHJvdG9bbWV0aG9kTmFtZV0ub3ZlcmxvYWRUYWJsZSsiKSEiKX1yZXR1cm4gcHJvdG9bbWV0aG9kTmFtZV0ub3ZlcmxvYWRUYWJsZVthcmd1bWVudHMubGVuZ3RoXS5hcHBseSh0aGlzLGFyZ3VtZW50cyl9O3Byb3RvW21ldGhvZE5hbWVdLm92ZXJsb2FkVGFibGU9W107cHJvdG9bbWV0aG9kTmFtZV0ub3ZlcmxvYWRUYWJsZVtwcmV2RnVuYy5hcmdDb3VudF09cHJldkZ1bmN9fWZ1bmN0aW9uIGV4cG9zZVB1YmxpY1N5bWJvbChuYW1lLHZhbHVlLG51bUFyZ3VtZW50cyl7aWYoTW9kdWxlLmhhc093blByb3BlcnR5KG5hbWUpKXtpZih1bmRlZmluZWQ9PT1udW1Bcmd1bWVudHN8fHVuZGVmaW5lZCE9PU1vZHVsZVtuYW1lXS5vdmVybG9hZFRhYmxlJiZ1bmRlZmluZWQhPT1Nb2R1bGVbbmFtZV0ub3ZlcmxvYWRUYWJsZVtudW1Bcmd1bWVudHNdKXt0aHJvd0JpbmRpbmdFcnJvcigiQ2Fubm90IHJlZ2lzdGVyIHB1YmxpYyBuYW1lICciK25hbWUrIicgdHdpY2UiKX1lbnN1cmVPdmVybG9hZFRhYmxlKE1vZHVsZSxuYW1lLG5hbWUpO2lmKE1vZHVsZS5oYXNPd25Qcm9wZXJ0eShudW1Bcmd1bWVudHMpKXt0aHJvd0JpbmRpbmdFcnJvcigiQ2Fubm90IHJlZ2lzdGVyIG11bHRpcGxlIG92ZXJsb2FkcyBvZiBhIGZ1bmN0aW9uIHdpdGggdGhlIHNhbWUgbnVtYmVyIG9mIGFyZ3VtZW50cyAoIitudW1Bcmd1bWVudHMrIikhIil9TW9kdWxlW25hbWVdLm92ZXJsb2FkVGFibGVbbnVtQXJndW1lbnRzXT12YWx1ZX1lbHNle01vZHVsZVtuYW1lXT12YWx1ZTtpZih1bmRlZmluZWQhPT1udW1Bcmd1bWVudHMpe01vZHVsZVtuYW1lXS5udW1Bcmd1bWVudHM9bnVtQXJndW1lbnRzfX19ZnVuY3Rpb24gZW51bVJlYWRWYWx1ZUZyb21Qb2ludGVyKG5hbWUsc2hpZnQsc2lnbmVkKXtzd2l0Y2goc2hpZnQpe2Nhc2UgMDpyZXR1cm4gZnVuY3Rpb24ocG9pbnRlcil7dmFyIGhlYXA9c2lnbmVkP0hFQVA4OkhFQVBVODtyZXR1cm4gdGhpc1siZnJvbVdpcmVUeXBlIl0oaGVhcFtwb2ludGVyXSl9O2Nhc2UgMTpyZXR1cm4gZnVuY3Rpb24ocG9pbnRlcil7dmFyIGhlYXA9c2lnbmVkP0hFQVAxNjpIRUFQVTE2O3JldHVybiB0aGlzWyJmcm9tV2lyZVR5cGUiXShoZWFwW3BvaW50ZXI+PjFdKX07Y2FzZSAyOnJldHVybiBmdW5jdGlvbihwb2ludGVyKXt2YXIgaGVhcD1zaWduZWQ/SEVBUDMyOkhFQVBVMzI7cmV0dXJuIHRoaXNbImZyb21XaXJlVHlwZSJdKGhlYXBbcG9pbnRlcj4+Ml0pfTtkZWZhdWx0OnRocm93IG5ldyBUeXBlRXJyb3IoIlVua25vd24gaW50ZWdlciB0eXBlOiAiK25hbWUpfX1mdW5jdGlvbiBfX2VtYmluZF9yZWdpc3Rlcl9lbnVtKHJhd1R5cGUsbmFtZSxzaXplLGlzU2lnbmVkKXt2YXIgc2hpZnQ9Z2V0U2hpZnRGcm9tU2l6ZShzaXplKTtuYW1lPXJlYWRMYXRpbjFTdHJpbmcobmFtZSk7ZnVuY3Rpb24gY3Rvcigpe31jdG9yLnZhbHVlcz17fTtyZWdpc3RlclR5cGUocmF3VHlwZSx7bmFtZTpuYW1lLGNvbnN0cnVjdG9yOmN0b3IsImZyb21XaXJlVHlwZSI6ZnVuY3Rpb24oYyl7cmV0dXJuIHRoaXMuY29uc3RydWN0b3IudmFsdWVzW2NdfSwidG9XaXJlVHlwZSI6ZnVuY3Rpb24oZGVzdHJ1Y3RvcnMsYyl7cmV0dXJuIGMudmFsdWV9LCJhcmdQYWNrQWR2YW5jZSI6OCwicmVhZFZhbHVlRnJvbVBvaW50ZXIiOmVudW1SZWFkVmFsdWVGcm9tUG9pbnRlcihuYW1lLHNoaWZ0LGlzU2lnbmVkKSxkZXN0cnVjdG9yRnVuY3Rpb246bnVsbH0pO2V4cG9zZVB1YmxpY1N5bWJvbChuYW1lLGN0b3IpfWZ1bmN0aW9uIGdldFR5cGVOYW1lKHR5cGUpe3ZhciBwdHI9X19fZ2V0VHlwZU5hbWUodHlwZSk7dmFyIHJ2PXJlYWRMYXRpbjFTdHJpbmcocHRyKTtfZnJlZShwdHIpO3JldHVybiBydn1mdW5jdGlvbiByZXF1aXJlUmVnaXN0ZXJlZFR5cGUocmF3VHlwZSxodW1hbk5hbWUpe3ZhciBpbXBsPXJlZ2lzdGVyZWRUeXBlc1tyYXdUeXBlXTtpZih1bmRlZmluZWQ9PT1pbXBsKXt0aHJvd0JpbmRpbmdFcnJvcihodW1hbk5hbWUrIiBoYXMgdW5rbm93biB0eXBlICIrZ2V0VHlwZU5hbWUocmF3VHlwZSkpfXJldHVybiBpbXBsfWZ1bmN0aW9uIF9fZW1iaW5kX3JlZ2lzdGVyX2VudW1fdmFsdWUocmF3RW51bVR5cGUsbmFtZSxlbnVtVmFsdWUpe3ZhciBlbnVtVHlwZT1yZXF1aXJlUmVnaXN0ZXJlZFR5cGUocmF3RW51bVR5cGUsImVudW0iKTtuYW1lPXJlYWRMYXRpbjFTdHJpbmcobmFtZSk7dmFyIEVudW09ZW51bVR5cGUuY29uc3RydWN0b3I7dmFyIFZhbHVlPU9iamVjdC5jcmVhdGUoZW51bVR5cGUuY29uc3RydWN0b3IucHJvdG90eXBlLHt2YWx1ZTp7dmFsdWU6ZW51bVZhbHVlfSxjb25zdHJ1Y3Rvcjp7dmFsdWU6Y3JlYXRlTmFtZWRGdW5jdGlvbihlbnVtVHlwZS5uYW1lKyJfIituYW1lLGZ1bmN0aW9uKCl7fSl9fSk7RW51bS52YWx1ZXNbZW51bVZhbHVlXT1WYWx1ZTtFbnVtW25hbWVdPVZhbHVlfWZ1bmN0aW9uIGZsb2F0UmVhZFZhbHVlRnJvbVBvaW50ZXIobmFtZSxzaGlmdCl7c3dpdGNoKHNoaWZ0KXtjYXNlIDI6cmV0dXJuIGZ1bmN0aW9uKHBvaW50ZXIpe3JldHVybiB0aGlzWyJmcm9tV2lyZVR5cGUiXShIRUFQRjMyW3BvaW50ZXI+PjJdKX07Y2FzZSAzOnJldHVybiBmdW5jdGlvbihwb2ludGVyKXtyZXR1cm4gdGhpc1siZnJvbVdpcmVUeXBlIl0oSEVBUEY2NFtwb2ludGVyPj4zXSl9O2RlZmF1bHQ6dGhyb3cgbmV3IFR5cGVFcnJvcigiVW5rbm93biBmbG9hdCB0eXBlOiAiK25hbWUpfX1mdW5jdGlvbiBfX2VtYmluZF9yZWdpc3Rlcl9mbG9hdChyYXdUeXBlLG5hbWUsc2l6ZSl7dmFyIHNoaWZ0PWdldFNoaWZ0RnJvbVNpemUoc2l6ZSk7bmFtZT1yZWFkTGF0aW4xU3RyaW5nKG5hbWUpO3JlZ2lzdGVyVHlwZShyYXdUeXBlLHtuYW1lOm5hbWUsImZyb21XaXJlVHlwZSI6ZnVuY3Rpb24odmFsdWUpe3JldHVybiB2YWx1ZX0sInRvV2lyZVR5cGUiOmZ1bmN0aW9uKGRlc3RydWN0b3JzLHZhbHVlKXtyZXR1cm4gdmFsdWV9LCJhcmdQYWNrQWR2YW5jZSI6OCwicmVhZFZhbHVlRnJvbVBvaW50ZXIiOmZsb2F0UmVhZFZhbHVlRnJvbVBvaW50ZXIobmFtZSxzaGlmdCksZGVzdHJ1Y3RvckZ1bmN0aW9uOm51bGx9KX1mdW5jdGlvbiBuZXdfKGNvbnN0cnVjdG9yLGFyZ3VtZW50TGlzdCl7aWYoIShjb25zdHJ1Y3RvciBpbnN0YW5jZW9mIEZ1bmN0aW9uKSl7dGhyb3cgbmV3IFR5cGVFcnJvcigibmV3XyBjYWxsZWQgd2l0aCBjb25zdHJ1Y3RvciB0eXBlICIrdHlwZW9mIGNvbnN0cnVjdG9yKyIgd2hpY2ggaXMgbm90IGEgZnVuY3Rpb24iKX12YXIgZHVtbXk9Y3JlYXRlTmFtZWRGdW5jdGlvbihjb25zdHJ1Y3Rvci5uYW1lfHwidW5rbm93bkZ1bmN0aW9uTmFtZSIsZnVuY3Rpb24oKXt9KTtkdW1teS5wcm90b3R5cGU9Y29uc3RydWN0b3IucHJvdG90eXBlO3ZhciBvYmo9bmV3IGR1bW15O3ZhciByPWNvbnN0cnVjdG9yLmFwcGx5KG9iaixhcmd1bWVudExpc3QpO3JldHVybiByIGluc3RhbmNlb2YgT2JqZWN0P3I6b2JqfWZ1bmN0aW9uIGNyYWZ0SW52b2tlckZ1bmN0aW9uKGh1bWFuTmFtZSxhcmdUeXBlcyxjbGFzc1R5cGUsY3BwSW52b2tlckZ1bmMsY3BwVGFyZ2V0RnVuYyl7dmFyIGFyZ0NvdW50PWFyZ1R5cGVzLmxlbmd0aDtpZihhcmdDb3VudDwyKXt0aHJvd0JpbmRpbmdFcnJvcigiYXJnVHlwZXMgYXJyYXkgc2l6ZSBtaXNtYXRjaCEgTXVzdCBhdCBsZWFzdCBnZXQgcmV0dXJuIHZhbHVlIGFuZCAndGhpcycgdHlwZXMhIil9dmFyIGlzQ2xhc3NNZXRob2RGdW5jPWFyZ1R5cGVzWzFdIT09bnVsbCYmY2xhc3NUeXBlIT09bnVsbDt2YXIgbmVlZHNEZXN0cnVjdG9yU3RhY2s9ZmFsc2U7Zm9yKHZhciBpPTE7aTxhcmdUeXBlcy5sZW5ndGg7KytpKXtpZihhcmdUeXBlc1tpXSE9PW51bGwmJmFyZ1R5cGVzW2ldLmRlc3RydWN0b3JGdW5jdGlvbj09PXVuZGVmaW5lZCl7bmVlZHNEZXN0cnVjdG9yU3RhY2s9dHJ1ZTticmVha319dmFyIHJldHVybnM9YXJnVHlwZXNbMF0ubmFtZSE9PSJ2b2lkIjt2YXIgYXJnc0xpc3Q9IiI7dmFyIGFyZ3NMaXN0V2lyZWQ9IiI7Zm9yKHZhciBpPTA7aTxhcmdDb3VudC0yOysraSl7YXJnc0xpc3QrPShpIT09MD8iLCAiOiIiKSsiYXJnIitpO2FyZ3NMaXN0V2lyZWQrPShpIT09MD8iLCAiOiIiKSsiYXJnIitpKyJXaXJlZCJ9dmFyIGludm9rZXJGbkJvZHk9InJldHVybiBmdW5jdGlvbiAiK21ha2VMZWdhbEZ1bmN0aW9uTmFtZShodW1hbk5hbWUpKyIoIithcmdzTGlzdCsiKSB7XG4iKyJpZiAoYXJndW1lbnRzLmxlbmd0aCAhPT0gIisoYXJnQ291bnQtMikrIikge1xuIisidGhyb3dCaW5kaW5nRXJyb3IoJ2Z1bmN0aW9uICIraHVtYW5OYW1lKyIgY2FsbGVkIHdpdGggJyArIGFyZ3VtZW50cy5sZW5ndGggKyAnIGFyZ3VtZW50cywgZXhwZWN0ZWQgIisoYXJnQ291bnQtMikrIiBhcmdzIScpO1xuIisifVxuIjtpZihuZWVkc0Rlc3RydWN0b3JTdGFjayl7aW52b2tlckZuQm9keSs9InZhciBkZXN0cnVjdG9ycyA9IFtdO1xuIn12YXIgZHRvclN0YWNrPW5lZWRzRGVzdHJ1Y3RvclN0YWNrPyJkZXN0cnVjdG9ycyI6Im51bGwiO3ZhciBhcmdzMT1bInRocm93QmluZGluZ0Vycm9yIiwiaW52b2tlciIsImZuIiwicnVuRGVzdHJ1Y3RvcnMiLCJyZXRUeXBlIiwiY2xhc3NQYXJhbSJdO3ZhciBhcmdzMj1bdGhyb3dCaW5kaW5nRXJyb3IsY3BwSW52b2tlckZ1bmMsY3BwVGFyZ2V0RnVuYyxydW5EZXN0cnVjdG9ycyxhcmdUeXBlc1swXSxhcmdUeXBlc1sxXV07aWYoaXNDbGFzc01ldGhvZEZ1bmMpe2ludm9rZXJGbkJvZHkrPSJ2YXIgdGhpc1dpcmVkID0gY2xhc3NQYXJhbS50b1dpcmVUeXBlKCIrZHRvclN0YWNrKyIsIHRoaXMpO1xuIn1mb3IodmFyIGk9MDtpPGFyZ0NvdW50LTI7KytpKXtpbnZva2VyRm5Cb2R5Kz0idmFyIGFyZyIraSsiV2lyZWQgPSBhcmdUeXBlIitpKyIudG9XaXJlVHlwZSgiK2R0b3JTdGFjaysiLCBhcmciK2krIik7IC8vICIrYXJnVHlwZXNbaSsyXS5uYW1lKyJcbiI7YXJnczEucHVzaCgiYXJnVHlwZSIraSk7YXJnczIucHVzaChhcmdUeXBlc1tpKzJdKX1pZihpc0NsYXNzTWV0aG9kRnVuYyl7YXJnc0xpc3RXaXJlZD0idGhpc1dpcmVkIisoYXJnc0xpc3RXaXJlZC5sZW5ndGg+MD8iLCAiOiIiKSthcmdzTGlzdFdpcmVkfWludm9rZXJGbkJvZHkrPShyZXR1cm5zPyJ2YXIgcnYgPSAiOiIiKSsiaW52b2tlcihmbiIrKGFyZ3NMaXN0V2lyZWQubGVuZ3RoPjA/IiwgIjoiIikrYXJnc0xpc3RXaXJlZCsiKTtcbiI7aWYobmVlZHNEZXN0cnVjdG9yU3RhY2spe2ludm9rZXJGbkJvZHkrPSJydW5EZXN0cnVjdG9ycyhkZXN0cnVjdG9ycyk7XG4ifWVsc2V7Zm9yKHZhciBpPWlzQ2xhc3NNZXRob2RGdW5jPzE6MjtpPGFyZ1R5cGVzLmxlbmd0aDsrK2kpe3ZhciBwYXJhbU5hbWU9aT09PTE/InRoaXNXaXJlZCI6ImFyZyIrKGktMikrIldpcmVkIjtpZihhcmdUeXBlc1tpXS5kZXN0cnVjdG9yRnVuY3Rpb24hPT1udWxsKXtpbnZva2VyRm5Cb2R5Kz1wYXJhbU5hbWUrIl9kdG9yKCIrcGFyYW1OYW1lKyIpOyAvLyAiK2FyZ1R5cGVzW2ldLm5hbWUrIlxuIjthcmdzMS5wdXNoKHBhcmFtTmFtZSsiX2R0b3IiKTthcmdzMi5wdXNoKGFyZ1R5cGVzW2ldLmRlc3RydWN0b3JGdW5jdGlvbil9fX1pZihyZXR1cm5zKXtpbnZva2VyRm5Cb2R5Kz0idmFyIHJldCA9IHJldFR5cGUuZnJvbVdpcmVUeXBlKHJ2KTtcbiIrInJldHVybiByZXQ7XG4ifWVsc2V7fWludm9rZXJGbkJvZHkrPSJ9XG4iO2FyZ3MxLnB1c2goaW52b2tlckZuQm9keSk7dmFyIGludm9rZXJGdW5jdGlvbj1uZXdfKEZ1bmN0aW9uLGFyZ3MxKS5hcHBseShudWxsLGFyZ3MyKTtyZXR1cm4gaW52b2tlckZ1bmN0aW9ufWZ1bmN0aW9uIGhlYXAzMlZlY3RvclRvQXJyYXkoY291bnQsZmlyc3RFbGVtZW50KXt2YXIgYXJyYXk9W107Zm9yKHZhciBpPTA7aTxjb3VudDtpKyspe2FycmF5LnB1c2goSEVBUDMyWyhmaXJzdEVsZW1lbnQ+PjIpK2ldKX1yZXR1cm4gYXJyYXl9ZnVuY3Rpb24gcmVwbGFjZVB1YmxpY1N5bWJvbChuYW1lLHZhbHVlLG51bUFyZ3VtZW50cyl7aWYoIU1vZHVsZS5oYXNPd25Qcm9wZXJ0eShuYW1lKSl7dGhyb3dJbnRlcm5hbEVycm9yKCJSZXBsYWNpbmcgbm9uZXhpc3RhbnQgcHVibGljIHN5bWJvbCIpfWlmKHVuZGVmaW5lZCE9PU1vZHVsZVtuYW1lXS5vdmVybG9hZFRhYmxlJiZ1bmRlZmluZWQhPT1udW1Bcmd1bWVudHMpe01vZHVsZVtuYW1lXS5vdmVybG9hZFRhYmxlW251bUFyZ3VtZW50c109dmFsdWV9ZWxzZXtNb2R1bGVbbmFtZV09dmFsdWU7TW9kdWxlW25hbWVdLmFyZ0NvdW50PW51bUFyZ3VtZW50c319ZnVuY3Rpb24gZHluQ2FsbExlZ2FjeShzaWcscHRyLGFyZ3Mpe3ZhciBmPU1vZHVsZVsiZHluQ2FsbF8iK3NpZ107cmV0dXJuIGFyZ3MmJmFyZ3MubGVuZ3RoP2YuYXBwbHkobnVsbCxbcHRyXS5jb25jYXQoYXJncykpOmYuY2FsbChudWxsLHB0cil9ZnVuY3Rpb24gZHluQ2FsbChzaWcscHRyLGFyZ3Mpe2lmKHNpZy5pbmNsdWRlcygiaiIpKXtyZXR1cm4gZHluQ2FsbExlZ2FjeShzaWcscHRyLGFyZ3MpfXJldHVybiBnZXRXYXNtVGFibGVFbnRyeShwdHIpLmFwcGx5KG51bGwsYXJncyl9ZnVuY3Rpb24gZ2V0RHluQ2FsbGVyKHNpZyxwdHIpe3ZhciBhcmdDYWNoZT1bXTtyZXR1cm4gZnVuY3Rpb24oKXthcmdDYWNoZS5sZW5ndGg9YXJndW1lbnRzLmxlbmd0aDtmb3IodmFyIGk9MDtpPGFyZ3VtZW50cy5sZW5ndGg7aSsrKXthcmdDYWNoZVtpXT1hcmd1bWVudHNbaV19cmV0dXJuIGR5bkNhbGwoc2lnLHB0cixhcmdDYWNoZSl9fWZ1bmN0aW9uIGVtYmluZF9fcmVxdWlyZUZ1bmN0aW9uKHNpZ25hdHVyZSxyYXdGdW5jdGlvbil7c2lnbmF0dXJlPXJlYWRMYXRpbjFTdHJpbmcoc2lnbmF0dXJlKTtmdW5jdGlvbiBtYWtlRHluQ2FsbGVyKCl7aWYoc2lnbmF0dXJlLmluY2x1ZGVzKCJqIikpe3JldHVybiBnZXREeW5DYWxsZXIoc2lnbmF0dXJlLHJhd0Z1bmN0aW9uKX1yZXR1cm4gZ2V0V2FzbVRhYmxlRW50cnkocmF3RnVuY3Rpb24pfXZhciBmcD1tYWtlRHluQ2FsbGVyKCk7aWYodHlwZW9mIGZwIT09ImZ1bmN0aW9uIil7dGhyb3dCaW5kaW5nRXJyb3IoInVua25vd24gZnVuY3Rpb24gcG9pbnRlciB3aXRoIHNpZ25hdHVyZSAiK3NpZ25hdHVyZSsiOiAiK3Jhd0Z1bmN0aW9uKX1yZXR1cm4gZnB9dmFyIFVuYm91bmRUeXBlRXJyb3I9dW5kZWZpbmVkO2Z1bmN0aW9uIHRocm93VW5ib3VuZFR5cGVFcnJvcihtZXNzYWdlLHR5cGVzKXt2YXIgdW5ib3VuZFR5cGVzPVtdO3ZhciBzZWVuPXt9O2Z1bmN0aW9uIHZpc2l0KHR5cGUpe2lmKHNlZW5bdHlwZV0pe3JldHVybn1pZihyZWdpc3RlcmVkVHlwZXNbdHlwZV0pe3JldHVybn1pZih0eXBlRGVwZW5kZW5jaWVzW3R5cGVdKXt0eXBlRGVwZW5kZW5jaWVzW3R5cGVdLmZvckVhY2godmlzaXQpO3JldHVybn11bmJvdW5kVHlwZXMucHVzaCh0eXBlKTtzZWVuW3R5cGVdPXRydWV9dHlwZXMuZm9yRWFjaCh2aXNpdCk7dGhyb3cgbmV3IFVuYm91bmRUeXBlRXJyb3IobWVzc2FnZSsiOiAiK3VuYm91bmRUeXBlcy5tYXAoZ2V0VHlwZU5hbWUpLmpvaW4oWyIsICJdKSl9ZnVuY3Rpb24gX19lbWJpbmRfcmVnaXN0ZXJfZnVuY3Rpb24obmFtZSxhcmdDb3VudCxyYXdBcmdUeXBlc0FkZHIsc2lnbmF0dXJlLHJhd0ludm9rZXIsZm4pe3ZhciBhcmdUeXBlcz1oZWFwMzJWZWN0b3JUb0FycmF5KGFyZ0NvdW50LHJhd0FyZ1R5cGVzQWRkcik7bmFtZT1yZWFkTGF0aW4xU3RyaW5nKG5hbWUpO3Jhd0ludm9rZXI9ZW1iaW5kX19yZXF1aXJlRnVuY3Rpb24oc2lnbmF0dXJlLHJhd0ludm9rZXIpO2V4cG9zZVB1YmxpY1N5bWJvbChuYW1lLGZ1bmN0aW9uKCl7dGhyb3dVbmJvdW5kVHlwZUVycm9yKCJDYW5ub3QgY2FsbCAiK25hbWUrIiBkdWUgdG8gdW5ib3VuZCB0eXBlcyIsYXJnVHlwZXMpfSxhcmdDb3VudC0xKTt3aGVuRGVwZW5kZW50VHlwZXNBcmVSZXNvbHZlZChbXSxhcmdUeXBlcyxmdW5jdGlvbihhcmdUeXBlcyl7dmFyIGludm9rZXJBcmdzQXJyYXk9W2FyZ1R5cGVzWzBdLG51bGxdLmNvbmNhdChhcmdUeXBlcy5zbGljZSgxKSk7cmVwbGFjZVB1YmxpY1N5bWJvbChuYW1lLGNyYWZ0SW52b2tlckZ1bmN0aW9uKG5hbWUsaW52b2tlckFyZ3NBcnJheSxudWxsLHJhd0ludm9rZXIsZm4pLGFyZ0NvdW50LTEpO3JldHVybltdfSl9ZnVuY3Rpb24gaW50ZWdlclJlYWRWYWx1ZUZyb21Qb2ludGVyKG5hbWUsc2hpZnQsc2lnbmVkKXtzd2l0Y2goc2hpZnQpe2Nhc2UgMDpyZXR1cm4gc2lnbmVkP2Z1bmN0aW9uIHJlYWRTOEZyb21Qb2ludGVyKHBvaW50ZXIpe3JldHVybiBIRUFQOFtwb2ludGVyXX06ZnVuY3Rpb24gcmVhZFU4RnJvbVBvaW50ZXIocG9pbnRlcil7cmV0dXJuIEhFQVBVOFtwb2ludGVyXX07Y2FzZSAxOnJldHVybiBzaWduZWQ/ZnVuY3Rpb24gcmVhZFMxNkZyb21Qb2ludGVyKHBvaW50ZXIpe3JldHVybiBIRUFQMTZbcG9pbnRlcj4+MV19OmZ1bmN0aW9uIHJlYWRVMTZGcm9tUG9pbnRlcihwb2ludGVyKXtyZXR1cm4gSEVBUFUxNltwb2ludGVyPj4xXX07Y2FzZSAyOnJldHVybiBzaWduZWQ/ZnVuY3Rpb24gcmVhZFMzMkZyb21Qb2ludGVyKHBvaW50ZXIpe3JldHVybiBIRUFQMzJbcG9pbnRlcj4+Ml19OmZ1bmN0aW9uIHJlYWRVMzJGcm9tUG9pbnRlcihwb2ludGVyKXtyZXR1cm4gSEVBUFUzMltwb2ludGVyPj4yXX07ZGVmYXVsdDp0aHJvdyBuZXcgVHlwZUVycm9yKCJVbmtub3duIGludGVnZXIgdHlwZTogIituYW1lKX19ZnVuY3Rpb24gX19lbWJpbmRfcmVnaXN0ZXJfaW50ZWdlcihwcmltaXRpdmVUeXBlLG5hbWUsc2l6ZSxtaW5SYW5nZSxtYXhSYW5nZSl7bmFtZT1yZWFkTGF0aW4xU3RyaW5nKG5hbWUpO2lmKG1heFJhbmdlPT09LTEpe21heFJhbmdlPTQyOTQ5NjcyOTV9dmFyIHNoaWZ0PWdldFNoaWZ0RnJvbVNpemUoc2l6ZSk7dmFyIGZyb21XaXJlVHlwZT12YWx1ZT0+dmFsdWU7aWYobWluUmFuZ2U9PT0wKXt2YXIgYml0c2hpZnQ9MzItOCpzaXplO2Zyb21XaXJlVHlwZT0odmFsdWU9PnZhbHVlPDxiaXRzaGlmdD4+PmJpdHNoaWZ0KX12YXIgaXNVbnNpZ25lZFR5cGU9bmFtZS5pbmNsdWRlcygidW5zaWduZWQiKTt2YXIgY2hlY2tBc3NlcnRpb25zPSh2YWx1ZSx0b1R5cGVOYW1lKT0+e307dmFyIHRvV2lyZVR5cGU7aWYoaXNVbnNpZ25lZFR5cGUpe3RvV2lyZVR5cGU9ZnVuY3Rpb24oZGVzdHJ1Y3RvcnMsdmFsdWUpe2NoZWNrQXNzZXJ0aW9ucyh2YWx1ZSx0aGlzLm5hbWUpO3JldHVybiB2YWx1ZT4+PjB9fWVsc2V7dG9XaXJlVHlwZT1mdW5jdGlvbihkZXN0cnVjdG9ycyx2YWx1ZSl7Y2hlY2tBc3NlcnRpb25zKHZhbHVlLHRoaXMubmFtZSk7cmV0dXJuIHZhbHVlfX1yZWdpc3RlclR5cGUocHJpbWl0aXZlVHlwZSx7bmFtZTpuYW1lLCJmcm9tV2lyZVR5cGUiOmZyb21XaXJlVHlwZSwidG9XaXJlVHlwZSI6dG9XaXJlVHlwZSwiYXJnUGFja0FkdmFuY2UiOjgsInJlYWRWYWx1ZUZyb21Qb2ludGVyIjppbnRlZ2VyUmVhZFZhbHVlRnJvbVBvaW50ZXIobmFtZSxzaGlmdCxtaW5SYW5nZSE9PTApLGRlc3RydWN0b3JGdW5jdGlvbjpudWxsfSl9ZnVuY3Rpb24gX19lbWJpbmRfcmVnaXN0ZXJfbWVtb3J5X3ZpZXcocmF3VHlwZSxkYXRhVHlwZUluZGV4LG5hbWUpe3ZhciB0eXBlTWFwcGluZz1bSW50OEFycmF5LFVpbnQ4QXJyYXksSW50MTZBcnJheSxVaW50MTZBcnJheSxJbnQzMkFycmF5LFVpbnQzMkFycmF5LEZsb2F0MzJBcnJheSxGbG9hdDY0QXJyYXldO3ZhciBUQT10eXBlTWFwcGluZ1tkYXRhVHlwZUluZGV4XTtmdW5jdGlvbiBkZWNvZGVNZW1vcnlWaWV3KGhhbmRsZSl7aGFuZGxlPWhhbmRsZT4+Mjt2YXIgaGVhcD1IRUFQVTMyO3ZhciBzaXplPWhlYXBbaGFuZGxlXTt2YXIgZGF0YT1oZWFwW2hhbmRsZSsxXTtyZXR1cm4gbmV3IFRBKGJ1ZmZlcixkYXRhLHNpemUpfW5hbWU9cmVhZExhdGluMVN0cmluZyhuYW1lKTtyZWdpc3RlclR5cGUocmF3VHlwZSx7bmFtZTpuYW1lLCJmcm9tV2lyZVR5cGUiOmRlY29kZU1lbW9yeVZpZXcsImFyZ1BhY2tBZHZhbmNlIjo4LCJyZWFkVmFsdWVGcm9tUG9pbnRlciI6ZGVjb2RlTWVtb3J5Vmlld30se2lnbm9yZUR1cGxpY2F0ZVJlZ2lzdHJhdGlvbnM6dHJ1ZX0pfWZ1bmN0aW9uIF9fZW1iaW5kX3JlZ2lzdGVyX3N0ZF9zdHJpbmcocmF3VHlwZSxuYW1lKXtuYW1lPXJlYWRMYXRpbjFTdHJpbmcobmFtZSk7dmFyIHN0ZFN0cmluZ0lzVVRGOD1uYW1lPT09InN0ZDo6c3RyaW5nIjtyZWdpc3RlclR5cGUocmF3VHlwZSx7bmFtZTpuYW1lLCJmcm9tV2lyZVR5cGUiOmZ1bmN0aW9uKHZhbHVlKXt2YXIgbGVuZ3RoPUhFQVBVMzJbdmFsdWU+PjJdO3ZhciBzdHI7aWYoc3RkU3RyaW5nSXNVVEY4KXt2YXIgZGVjb2RlU3RhcnRQdHI9dmFsdWUrNDtmb3IodmFyIGk9MDtpPD1sZW5ndGg7KytpKXt2YXIgY3VycmVudEJ5dGVQdHI9dmFsdWUrNCtpO2lmKGk9PWxlbmd0aHx8SEVBUFU4W2N1cnJlbnRCeXRlUHRyXT09MCl7dmFyIG1heFJlYWQ9Y3VycmVudEJ5dGVQdHItZGVjb2RlU3RhcnRQdHI7dmFyIHN0cmluZ1NlZ21lbnQ9VVRGOFRvU3RyaW5nKGRlY29kZVN0YXJ0UHRyLG1heFJlYWQpO2lmKHN0cj09PXVuZGVmaW5lZCl7c3RyPXN0cmluZ1NlZ21lbnR9ZWxzZXtzdHIrPVN0cmluZy5mcm9tQ2hhckNvZGUoMCk7c3RyKz1zdHJpbmdTZWdtZW50fWRlY29kZVN0YXJ0UHRyPWN1cnJlbnRCeXRlUHRyKzF9fX1lbHNle3ZhciBhPW5ldyBBcnJheShsZW5ndGgpO2Zvcih2YXIgaT0wO2k8bGVuZ3RoOysraSl7YVtpXT1TdHJpbmcuZnJvbUNoYXJDb2RlKEhFQVBVOFt2YWx1ZSs0K2ldKX1zdHI9YS5qb2luKCIiKX1fZnJlZSh2YWx1ZSk7cmV0dXJuIHN0cn0sInRvV2lyZVR5cGUiOmZ1bmN0aW9uKGRlc3RydWN0b3JzLHZhbHVlKXtpZih2YWx1ZSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKXt2YWx1ZT1uZXcgVWludDhBcnJheSh2YWx1ZSl9dmFyIGdldExlbmd0aDt2YXIgdmFsdWVJc09mVHlwZVN0cmluZz10eXBlb2YgdmFsdWU9PT0ic3RyaW5nIjtpZighKHZhbHVlSXNPZlR5cGVTdHJpbmd8fHZhbHVlIGluc3RhbmNlb2YgVWludDhBcnJheXx8dmFsdWUgaW5zdGFuY2VvZiBVaW50OENsYW1wZWRBcnJheXx8dmFsdWUgaW5zdGFuY2VvZiBJbnQ4QXJyYXkpKXt0aHJvd0JpbmRpbmdFcnJvcigiQ2Fubm90IHBhc3Mgbm9uLXN0cmluZyB0byBzdGQ6OnN0cmluZyIpfWlmKHN0ZFN0cmluZ0lzVVRGOCYmdmFsdWVJc09mVHlwZVN0cmluZyl7Z2V0TGVuZ3RoPSgoKT0+bGVuZ3RoQnl0ZXNVVEY4KHZhbHVlKSl9ZWxzZXtnZXRMZW5ndGg9KCgpPT52YWx1ZS5sZW5ndGgpfXZhciBsZW5ndGg9Z2V0TGVuZ3RoKCk7dmFyIHB0cj1fbWFsbG9jKDQrbGVuZ3RoKzEpO0hFQVBVMzJbcHRyPj4yXT1sZW5ndGg7aWYoc3RkU3RyaW5nSXNVVEY4JiZ2YWx1ZUlzT2ZUeXBlU3RyaW5nKXtzdHJpbmdUb1VURjgodmFsdWUscHRyKzQsbGVuZ3RoKzEpfWVsc2V7aWYodmFsdWVJc09mVHlwZVN0cmluZyl7Zm9yKHZhciBpPTA7aTxsZW5ndGg7KytpKXt2YXIgY2hhckNvZGU9dmFsdWUuY2hhckNvZGVBdChpKTtpZihjaGFyQ29kZT4yNTUpe19mcmVlKHB0cik7dGhyb3dCaW5kaW5nRXJyb3IoIlN0cmluZyBoYXMgVVRGLTE2IGNvZGUgdW5pdHMgdGhhdCBkbyBub3QgZml0IGluIDggYml0cyIpfUhFQVBVOFtwdHIrNCtpXT1jaGFyQ29kZX19ZWxzZXtmb3IodmFyIGk9MDtpPGxlbmd0aDsrK2kpe0hFQVBVOFtwdHIrNCtpXT12YWx1ZVtpXX19fWlmKGRlc3RydWN0b3JzIT09bnVsbCl7ZGVzdHJ1Y3RvcnMucHVzaChfZnJlZSxwdHIpfXJldHVybiBwdHJ9LCJhcmdQYWNrQWR2YW5jZSI6OCwicmVhZFZhbHVlRnJvbVBvaW50ZXIiOnNpbXBsZVJlYWRWYWx1ZUZyb21Qb2ludGVyLGRlc3RydWN0b3JGdW5jdGlvbjpmdW5jdGlvbihwdHIpe19mcmVlKHB0cil9fSl9ZnVuY3Rpb24gX19lbWJpbmRfcmVnaXN0ZXJfc3RkX3dzdHJpbmcocmF3VHlwZSxjaGFyU2l6ZSxuYW1lKXtuYW1lPXJlYWRMYXRpbjFTdHJpbmcobmFtZSk7dmFyIGRlY29kZVN0cmluZyxlbmNvZGVTdHJpbmcsZ2V0SGVhcCxsZW5ndGhCeXRlc1VURixzaGlmdDtpZihjaGFyU2l6ZT09PTIpe2RlY29kZVN0cmluZz1VVEYxNlRvU3RyaW5nO2VuY29kZVN0cmluZz1zdHJpbmdUb1VURjE2O2xlbmd0aEJ5dGVzVVRGPWxlbmd0aEJ5dGVzVVRGMTY7Z2V0SGVhcD0oKCk9PkhFQVBVMTYpO3NoaWZ0PTF9ZWxzZSBpZihjaGFyU2l6ZT09PTQpe2RlY29kZVN0cmluZz1VVEYzMlRvU3RyaW5nO2VuY29kZVN0cmluZz1zdHJpbmdUb1VURjMyO2xlbmd0aEJ5dGVzVVRGPWxlbmd0aEJ5dGVzVVRGMzI7Z2V0SGVhcD0oKCk9PkhFQVBVMzIpO3NoaWZ0PTJ9cmVnaXN0ZXJUeXBlKHJhd1R5cGUse25hbWU6bmFtZSwiZnJvbVdpcmVUeXBlIjpmdW5jdGlvbih2YWx1ZSl7dmFyIGxlbmd0aD1IRUFQVTMyW3ZhbHVlPj4yXTt2YXIgSEVBUD1nZXRIZWFwKCk7dmFyIHN0cjt2YXIgZGVjb2RlU3RhcnRQdHI9dmFsdWUrNDtmb3IodmFyIGk9MDtpPD1sZW5ndGg7KytpKXt2YXIgY3VycmVudEJ5dGVQdHI9dmFsdWUrNCtpKmNoYXJTaXplO2lmKGk9PWxlbmd0aHx8SEVBUFtjdXJyZW50Qnl0ZVB0cj4+c2hpZnRdPT0wKXt2YXIgbWF4UmVhZEJ5dGVzPWN1cnJlbnRCeXRlUHRyLWRlY29kZVN0YXJ0UHRyO3ZhciBzdHJpbmdTZWdtZW50PWRlY29kZVN0cmluZyhkZWNvZGVTdGFydFB0cixtYXhSZWFkQnl0ZXMpO2lmKHN0cj09PXVuZGVmaW5lZCl7c3RyPXN0cmluZ1NlZ21lbnR9ZWxzZXtzdHIrPVN0cmluZy5mcm9tQ2hhckNvZGUoMCk7c3RyKz1zdHJpbmdTZWdtZW50fWRlY29kZVN0YXJ0UHRyPWN1cnJlbnRCeXRlUHRyK2NoYXJTaXplfX1fZnJlZSh2YWx1ZSk7cmV0dXJuIHN0cn0sInRvV2lyZVR5cGUiOmZ1bmN0aW9uKGRlc3RydWN0b3JzLHZhbHVlKXtpZighKHR5cGVvZiB2YWx1ZT09PSJzdHJpbmciKSl7dGhyb3dCaW5kaW5nRXJyb3IoIkNhbm5vdCBwYXNzIG5vbi1zdHJpbmcgdG8gQysrIHN0cmluZyB0eXBlICIrbmFtZSl9dmFyIGxlbmd0aD1sZW5ndGhCeXRlc1VURih2YWx1ZSk7dmFyIHB0cj1fbWFsbG9jKDQrbGVuZ3RoK2NoYXJTaXplKTtIRUFQVTMyW3B0cj4+Ml09bGVuZ3RoPj5zaGlmdDtlbmNvZGVTdHJpbmcodmFsdWUscHRyKzQsbGVuZ3RoK2NoYXJTaXplKTtpZihkZXN0cnVjdG9ycyE9PW51bGwpe2Rlc3RydWN0b3JzLnB1c2goX2ZyZWUscHRyKX1yZXR1cm4gcHRyfSwiYXJnUGFja0FkdmFuY2UiOjgsInJlYWRWYWx1ZUZyb21Qb2ludGVyIjpzaW1wbGVSZWFkVmFsdWVGcm9tUG9pbnRlcixkZXN0cnVjdG9yRnVuY3Rpb246ZnVuY3Rpb24ocHRyKXtfZnJlZShwdHIpfX0pfWZ1bmN0aW9uIF9fZW1iaW5kX3JlZ2lzdGVyX3ZhbHVlX29iamVjdChyYXdUeXBlLG5hbWUsY29uc3RydWN0b3JTaWduYXR1cmUscmF3Q29uc3RydWN0b3IsZGVzdHJ1Y3RvclNpZ25hdHVyZSxyYXdEZXN0cnVjdG9yKXtzdHJ1Y3RSZWdpc3RyYXRpb25zW3Jhd1R5cGVdPXtuYW1lOnJlYWRMYXRpbjFTdHJpbmcobmFtZSkscmF3Q29uc3RydWN0b3I6ZW1iaW5kX19yZXF1aXJlRnVuY3Rpb24oY29uc3RydWN0b3JTaWduYXR1cmUscmF3Q29uc3RydWN0b3IpLHJhd0Rlc3RydWN0b3I6ZW1iaW5kX19yZXF1aXJlRnVuY3Rpb24oZGVzdHJ1Y3RvclNpZ25hdHVyZSxyYXdEZXN0cnVjdG9yKSxmaWVsZHM6W119fWZ1bmN0aW9uIF9fZW1iaW5kX3JlZ2lzdGVyX3ZhbHVlX29iamVjdF9maWVsZChzdHJ1Y3RUeXBlLGZpZWxkTmFtZSxnZXR0ZXJSZXR1cm5UeXBlLGdldHRlclNpZ25hdHVyZSxnZXR0ZXIsZ2V0dGVyQ29udGV4dCxzZXR0ZXJBcmd1bWVudFR5cGUsc2V0dGVyU2lnbmF0dXJlLHNldHRlcixzZXR0ZXJDb250ZXh0KXtzdHJ1Y3RSZWdpc3RyYXRpb25zW3N0cnVjdFR5cGVdLmZpZWxkcy5wdXNoKHtmaWVsZE5hbWU6cmVhZExhdGluMVN0cmluZyhmaWVsZE5hbWUpLGdldHRlclJldHVyblR5cGU6Z2V0dGVyUmV0dXJuVHlwZSxnZXR0ZXI6ZW1iaW5kX19yZXF1aXJlRnVuY3Rpb24oZ2V0dGVyU2lnbmF0dXJlLGdldHRlciksZ2V0dGVyQ29udGV4dDpnZXR0ZXJDb250ZXh0LHNldHRlckFyZ3VtZW50VHlwZTpzZXR0ZXJBcmd1bWVudFR5cGUsc2V0dGVyOmVtYmluZF9fcmVxdWlyZUZ1bmN0aW9uKHNldHRlclNpZ25hdHVyZSxzZXR0ZXIpLHNldHRlckNvbnRleHQ6c2V0dGVyQ29udGV4dH0pfWZ1bmN0aW9uIF9fZW1iaW5kX3JlZ2lzdGVyX3ZvaWQocmF3VHlwZSxuYW1lKXtuYW1lPXJlYWRMYXRpbjFTdHJpbmcobmFtZSk7cmVnaXN0ZXJUeXBlKHJhd1R5cGUse2lzVm9pZDp0cnVlLG5hbWU6bmFtZSwiYXJnUGFja0FkdmFuY2UiOjAsImZyb21XaXJlVHlwZSI6ZnVuY3Rpb24oKXtyZXR1cm4gdW5kZWZpbmVkfSwidG9XaXJlVHlwZSI6ZnVuY3Rpb24oZGVzdHJ1Y3RvcnMsbyl7cmV0dXJuIHVuZGVmaW5lZH19KX1mdW5jdGlvbiBfX2VtdmFsX2luY3JlZihoYW5kbGUpe2lmKGhhbmRsZT40KXtlbXZhbF9oYW5kbGVfYXJyYXlbaGFuZGxlXS5yZWZjb3VudCs9MX19ZnVuY3Rpb24gX19lbXZhbF90YWtlX3ZhbHVlKHR5cGUsYXJndil7dHlwZT1yZXF1aXJlUmVnaXN0ZXJlZFR5cGUodHlwZSwiX2VtdmFsX3Rha2VfdmFsdWUiKTt2YXIgdj10eXBlWyJyZWFkVmFsdWVGcm9tUG9pbnRlciJdKGFyZ3YpO3JldHVybiBFbXZhbC50b0hhbmRsZSh2KX1mdW5jdGlvbiBfYWJvcnQoKXthYm9ydCgiIil9ZnVuY3Rpb24gX2Vtc2NyaXB0ZW5fbWVtY3B5X2JpZyhkZXN0LHNyYyxudW0pe0hFQVBVOC5jb3B5V2l0aGluKGRlc3Qsc3JjLHNyYytudW0pfWZ1bmN0aW9uIGVtc2NyaXB0ZW5fcmVhbGxvY19idWZmZXIoc2l6ZSl7dHJ5e3dhc21NZW1vcnkuZ3JvdyhzaXplLWJ1ZmZlci5ieXRlTGVuZ3RoKzY1NTM1Pj4+MTYpO3VwZGF0ZUdsb2JhbEJ1ZmZlckFuZFZpZXdzKHdhc21NZW1vcnkuYnVmZmVyKTtyZXR1cm4gMX1jYXRjaChlKXt9fWZ1bmN0aW9uIF9lbXNjcmlwdGVuX3Jlc2l6ZV9oZWFwKHJlcXVlc3RlZFNpemUpe3ZhciBvbGRTaXplPUhFQVBVOC5sZW5ndGg7cmVxdWVzdGVkU2l6ZT1yZXF1ZXN0ZWRTaXplPj4+MDt2YXIgbWF4SGVhcFNpemU9MjE0NzQ4MzY0ODtpZihyZXF1ZXN0ZWRTaXplPm1heEhlYXBTaXplKXtyZXR1cm4gZmFsc2V9Zm9yKHZhciBjdXREb3duPTE7Y3V0RG93bjw9NDtjdXREb3duKj0yKXt2YXIgb3Zlckdyb3duSGVhcFNpemU9b2xkU2l6ZSooMSsuMi9jdXREb3duKTtvdmVyR3Jvd25IZWFwU2l6ZT1NYXRoLm1pbihvdmVyR3Jvd25IZWFwU2l6ZSxyZXF1ZXN0ZWRTaXplKzEwMDY2MzI5Nik7dmFyIG5ld1NpemU9TWF0aC5taW4obWF4SGVhcFNpemUsYWxpZ25VcChNYXRoLm1heChyZXF1ZXN0ZWRTaXplLG92ZXJHcm93bkhlYXBTaXplKSw2NTUzNikpO3ZhciByZXBsYWNlbWVudD1lbXNjcmlwdGVuX3JlYWxsb2NfYnVmZmVyKG5ld1NpemUpO2lmKHJlcGxhY2VtZW50KXtyZXR1cm4gdHJ1ZX19cmV0dXJuIGZhbHNlfXZhciBTWVNDQUxMUz17bWFwcGluZ3M6e30sYnVmZmVyczpbbnVsbCxbXSxbXV0scHJpbnRDaGFyOmZ1bmN0aW9uKHN0cmVhbSxjdXJyKXt2YXIgYnVmZmVyPVNZU0NBTExTLmJ1ZmZlcnNbc3RyZWFtXTtpZihjdXJyPT09MHx8Y3Vycj09PTEwKXsoc3RyZWFtPT09MT9vdXQ6ZXJyKShVVEY4QXJyYXlUb1N0cmluZyhidWZmZXIsMCkpO2J1ZmZlci5sZW5ndGg9MH1lbHNle2J1ZmZlci5wdXNoKGN1cnIpfX0sdmFyYXJnczp1bmRlZmluZWQsZ2V0OmZ1bmN0aW9uKCl7U1lTQ0FMTFMudmFyYXJncys9NDt2YXIgcmV0PUhFQVAzMltTWVNDQUxMUy52YXJhcmdzLTQ+PjJdO3JldHVybiByZXR9LGdldFN0cjpmdW5jdGlvbihwdHIpe3ZhciByZXQ9VVRGOFRvU3RyaW5nKHB0cik7cmV0dXJuIHJldH0sZ2V0NjQ6ZnVuY3Rpb24obG93LGhpZ2gpe3JldHVybiBsb3d9fTtmdW5jdGlvbiBfZmRfY2xvc2UoZmQpe3JldHVybiAwfWZ1bmN0aW9uIF9mZF9zZWVrKGZkLG9mZnNldF9sb3csb2Zmc2V0X2hpZ2gsd2hlbmNlLG5ld09mZnNldCl7fWZ1bmN0aW9uIF9mZF93cml0ZShmZCxpb3YsaW92Y250LHBudW0pe3ZhciBudW09MDtmb3IodmFyIGk9MDtpPGlvdmNudDtpKyspe3ZhciBwdHI9SEVBUDMyW2lvdj4+Ml07dmFyIGxlbj1IRUFQMzJbaW92KzQ+PjJdO2lvdis9ODtmb3IodmFyIGo9MDtqPGxlbjtqKyspe1NZU0NBTExTLnByaW50Q2hhcihmZCxIRUFQVThbcHRyK2pdKX1udW0rPWxlbn1IRUFQMzJbcG51bT4+Ml09bnVtO3JldHVybiAwfWZ1bmN0aW9uIF9zZXRUZW1wUmV0MCh2YWwpe3NldFRlbXBSZXQwKHZhbCl9SW50ZXJuYWxFcnJvcj1Nb2R1bGVbIkludGVybmFsRXJyb3IiXT1leHRlbmRFcnJvcihFcnJvciwiSW50ZXJuYWxFcnJvciIpO2VtYmluZF9pbml0X2NoYXJDb2RlcygpO0JpbmRpbmdFcnJvcj1Nb2R1bGVbIkJpbmRpbmdFcnJvciJdPWV4dGVuZEVycm9yKEVycm9yLCJCaW5kaW5nRXJyb3IiKTtpbml0X2VtdmFsKCk7VW5ib3VuZFR5cGVFcnJvcj1Nb2R1bGVbIlVuYm91bmRUeXBlRXJyb3IiXT1leHRlbmRFcnJvcihFcnJvciwiVW5ib3VuZFR5cGVFcnJvciIpO3ZhciBBU1NFUlRJT05TPWZhbHNlO2Z1bmN0aW9uIGludEFycmF5VG9TdHJpbmcoYXJyYXkpe3ZhciByZXQ9W107Zm9yKHZhciBpPTA7aTxhcnJheS5sZW5ndGg7aSsrKXt2YXIgY2hyPWFycmF5W2ldO2lmKGNocj4yNTUpe2lmKEFTU0VSVElPTlMpe2Fzc2VydChmYWxzZSwiQ2hhcmFjdGVyIGNvZGUgIitjaHIrIiAoIitTdHJpbmcuZnJvbUNoYXJDb2RlKGNocikrIikgIGF0IG9mZnNldCAiK2krIiBub3QgaW4gMHgwMC0weEZGLiIpfWNociY9MjU1fXJldC5wdXNoKFN0cmluZy5mcm9tQ2hhckNvZGUoY2hyKSl9cmV0dXJuIHJldC5qb2luKCIiKX12YXIgZGVjb2RlQmFzZTY0PXR5cGVvZiBhdG9iPT09ImZ1bmN0aW9uIj9hdG9iOmZ1bmN0aW9uKGlucHV0KXt2YXIga2V5U3RyPSJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvPSI7dmFyIG91dHB1dD0iIjt2YXIgY2hyMSxjaHIyLGNocjM7dmFyIGVuYzEsZW5jMixlbmMzLGVuYzQ7dmFyIGk9MDtpbnB1dD1pbnB1dC5yZXBsYWNlKC9bXkEtWmEtejAtOVwrXC9cPV0vZywiIik7ZG97ZW5jMT1rZXlTdHIuaW5kZXhPZihpbnB1dC5jaGFyQXQoaSsrKSk7ZW5jMj1rZXlTdHIuaW5kZXhPZihpbnB1dC5jaGFyQXQoaSsrKSk7ZW5jMz1rZXlTdHIuaW5kZXhPZihpbnB1dC5jaGFyQXQoaSsrKSk7ZW5jND1rZXlTdHIuaW5kZXhPZihpbnB1dC5jaGFyQXQoaSsrKSk7Y2hyMT1lbmMxPDwyfGVuYzI+PjQ7Y2hyMj0oZW5jMiYxNSk8PDR8ZW5jMz4+MjtjaHIzPShlbmMzJjMpPDw2fGVuYzQ7b3V0cHV0PW91dHB1dCtTdHJpbmcuZnJvbUNoYXJDb2RlKGNocjEpO2lmKGVuYzMhPT02NCl7b3V0cHV0PW91dHB1dCtTdHJpbmcuZnJvbUNoYXJDb2RlKGNocjIpfWlmKGVuYzQhPT02NCl7b3V0cHV0PW91dHB1dCtTdHJpbmcuZnJvbUNoYXJDb2RlKGNocjMpfX13aGlsZShpPGlucHV0Lmxlbmd0aCk7cmV0dXJuIG91dHB1dH07ZnVuY3Rpb24gaW50QXJyYXlGcm9tQmFzZTY0KHMpe2lmKHR5cGVvZiBFTlZJUk9OTUVOVF9JU19OT0RFPT09ImJvb2xlYW4iJiZFTlZJUk9OTUVOVF9JU19OT0RFKXt2YXIgYnVmPUJ1ZmZlci5mcm9tKHMsImJhc2U2NCIpO3JldHVybiBuZXcgVWludDhBcnJheShidWZbImJ1ZmZlciJdLGJ1ZlsiYnl0ZU9mZnNldCJdLGJ1ZlsiYnl0ZUxlbmd0aCJdKX10cnl7dmFyIGRlY29kZWQ9ZGVjb2RlQmFzZTY0KHMpO3ZhciBieXRlcz1uZXcgVWludDhBcnJheShkZWNvZGVkLmxlbmd0aCk7Zm9yKHZhciBpPTA7aTxkZWNvZGVkLmxlbmd0aDsrK2kpe2J5dGVzW2ldPWRlY29kZWQuY2hhckNvZGVBdChpKX1yZXR1cm4gYnl0ZXN9Y2F0Y2goXyl7dGhyb3cgbmV3IEVycm9yKCJDb252ZXJ0aW5nIGJhc2U2NCBzdHJpbmcgdG8gYnl0ZXMgZmFpbGVkLiIpfX1mdW5jdGlvbiB0cnlQYXJzZUFzRGF0YVVSSShmaWxlbmFtZSl7aWYoIWlzRGF0YVVSSShmaWxlbmFtZSkpe3JldHVybn1yZXR1cm4gaW50QXJyYXlGcm9tQmFzZTY0KGZpbGVuYW1lLnNsaWNlKGRhdGFVUklQcmVmaXgubGVuZ3RoKSl9dmFyIGFzbUxpYnJhcnlBcmc9eyJwIjpfX2VtYmluZF9maW5hbGl6ZV92YWx1ZV9vYmplY3QsInMiOl9fZW1iaW5kX3JlZ2lzdGVyX2JpZ2ludCwieSI6X19lbWJpbmRfcmVnaXN0ZXJfYm9vbCwiZiI6X19lbWJpbmRfcmVnaXN0ZXJfY29uc3RhbnQsIngiOl9fZW1iaW5kX3JlZ2lzdGVyX2VtdmFsLCJvIjpfX2VtYmluZF9yZWdpc3Rlcl9lbnVtLCJhIjpfX2VtYmluZF9yZWdpc3Rlcl9lbnVtX3ZhbHVlLCJuIjpfX2VtYmluZF9yZWdpc3Rlcl9mbG9hdCwiYyI6X19lbWJpbmRfcmVnaXN0ZXJfZnVuY3Rpb24sImUiOl9fZW1iaW5kX3JlZ2lzdGVyX2ludGVnZXIsImIiOl9fZW1iaW5kX3JlZ2lzdGVyX21lbW9yeV92aWV3LCJtIjpfX2VtYmluZF9yZWdpc3Rlcl9zdGRfc3RyaW5nLCJpIjpfX2VtYmluZF9yZWdpc3Rlcl9zdGRfd3N0cmluZywicSI6X19lbWJpbmRfcmVnaXN0ZXJfdmFsdWVfb2JqZWN0LCJkIjpfX2VtYmluZF9yZWdpc3Rlcl92YWx1ZV9vYmplY3RfZmllbGQsInoiOl9fZW1iaW5kX3JlZ2lzdGVyX3ZvaWQsImoiOl9fZW12YWxfZGVjcmVmLCJrIjpfX2VtdmFsX2luY3JlZiwiZyI6X19lbXZhbF90YWtlX3ZhbHVlLCJoIjpfYWJvcnQsInciOl9lbXNjcmlwdGVuX21lbWNweV9iaWcsInUiOl9lbXNjcmlwdGVuX3Jlc2l6ZV9oZWFwLCJ2IjpfZmRfY2xvc2UsInIiOl9mZF9zZWVrLCJsIjpfZmRfd3JpdGUsInQiOl9zZXRUZW1wUmV0MH07dmFyIGFzbT1jcmVhdGVXYXNtKCk7dmFyIF9fX3dhc21fY2FsbF9jdG9ycz1Nb2R1bGVbIl9fX3dhc21fY2FsbF9jdG9ycyJdPWZ1bmN0aW9uKCl7cmV0dXJuKF9fX3dhc21fY2FsbF9jdG9ycz1Nb2R1bGVbIl9fX3dhc21fY2FsbF9jdG9ycyJdPU1vZHVsZVsiYXNtIl1bIkIiXSkuYXBwbHkobnVsbCxhcmd1bWVudHMpfTt2YXIgX2ZyZWU9TW9kdWxlWyJfZnJlZSJdPWZ1bmN0aW9uKCl7cmV0dXJuKF9mcmVlPU1vZHVsZVsiX2ZyZWUiXT1Nb2R1bGVbImFzbSJdWyJEIl0pLmFwcGx5KG51bGwsYXJndW1lbnRzKX07dmFyIF9tYWxsb2M9TW9kdWxlWyJfbWFsbG9jIl09ZnVuY3Rpb24oKXtyZXR1cm4oX21hbGxvYz1Nb2R1bGVbIl9tYWxsb2MiXT1Nb2R1bGVbImFzbSJdWyJFIl0pLmFwcGx5KG51bGwsYXJndW1lbnRzKX07dmFyIF9fX2dldFR5cGVOYW1lPU1vZHVsZVsiX19fZ2V0VHlwZU5hbWUiXT1mdW5jdGlvbigpe3JldHVybihfX19nZXRUeXBlTmFtZT1Nb2R1bGVbIl9fX2dldFR5cGVOYW1lIl09TW9kdWxlWyJhc20iXVsiRiJdKS5hcHBseShudWxsLGFyZ3VtZW50cyl9O3ZhciBfX19lbWJpbmRfcmVnaXN0ZXJfbmF0aXZlX2FuZF9idWlsdGluX3R5cGVzPU1vZHVsZVsiX19fZW1iaW5kX3JlZ2lzdGVyX25hdGl2ZV9hbmRfYnVpbHRpbl90eXBlcyJdPWZ1bmN0aW9uKCl7cmV0dXJuKF9fX2VtYmluZF9yZWdpc3Rlcl9uYXRpdmVfYW5kX2J1aWx0aW5fdHlwZXM9TW9kdWxlWyJfX19lbWJpbmRfcmVnaXN0ZXJfbmF0aXZlX2FuZF9idWlsdGluX3R5cGVzIl09TW9kdWxlWyJhc20iXVsiRyJdKS5hcHBseShudWxsLGFyZ3VtZW50cyl9O3ZhciBkeW5DYWxsX2ppamk9TW9kdWxlWyJkeW5DYWxsX2ppamkiXT1mdW5jdGlvbigpe3JldHVybihkeW5DYWxsX2ppamk9TW9kdWxlWyJkeW5DYWxsX2ppamkiXT1Nb2R1bGVbImFzbSJdWyJIIl0pLmFwcGx5KG51bGwsYXJndW1lbnRzKX07dmFyIGNhbGxlZFJ1bjtmdW5jdGlvbiBFeGl0U3RhdHVzKHN0YXR1cyl7dGhpcy5uYW1lPSJFeGl0U3RhdHVzIjt0aGlzLm1lc3NhZ2U9IlByb2dyYW0gdGVybWluYXRlZCB3aXRoIGV4aXQoIitzdGF0dXMrIikiO3RoaXMuc3RhdHVzPXN0YXR1c31kZXBlbmRlbmNpZXNGdWxmaWxsZWQ9ZnVuY3Rpb24gcnVuQ2FsbGVyKCl7aWYoIWNhbGxlZFJ1bilydW4oKTtpZighY2FsbGVkUnVuKWRlcGVuZGVuY2llc0Z1bGZpbGxlZD1ydW5DYWxsZXJ9O2Z1bmN0aW9uIHJ1bihhcmdzKXthcmdzPWFyZ3N8fGFyZ3VtZW50c187aWYocnVuRGVwZW5kZW5jaWVzPjApe3JldHVybn1wcmVSdW4oKTtpZihydW5EZXBlbmRlbmNpZXM+MCl7cmV0dXJufWZ1bmN0aW9uIGRvUnVuKCl7aWYoY2FsbGVkUnVuKXJldHVybjtjYWxsZWRSdW49dHJ1ZTtNb2R1bGVbImNhbGxlZFJ1biJdPXRydWU7aWYoQUJPUlQpcmV0dXJuO2luaXRSdW50aW1lKCk7cmVhZHlQcm9taXNlUmVzb2x2ZShNb2R1bGUpO2lmKE1vZHVsZVsib25SdW50aW1lSW5pdGlhbGl6ZWQiXSlNb2R1bGVbIm9uUnVudGltZUluaXRpYWxpemVkIl0oKTtwb3N0UnVuKCl9aWYoTW9kdWxlWyJzZXRTdGF0dXMiXSl7TW9kdWxlWyJzZXRTdGF0dXMiXSgiUnVubmluZy4uLiIpO3NldFRpbWVvdXQoZnVuY3Rpb24oKXtzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7TW9kdWxlWyJzZXRTdGF0dXMiXSgiIil9LDEpO2RvUnVuKCl9LDEpfWVsc2V7ZG9SdW4oKX19TW9kdWxlWyJydW4iXT1ydW47aWYoTW9kdWxlWyJwcmVJbml0Il0pe2lmKHR5cGVvZiBNb2R1bGVbInByZUluaXQiXT09ImZ1bmN0aW9uIilNb2R1bGVbInByZUluaXQiXT1bTW9kdWxlWyJwcmVJbml0Il1dO3doaWxlKE1vZHVsZVsicHJlSW5pdCJdLmxlbmd0aD4wKXtNb2R1bGVbInByZUluaXQiXS5wb3AoKSgpfX1ydW4oKTsKCgogIHJldHVybiBnZ3dhdmVfZmFjdG9yeS5yZWFkeQp9Cik7Cn0pKCk7CmlmICh0eXBlb2YgZXhwb3J0cyA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIG1vZHVsZSA9PT0gJ29iamVjdCcpCiAgbW9kdWxlLmV4cG9ydHMgPSBnZ3dhdmVfZmFjdG9yeTsKZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PT0gJ2Z1bmN0aW9uJyAmJiBkZWZpbmVbJ2FtZCddKQogIGRlZmluZShbXSwgZnVuY3Rpb24oKSB7IHJldHVybiBnZ3dhdmVfZmFjdG9yeTsgfSk7CmVsc2UgaWYgKHR5cGVvZiBleHBvcnRzID09PSAnb2JqZWN0JykKICBleHBvcnRzWyJnZ3dhdmVfZmFjdG9yeSJdID0gZ2d3YXZlX2ZhY3Rvcnk7Cg==),
     protocol p=4. Only payloads the decoder actually returns — TAP, DBL,
     HLD, or a valid metric payload — become journal entries; there is no
     fallback guesser.
     Every chirp becomes a journal entry: sub tap + timestamp, then the Dom
     prompt (Way A) attaches the spoken activity and the Dom's own rating.
     No audio is stored; speech transcription uses the Web Speech API. */
  var GW_SUB = {
    TAP: { level: 2, label: "Enjoying", detail: "Tap — enjoying, all good" },
    DBL: { level: 1, label: "Kind of / mixed", detail: "Double-tap — only kind of enjoying it" },
    HLD: { level: 0, label: "Slow down", detail: "Hold — slow down" }
  };
  var GW_METRICS = {
    E: { name: "Enjoyment" },
    H: { name: "Heat" },
    N: { name: "Endurance" }
  };
  function gwParseMetric(txt) {
    var m = /^([EHN])(-?\d{1,3})$/.exec(String(txt || ""));
    if (!m) return null;
    var v = parseInt(m[2], 10);
    if (isNaN(v) || v < -100 || v > 100) return null;
    return { metric: m[1], value: v };
  }
  function gwFmtVal(v) { return (v > 0 ? "+" : "") + String(v); }
  function gwIsMetric(entry) { return !!(entry && entry.metric && GW_METRICS[entry.metric]); }
  function gwSubLevel(entry) {
    if (gwIsMetric(entry)) { var v = +entry.value || 0; return v >= 34 ? 2 : (v <= -34 ? 0 : 1); }
    return gwSubMeta(entry).level;
  }
  function gwEntrySubText(entry) {
    var tag = entry.code + (entry.source === "ble" ? ", Bluetooth" : "") + (entry.profileId ? ", profile " + entry.profileId : ", broadcast (no key)");
    if (gwIsMetric(entry)) return GW_METRICS[entry.metric].name + " " + gwFmtVal(+entry.value || 0) + " [" + tag + "]";
    return gwSubMeta(entry).detail + " [" + tag + "]";
  }
  var GW_DOM_LABELS = ["Not enjoying", "Mixed", "Enjoying", "Loving it"];
  var gwListenBtn = SexcapadesRuntime.DOM.byId("gwListenToggle"),
      gwListenStatus = SexcapadesRuntime.DOM.byId("gwListenStatus"),
      gwDecodeStatus = SexcapadesRuntime.DOM.byId("gwDecodeStatus"),
      gwLiveSub = SexcapadesRuntime.DOM.byId("gwLiveSub"), gwLiveSubTime = SexcapadesRuntime.DOM.byId("gwLiveSubTime"),
      gwLiveDom = SexcapadesRuntime.DOM.byId("gwLiveDom"), gwLiveDomTime = SexcapadesRuntime.DOM.byId("gwLiveDomTime"),
      gwMismatchBanner = SexcapadesRuntime.DOM.byId("gwMismatchBanner"), gwMismatchText = SexcapadesRuntime.DOM.byId("gwMismatchText"),
      gwPrompt = SexcapadesRuntime.DOM.byId("gwDomPrompt"), gwPromptTitle = SexcapadesRuntime.DOM.byId("gwDomPromptTitle"),
      gwSpeakBtn = SexcapadesRuntime.DOM.byId("gwSpeakBtn"), gwActivityInput = SexcapadesRuntime.DOM.byId("gwActivityInput"),
      gwActivitySave = SexcapadesRuntime.DOM.byId("gwActivitySave"), gwSpeechStatus = SexcapadesRuntime.DOM.byId("gwSpeechStatus"),
      gwDomRateBox = SexcapadesRuntime.DOM.byId("gwDomRateBox"),
      gwMetricE = SexcapadesRuntime.DOM.byId("gwMetricE"), gwMetricETime = SexcapadesRuntime.DOM.byId("gwMetricETime"),
      gwMetricH = SexcapadesRuntime.DOM.byId("gwMetricH"), gwMetricHTime = SexcapadesRuntime.DOM.byId("gwMetricHTime"),
      gwMetricN = SexcapadesRuntime.DOM.byId("gwMetricN"), gwMetricNTime = SexcapadesRuntime.DOM.byId("gwMetricNTime"),
      gwAftercareList = SexcapadesRuntime.DOM.byId("gwAftercareList"), gwJournalEmpty = SexcapadesRuntime.DOM.byId("gwJournalEmpty");
  var gwPromptEntryId = null;
  function fmtCT(ts) {
    try { return new Date(ts).toLocaleString("en-US", { timeZone: "America/Chicago", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", second: "2-digit" }) + " CT"; }
    catch (e) { return fmtTimeSec(ts); }
  }
  function gwSubMeta(entry) { return GW_SUB[entry.code] || GW_SUB.TAP; }
  function gwIsMismatch(entry) {
    /* The one approved rule: sub only kind of enjoying it (double-tap)
       AND Dom not enjoying it (rating 0). Nothing else is a mismatch. */
    if (!entry || entry.domEnjoy === null || entry.domEnjoy === undefined) return false;
    return entry.code === "DBL" && entry.domEnjoy === 0;
  }
  function gwAlignment(entry) {
    if (!entry || entry.domEnjoy === null || entry.domEnjoy === undefined) return { tone: "pending", label: "Waiting on Dom rating" };
    if (gwIsMismatch(entry)) return { tone: "mismatch", label: "Mismatch — should have stopped" };
    var sub = gwSubLevel(entry);
    if ((sub === 2 && entry.domEnjoy >= 2) || (sub === 1 && entry.domEnjoy === 2)) return { tone: "aligned", label: "Aligned" };
    if (sub === 2 && entry.domEnjoy === 3) return { tone: "aligned", label: "Aligned" };
    return { tone: "differed", label: "Differed — talk it over" };
  }
  function gwLatest() { for (var i = 0; i < state.journal.length; i++) { if (!gwIsMetric(state.journal[i])) return state.journal[i]; } return null; }
  function gwBeep() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      if (!gwBeep.ctx) gwBeep.ctx = new AC();
      var ctx = gwBeep.ctx, t0 = ctx.currentTime;
      [880, 1174].forEach(function (f, i) {
        var o = ctx.createOscillator(), g = ctx.createGain();
        o.frequency.value = f; o.type = "sine";
        g.gain.setValueAtTime(0.0001, t0 + i * 0.16);
        g.gain.exponentialRampToValueAtTime(0.12, t0 + i * 0.16 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + i * 0.16 + 0.15);
        o.connect(g); g.connect(ctx.destination);
        o.start(t0 + i * 0.16); o.stop(t0 + i * 0.16 + 0.16);
      });
    } catch (e) { __sxErrLog("gw-beep", e); }
  }
  function gwOnChirp(code, source, profileId) {
    if (!GW_SUB[code]) return;
    var entry = { id: "gw" + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36), t: nowMs(), code: code, source: source || "watch", profileId: profileId || "", activity: "", sched: (typeof guideCurrentSched === "function" ? guideCurrentSched() : ""), domEnjoy: null, domAt: 0 };
    state.journal.unshift(entry);
    if (state.journal.length > 200) state.journal.length = 200;
    save();
    gwPromptEntryId = entry.id;
    vibrate(code === "HLD" ? [120, 50, 120] : [70, 40, 70]);
    gwBeep();
    renderJournal();
    if (gwSpeechStatus) gwSpeechStatus.textContent = "Heard " + code + " at " + fmtCT(entry.t) + " — Dom, name the activity.";
    if (gwActivityInput) gwActivityInput.focus();
  }
  function gwOnMetric(parsed, rawCode, source, profileId) {
    var entry = { id: "gw" + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36), t: nowMs(), code: rawCode, metric: parsed.metric, value: parsed.value, source: source || "watch", profileId: profileId || "", activity: "", sched: (typeof guideCurrentSched === "function" ? guideCurrentSched() : ""), domEnjoy: null, domAt: 0 };
    state.journal.unshift(entry);
    if (state.journal.length > 200) state.journal.length = 200;
    save();
    vibrate([50]);
    gwBeep();
    renderJournal();
    if (gwSpeechStatus) gwSpeechStatus.textContent = "Heard " + rawCode + " at " + fmtCT(entry.t) + " — " + GW_METRICS[parsed.metric].name + " " + gwFmtVal(parsed.value) + " (the watch's display value, shown as-is).";
  }
  /* GibberLink addressing (gibberlink-1108-1400): the sender's profile
     KEY prefixes its signals (adam:TAP, adam:E40) and is attributed
     per key, case preserved — the key is the identifier, there is no
     numeric UID. A payload with NO key is a BROADCAST from all watches
     (Jason's backward-compatibility rule, 2026-11-08): unkeyed TAP /
     DBL / HLD, metric readings, and ACK:CFG are processed as broadcast
     on the Broadcast watch card and in the journal — never dropped —
     so un-setup watches and older GibberWear builds keep working.
     ACKs (keyed ACK:<key>:CFG, unkeyed ACK:CFG) confirm a setup send. */
  var gwPendingCfgKey = "", gwPendingCfgTimer = null, gwPendingHeatValue = null;
  function gwOnAck(ackKey, source) {
    var via = source === "ble" ? "Bluetooth" : "ultrasound";
    if (ackKey) {
      gwLinkLog("IN", "ACK:" + ackKey + ":CFG", via);
      if (gwPendingCfgKey && ackKey === gwPendingCfgKey) {
        var confirmedKey = gwPendingCfgKey;
        var pendingHeat = gwPendingHeatValue;
        gwPendingCfgKey = "";
        gwPendingHeatValue = null;
        if (gwPendingCfgTimer) { try { SexcapadesRuntime.TimerManager.clear(gwPendingCfgTimer); } catch (e) {} gwPendingCfgTimer = null; }
        if (typeof pendingHeat === "number" && isFinite(pendingHeat)) {
          gwCfgSetStatus("Setup confirmed by " + confirmedKey + ". Syncing heat in 1.5s…");
          var delayTimer = (window.SexcapadesRuntime && SexcapadesRuntime.TimerManager && SexcapadesRuntime.TimerManager.setTimeout) ? SexcapadesRuntime.TimerManager.setTimeout : setTimeout;
          delayTimer(function () {
            var heatPayload = "HEAT:" + confirmedKey + ":" + Math.max(-100, Math.min(100, Math.round(pendingHeat)));
            gwSendBoth(heatPayload).then(function (hres) {
              gwLinkLog("OUT", heatPayload, hres.ble === true ? "Bluetooth" : "ultrasound");
              gwCfgSetStatus("Setup confirmed and heat synced (" + heatPayload + ") to " + confirmedKey + ".");
              if (gwTransientListen) gwStopListening("", true);
            });
          }, 1500);
        } else {
          gwCfgSetStatus("Setup confirmed — watch " + ackKey + " answered ACK:" + ackKey + ":CFG.");
          if (gwTransientListen) gwStopListening("", true);
        }
      } else if (gwCfgStatusEl) {
        gwCfgSetStatus("Heard ACK:" + ackKey + ":CFG — watch " + ackKey + " confirmed a setup.");
      }
    } else {
      gwLinkLog("IN", "ACK:CFG", via);
      gwBroadcastAckNote = "Setup ACK (ACK:CFG, unkeyed broadcast) heard " + fmtCT(nowMs()) + " — an unkeyed watch confirmed its setup.";
      var bt = SexcapadesRuntime.DOM.byId("gwBroadcastTime");
      if (bt) bt.textContent = gwBroadcastAckNote;
      if (gwPendingCfgKey) gwCfgSetStatus("Heard an unkeyed ACK:CFG (broadcast). The keyed ACK:" + gwPendingCfgKey + ":CFG has not arrived yet — still waiting.");
    }
  }
  var gwBroadcastAckNote = "";
  function gwHandlePayload(txt, source, profileId) {
    var raw = String(txt || "").trim();
    if (!raw) return false;
    var ackm = /^ACK:(?:([A-Za-z0-9][A-Za-z0-9_-]{0,31}):)?CFG$/i.exec(raw);
    if (ackm) { gwOnAck(ackm[1] || "", source); return true; }
    var body = raw, key = profileId || "";
    if (!key) {
      var ci = raw.indexOf(":");
      if (ci > 0) {
        var candKey = raw.slice(0, ci), rest = raw.slice(ci + 1), restUp = rest.toUpperCase();
        if (/^[A-Za-z0-9][A-Za-z0-9_-]{0,31}$/.test(candKey) && (GW_SUB[restUp] || gwParseMetric(restUp))) { key = candKey; body = rest; }
      }
    }
    body = String(body || "").trim().toUpperCase();
    if (GW_SUB[body]) { gwOnChirp(body, source, key); return true; }
    var parsed = gwParseMetric(body);
    if (parsed) { gwOnMetric(parsed, body, source, key); return true; }
    return false;
  }
  function gwEntryById(id) {
    for (var i = 0; i < state.journal.length; i++) if (state.journal[i].id === id) return state.journal[i];
    return null;
  }
  function gwRateDom(entry, value) {
    if (!entry) return;
    entry.domEnjoy = value; entry.domAt = nowMs();
    save(); renderJournal();
    if (gwIsMismatch(entry)) vibrate([220, 60, 220, 60, 220]);
  }
  function gwAttachActivity(entry, textValue) {
    if (!entry) return;
    entry.activity = String(textValue || "").trim().slice(0, 120);
    save(); renderJournal();
  }
  function renderJournal() {
    /* sentinel-density-1108-1545: an incoming signal re-renders the journal,
       live view and metrics — capture the sections scroll position and put
       it back afterwards so the view never jumps on a received signal. */
    var secEl = gwSectionsScrollEl(); var secTop = secEl ? secEl.scrollTop : 0;
    var latest = gwLatest();
    if (gwLiveSub) gwLiveSub.textContent = latest ? gwSubMeta(latest).detail : "No taps yet";
    if (gwLiveSubTime) gwLiveSubTime.textContent = latest ? fmtCT(latest.t) + (latest.activity ? " · " + latest.activity : "") : "";
    var domLatest = null;
    for (var i = 0; i < state.journal.length; i++) { if (state.journal[i].domEnjoy !== null && state.journal[i].domEnjoy !== undefined) { domLatest = state.journal[i]; break; } }
    if (gwLiveDom) gwLiveDom.textContent = domLatest ? GW_DOM_LABELS[domLatest.domEnjoy] : "Not rated yet";
    if (gwLiveDomTime) gwLiveDomTime.textContent = domLatest ? fmtCT(domLatest.domAt) + (domLatest.activity ? " · " + domLatest.activity : "") : "";
    [["E", gwMetricE, gwMetricETime], ["H", gwMetricH, gwMetricHTime], ["N", gwMetricN, gwMetricNTime]].forEach(function (cfg) {
      var found = null;
      for (var i = 0; i < state.journal.length; i++) { if (state.journal[i].metric === cfg[0]) { found = state.journal[i]; break; } }
      if (cfg[1]) cfg[1].textContent = found ? gwFmtVal(+found.value || 0) : "—";
      if (cfg[2]) cfg[2].textContent = found ? fmtCT(found.t) : "No reading yet";
    });
    var gwBroadcastLatestEl = SexcapadesRuntime.DOM.byId("gwBroadcastLatest"), gwBroadcastTimeEl = SexcapadesRuntime.DOM.byId("gwBroadcastTime");
    if (gwBroadcastLatestEl) {
      var bFound = null, bCount = 0;
      for (var bi = 0; bi < state.journal.length; bi++) { if (!state.journal[bi].profileId) { bCount++; if (!bFound) bFound = state.journal[bi]; } }
      if (bFound) {
        gwBroadcastLatestEl.textContent = gwIsMetric(bFound) ? (GW_METRICS[bFound.metric].name + " " + gwFmtVal(+bFound.value || 0)) : gwSubMeta(bFound).detail;
        if (gwBroadcastTimeEl) gwBroadcastTimeEl.textContent = fmtCT(bFound.t) + " · " + bCount + " broadcast signal" + (bCount === 1 ? "" : "s") + " this scene — unkeyed, from any watch in the room." + (gwBroadcastAckNote ? " " + gwBroadcastAckNote : "");
      } else {
        gwBroadcastLatestEl.textContent = "No broadcast signals yet";
        if (gwBroadcastTimeEl) gwBroadcastTimeEl.textContent = gwBroadcastAckNote || "Unkeyed signals from any watch in the room land here.";
      }
    }
    var showMismatch = !!(latest && gwIsMismatch(latest));
    if (gwMismatchBanner) gwMismatchBanner.hidden = !showMismatch;
    if (showMismatch && gwMismatchText) gwMismatchText.textContent = "Latest check-in: sub tapped \u201C" + gwSubMeta(latest).label + "\u201D and the Dom rated it \u201C" + GW_DOM_LABELS[latest.domEnjoy] + "\u201D" + (latest.activity ? " during " + latest.activity : "") + ". This activity should stop — check in with each other.";
    var promptEntry = gwPromptEntryId ? gwEntryById(gwPromptEntryId) : latest;
    if (gwPrompt) gwPrompt.hidden = !promptEntry;
    if (gwDomRateBox) gwDomRateBox.hidden = !promptEntry;
    if (promptEntry && gwPromptTitle) gwPromptTitle.textContent = "Dom — what activity is this? (" + gwSubMeta(promptEntry).detail + ", " + fmtCT(promptEntry.t) + ")";
    if (promptEntry && gwActivityInput && document.activeElement !== gwActivityInput) gwActivityInput.value = promptEntry.activity || "";
    if (gwDomRateBox && promptEntry) {
      var btns = gwDomRateBox.querySelectorAll("[data-dom-rate]");
      for (var b = 0; b < btns.length; b++) btns[b].setAttribute("aria-pressed", promptEntry.domEnjoy === +btns[b].getAttribute("data-dom-rate") ? "true" : "false");
    }
    if (!gwAftercareList) { if (secEl && secEl.scrollTop !== secTop) secEl.scrollTop = secTop; return; }
    gwAftercareList.innerHTML = "";
    state.journal.forEach(function (entry) {
      var align = gwAlignment(entry);
      var card = document.createElement("div"); card.className = "gw-entry"; card.setAttribute("data-mismatch", gwIsMismatch(entry) ? "true" : "false");
      var head = document.createElement("div"); head.className = "gw-entry-head";
      var title = document.createElement("span"); title.className = "gw-entry-title"; title.textContent = gwIsMetric(entry) ? (GW_METRICS[entry.metric].name + " " + gwFmtVal(+entry.value || 0)) : (entry.activity ? entry.activity : (entry.sched ? entry.sched + " (scheduled)" : "Activity not named yet"));
      var tm = document.createElement("time"); tm.textContent = fmtCT(entry.t);
      head.appendChild(title); head.appendChild(tm); card.appendChild(head);
      var cols = document.createElement("div"); cols.className = "gw-cols";
      var subCol = document.createElement("div"); subCol.className = "gw-col";
      var subLab = document.createElement("span"); subLab.className = "gw-col-label"; subLab.textContent = "Sub (watch)";
      var subVal = document.createElement("span"); subVal.textContent = gwEntrySubText(entry);
      subCol.appendChild(subLab); subCol.appendChild(subVal);
      if (entry.sched && entry.sched !== entry.activity) { var schedVal = document.createElement("span"); schedVal.textContent = "Scheduled then: " + entry.sched; subCol.appendChild(schedVal); }
      var domCol = document.createElement("div"); domCol.className = "gw-col";
      var domLab = document.createElement("span"); domLab.className = "gw-col-label"; domLab.textContent = "Dom";
      var domVal = document.createElement("span"); domVal.textContent = (entry.domEnjoy === null || entry.domEnjoy === undefined) ? "Not rated yet" : ("Enjoyment: " + GW_DOM_LABELS[entry.domEnjoy]);
      domCol.appendChild(domLab); domCol.appendChild(domVal);
      cols.appendChild(subCol); cols.appendChild(domCol); card.appendChild(cols);
      var badge = document.createElement("span"); badge.className = "gw-badge"; badge.setAttribute("data-tone", align.tone); badge.textContent = align.label;
      card.appendChild(badge);
      var rateRow = document.createElement("div"); rateRow.className = "gw-rate-row";
      GW_DOM_LABELS.forEach(function (lab, val) {
        var rb = document.createElement("button"); rb.type = "button"; rb.className = "action-btn gw-rate-btn";
        rb.textContent = lab; rb.setAttribute("data-gw-rate-entry", entry.id); rb.setAttribute("data-dom-rate", String(val));
        rb.setAttribute("aria-pressed", entry.domEnjoy === val ? "true" : "false");
        rateRow.appendChild(rb);
      });
      card.appendChild(rateRow);
      gwAftercareList.appendChild(card);
    });
    if (gwJournalEmpty) gwJournalEmpty.hidden = state.journal.length > 0;
    if (secEl && secEl.scrollTop !== secTop) secEl.scrollTop = secTop;
  }
  if (gwDomRateBox) gwDomRateBox.addEventListener("click", function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest("[data-dom-rate]") : null; if (!t) return;
    var entry = gwPromptEntryId ? gwEntryById(gwPromptEntryId) : gwLatest();
    gwRateDom(entry, +t.getAttribute("data-dom-rate"));
  });
  if (gwAftercareList) gwAftercareList.addEventListener("click", function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest("[data-gw-rate-entry]") : null; if (!t) return;
    gwRateDom(gwEntryById(t.getAttribute("data-gw-rate-entry")), +t.getAttribute("data-dom-rate"));
  });
  if (gwActivitySave) gwActivitySave.addEventListener("click", function () {
    var entry = gwPromptEntryId ? gwEntryById(gwPromptEntryId) : gwLatest();
    if (entry && gwActivityInput) { gwAttachActivity(entry, gwActivityInput.value); if (gwSpeechStatus) gwSpeechStatus.textContent = "Activity attached: " + (entry.activity || "(blank)"); }
  });
  /* Speech (Way A): Web Speech API; audio goes to Google, nothing is stored. */
  var gwRecognition = null;
  if (gwSpeakBtn) gwSpeakBtn.addEventListener("click", function () {
    var optIn = SexcapadesRuntime.DOM.byId("gwSpeechOptIn");
    if (!optIn || !optIn.checked) { if (gwSpeechStatus) gwSpeechStatus.textContent = "Speech is off until you tick \u201CSend my voice to Google for transcription\u201D above — your voice goes to Google only after that opt-in. Typing the activity always stays on this device."; if (gwActivityInput) gwActivityInput.focus(); return; }
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { if (gwSpeechStatus) gwSpeechStatus.textContent = "Speech recognition is not available in this browser — type the activity instead. Nothing is recorded either way."; if (gwActivityInput) gwActivityInput.focus(); return; }
    try {
      if (gwRecognition) { try { gwRecognition.stop(); } catch (e) {} }
      gwRecognition = new SR();
      gwRecognition.lang = "en-US"; gwRecognition.interimResults = false; gwRecognition.maxAlternatives = 1;
      gwRecognition.onresult = function (ev) {
        var txt = ev.results && ev.results[0] && ev.results[0][0] ? ev.results[0][0].transcript : "";
        var entry = gwPromptEntryId ? gwEntryById(gwPromptEntryId) : gwLatest();
        if (entry && txt) { gwAttachActivity(entry, txt); if (gwActivityInput) gwActivityInput.value = entry.activity; if (gwSpeechStatus) gwSpeechStatus.textContent = "Heard: \u201C" + entry.activity + "\u201D — attached to this check-in."; }
      };
      gwRecognition.onerror = function (ev) { if (gwSpeechStatus) gwSpeechStatus.textContent = "Speech did not come through (" + (ev.error || "error") + ") — type the activity instead."; };
      gwRecognition.onend = function () { gwRecognition = null; };
      gwRecognition.start();
      if (gwSpeechStatus) gwSpeechStatus.textContent = "Listening — Dom, say the activity now. (Audio goes to Google for transcription; it is not stored.)";
    } catch (e) { __sxErrLog("gw-speech", e); if (gwSpeechStatus) gwSpeechStatus.textContent = "Speech could not start — type the activity instead."; }
  });
  var gwExportBtn = SexcapadesRuntime.DOM.byId("gwExportBtn"), gwClearBtn = SexcapadesRuntime.DOM.byId("gwClearBtn");
  if (gwExportBtn) gwExportBtn.addEventListener("click", function () {
    var lines = ["Scene Sentinel — scene journal (times in Central)", ""];
    if (state.guide && state.guide.steps && state.guide.steps.length) { lines.push("PLAY GUIDE (Way B) — scheduled steps:"); state.guide.steps.forEach(function (st) { lines.push(guideFmtClock(st.start) + "-" + guideFmtClock(st.end) + " | " + st.activity + (st.note ? " — " + st.note : "")); }); lines.push(""); }
    state.journal.slice().reverse().forEach(function (entry) {
      var align = gwAlignment(entry);
      lines.push(fmtCT(entry.t) + " | Sub: " + gwEntrySubText(entry) + " | Activity: " + (entry.activity || "(not named)") + (entry.sched ? " | Scheduled: " + entry.sched : "") + " | Dom: " + ((entry.domEnjoy === null || entry.domEnjoy === undefined) ? "not rated" : GW_DOM_LABELS[entry.domEnjoy]) + " | " + align.label);
    });
    if (!state.journal.length) lines.push("No check-ins recorded.");
    try {
      var blob = new Blob([lines.join("\n")], { type: "text/plain" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a"); a.href = url; a.download = "scene-journal.txt";
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
    } catch (e) { __sxErrLog("gw-export", e); }
  });
  if (gwClearBtn) gwClearBtn.addEventListener("click", function () {
    state.journal = []; gwPromptEntryId = null; save(); renderJournal();
    if (gwSpeechStatus) gwSpeechStatus.textContent = "";
  });
  /* Microphone listener: getUserMedia + ggwave-wasm decode (p=4).
     Mic samples stream into ggwave.decode(); a returned payload of TAP,
     DBL or HLD is a check-in. Mic audio is analysed on-device and never
     stored or sent anywhere. */
  var gwAudio = { stream: null, ctx: null, processor: null, on: false };
  var gwLib = null, gwInstance = null, gwLibPromise = null;
  function gwSetStatus(msg) { if (gwListenStatus) gwListenStatus.textContent = msg; }
  function gwEnsureDecoder(sampleRate) {
    if (gwInstance && gwLib) return Promise.resolve(true);
    if (!gwLibPromise) {
      gwLibPromise = new Promise(function (resolve) {
        if (typeof window.ggwave_factory !== "function") { try { gwTxDiag = "ggwave factory missing"; } catch (e) {} resolve(false); return; }
        window.ggwave_factory().then(function (lib) {
          try {
            if (lib.disableLog) lib.disableLog();
            gwLib = lib;
            resolve(true);
          } catch (e) { __sxErrLog("gw-init", e); resolve(false); }
        }).catch(function (e) { __sxErrLog("gw-init", e); resolve(false); });
      });
    }
    return gwLibPromise.then(function (ok) {
      if (!ok || !gwLib) return false;
      try {
        if (gwInstance) { try { gwLib.free(gwInstance); } catch (e) {} gwInstance = null; }
        var params = gwLib.getDefaultParameters();
        params.sampleRateInp = sampleRate;
        params.sampleRateOut = sampleRate;
        gwInstance = gwLib.init(params);
        return !!gwInstance || gwInstance === 0;
      } catch (e) { __sxErrLog("gw-init", e); return false; }
    });
  }
  var gwTransientListen = false;
  function gwStopListening(reason, force) {
    if (!force && gwTransientListen === false && guidePlay.on) return;
    gwTransientListen = false;
    gwAudio.on = false;
    if (gwAudio.processor) { try { gwAudio.processor.disconnect(); } catch (e) {} gwAudio.processor.onaudioprocess = null; gwAudio.processor = null; }
    if (gwAudio.stream) { try { gwAudio.stream.getTracks().forEach(function (tr) { try { tr.stop(); } catch (e) {} }); } catch (e) {} gwAudio.stream = null; }
    if (gwAudio.ctx) { try { gwAudio.ctx.close(); } catch (e) {} gwAudio.ctx = null; }
    if (gwLib && gwInstance !== null && gwInstance !== undefined) { try { gwLib.free(gwInstance); } catch (e) {} gwInstance = null; }
    if (gwListenBtn) gwListenBtn.textContent = "Start listening";
    if (reason) gwSetStatus(reason);
  }
  function gwStartListening(transientMode) {
    if (gwAudio.on) return Promise.resolve(true);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      gwSetStatus("This browser cannot open the microphone here, so the listener cannot run.");
      return Promise.resolve(false);
    }
    if (transientMode) gwTransientListen = true;
    gwSetStatus("Opening the microphone and loading the ggwave decoder\u2026");
    return navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } }).then(function (stream) {
      var AC = window.AudioContext || window.webkitAudioContext;
      var ctx = new AC();
      return gwEnsureDecoder(ctx.sampleRate).then(function (ok) {
        if (!ok) {
          try { stream.getTracks().forEach(function (tr) { try { tr.stop(); } catch (e) {} }); } catch (e) {}
          try { ctx.close(); } catch (e) {}
          gwSetStatus("The ggwave decoder could not load on this device, so the listener cannot run.");
          return false;
        }
        try {
          var src = ctx.createMediaStreamSource(stream);
          var proc = ctx.createScriptProcessor(4096, 1, 1);
          var mute = ctx.createGain(); mute.gain.value = 0;
          proc.onaudioprocess = function (ev) {
            if (!gwAudio.on || !gwLib || gwInstance === null || gwInstance === undefined) return;
            try {
              var input = ev.inputBuffer.getChannelData(0);
              var copy = new Float32Array(input.length); copy.set(input);
              var bytes = new Int8Array(copy.buffer, 0, copy.length * 4);
              var res = gwLib.decode(gwInstance, bytes);
              if (res && res.length) {
                var txt = "";
                for (var i = 0; i < res.length; i++) txt += String.fromCharCode(res[i]);
                txt = txt.trim();
                gwHandlePayload(txt, "watch");
              }
            } catch (e) { __sxErrLog("gw-decode", e); }
          };
          src.connect(proc); proc.connect(mute); mute.connect(ctx.destination);
          gwAudio.stream = stream; gwAudio.ctx = ctx; gwAudio.processor = proc; gwAudio.on = true;
          if (gwListenBtn) gwListenBtn.textContent = "Stop listening";
          gwSetStatus("Listening now — the ggwave decoder is live. Tap, double-tap, or hold on the watch and each decoded chirp lands in the journal with its time.");
          if (gwDecodeStatus) gwDecodeStatus.textContent = "Decoder live: ggwave-wasm, protocol p=4 (ultrasound fast) — only decoded TAP / DBL / HLD and metric (E / H / N, -100 to +100, shown as-is) payloads are logged. Mic audio is decoded on-device and never stored or sent anywhere; speech transcription leaves the device to Google only if you opt in for it in the Dom prompt.";
          return true;
        } catch (e) {
          __sxErrLog("gw-listen", e);
          gwStopListening("Microphone opened but the decoder could not start in this browser.", true);
          return false;
        }
      });
    }).catch(function (e) {
      __sxErrLog("gw-mic", e);
      gwSetStatus("Microphone permission was not granted, so the listener cannot hear the watch. Allow microphone access and try again.");
      return false;
    });
  }
  if (gwListenBtn) gwListenBtn.addEventListener("click", function () {
    if (gwAudio.on) {
      gwTransientListen = false;
      gwStopListening("Listener stopped. Chirps are only logged while listening.", true);
      return;
    }
    gwTransientListen = false;
    gwStartListening(false);
  });


  /* ---------------- GibberLink Bluetooth (BLE) transport (ble-1106-1405) ----------------
     A second transport alongside the acoustic GGWave chirps, carrying the
     SAME messages: check-in pulses out ("CHK"), TAP / DBL / HLD and
     E / H / N metric values in, attributed by the sender's short profile
     ID. The user never chooses a transport: where Web Bluetooth exists
     (Chrome on Android) BLE is used once connected, and GGWave stays the
     automatic fallback — and stays live as backup — whenever BLE is
     unavailable (iOS Safari has no Web Bluetooth), permission is denied,
     no device is picked, or the link drops and cannot be re-made.

     === GIBBERLINK BLE SPEC — THE WATCH APP MUST USE THIS SERVICE UUID ===
       Service UUID:  0000FFF0-0000-1000-8000-00805F9B34FB
         (gibberlink-1108-1400: replaces the old 7a1e5b90… service —
         Jason's ruling, following Gemini's spec v1.0. Under the FFF0
         service the phone picks the write characteristic and the
         notify characteristic by property, so their UUIDs are the
         watch app's own choice.)
     The watch advertises the service under a generic name (e.g.
     "GibberLink") — no kink wording anywhere on the watch side.
     Payloads are short UTF-8 text, opaque bytes to the watch:
       watch -> phone: "<key>:TAP" | "<key>:DBL" | "<key>:HLD" |
         "<key>:E<value>" | "<key>:H<value>" | "<key>:N<value>" |
         "ACK:<key>:CFG" — <key> is the sender's profile key (e.g.
         adam); metric values are the watch's display values, -100 to
         +100, sent as-is. A payload with NO key is broadcast (all
         watches) and is never dropped.
       phone -> watch: "CFG:<key>:<timer>" (setup), "CHK:<key>:P" /
         "CHK:<key>:T" (targeted check-in), "CHK:ALL:P" / "CHK:ALL:T"
         (broadcast check-in, explicit ALL signifier), "HEAT:<key>:<value>"
         (heat copied on sync), "CHK" for each play-guide check-in pulse.
         Incoming unkeyed messages are still accepted as broadcast.
     No pairing ceremony: plain Just Works / unencrypted GATT. The
     payloads are meaningless without the profile this phone holds.
     Web Bluetooth needs a user gesture to ask for a device, so the
     connect button below is that gesture; after the first grant, Chrome
     may hand the device back via navigator.bluetooth.getDevices() and
     the link re-forms on its own while a scene is active. On any drop,
     reconnect is attempted automatically while the user still wants the
     link (they have not pressed Disconnect). */
  var GIBBERLINK_SERVICE_UUID = "0000fff0-0000-1000-8000-00805f9b34fb";
  var gwBleBtn = SexcapadesRuntime.DOM.byId("gwBleToggle"),
      gwBleStatus = SexcapadesRuntime.DOM.byId("gwBleStatus");
  var ble = { device: null, txChar: null, rxChar: null, on: false, want: false, busy: false, attempts: 0, timer: null };
  function bleSupported() {
    try { return !!(navigator && navigator.bluetooth && typeof navigator.bluetooth.requestDevice === "function"); }
    catch (e) { return false; }
  }
  function bleSetStatus(msg) { if (gwBleStatus) gwBleStatus.textContent = msg; }
  function bleSceneActive() {
    return !!((safetyDlg && safetyDlg.open) || guidePlay.on || gwAudio.on);
  }
  function bleUpdateBtn() {
    if (!gwBleBtn) return;
    if (!bleSupported()) { gwBleBtn.disabled = true; gwBleBtn.textContent = "Bluetooth unavailable here"; return; }
    gwBleBtn.disabled = ble.busy;
    gwBleBtn.textContent = ble.on ? "Disconnect Bluetooth watch" : "Connect watch over Bluetooth";
  }
  function bleOnNotify(ev) {
    try {
      var v = ev && ev.target ? ev.target.value : null; if (!v) return;
      var txt = "";
      for (var i = 0; i < v.byteLength; i++) txt += String.fromCharCode(v.getUint8(i));
      txt = txt.trim();
      if (txt) gwHandlePayload(txt, "ble");
    } catch (e) { __sxErrLog("ble-notify", e); }
  }
  function bleAttach(device) {
    ble.busy = true; bleUpdateBtn();
    return device.gatt.connect().then(function (server) {
      return server.getPrimaryService(GIBBERLINK_SERVICE_UUID);
    }).then(function (svc) {
      return svc.getCharacteristics();
    }).then(function (allChars) {
      var tx = null, rx = null;
      (allChars || []).forEach(function (ch) {
        var pr = ch.properties || {};
        if (!tx && (pr.write || pr.writeWithoutResponse)) tx = ch;
        if (!rx && pr.notify) rx = ch;
      });
      if (!tx || !rx) throw new Error("GibberLink characteristics not found");
      return [tx, rx];
    }).then(function (chars) {
      ble.txChar = chars[0]; ble.rxChar = chars[1];
      return ble.rxChar.startNotifications().then(function () {
        ble.rxChar.addEventListener("characteristicvaluechanged", bleOnNotify);
        ble.on = true; ble.busy = false; ble.attempts = 0;
        bleSetStatus("Watch link: Bluetooth connected to " + (device.name || "the GibberWear watch") + " — taps and metrics arrive over BLE, check-in pulses go out over BLE, and GGWave chirps stay live as backup.");
        bleUpdateBtn();
        return true;
      });
    }).catch(function (e) {
      __sxErrLog("ble-connect", e);
      ble.busy = false; ble.on = false; ble.txChar = null; ble.rxChar = null;
      bleUpdateBtn();
      return false;
    });
  }
  function bleScheduleReconnect() {
    if (!ble.want || ble.on || ble.busy || ble.timer) return;
    ble.attempts++;
    var delay = Math.min(3000 * ble.attempts, 15000);
    bleSetStatus("Watch link: Bluetooth dropped — reconnecting in " + Math.round(delay / 1000) + "s (attempt " + ble.attempts + "). GGWave chirps carry the scene meanwhile.");
    ble.timer = setTimeout(function () {
      ble.timer = null;
      if (!ble.want || ble.on || !ble.device) return;
      bleAttach(ble.device).then(function (ok) { if (!ok) bleScheduleReconnect(); });
    }, delay);
  }
  function bleOnDisconnect() {
    ble.on = false; ble.txChar = null; ble.rxChar = null;
    bleUpdateBtn();
    if (ble.want) bleScheduleReconnect();
    else bleSetStatus("Watch link: Bluetooth disconnected — GGWave chirps are the active transport.");
  }
  function bleWireDevice(device) {
    ble.device = device;
    device.addEventListener("gattserverdisconnected", bleOnDisconnect);
  }
  function bleForgetWiring() {
    if (ble.timer) { clearTimeout(ble.timer); ble.timer = null; }
    if (ble.device) { try { ble.device.removeEventListener("gattserverdisconnected", bleOnDisconnect); } catch (e) {} }
  }
  /* Outbound pulse path: resolves true only when the write actually
     completed, null when BLE is not connected (nothing claimed), false
     when a connected write failed. guideFirePulse reports exactly this. */
  function bleSendText(text) {
    if (!ble.on || !ble.txChar) return Promise.resolve(null);
    try {
      var bytes = new TextEncoder().encode(String(text));
      var write = typeof ble.txChar.writeValueWithResponse === "function"
        ? ble.txChar.writeValueWithResponse(bytes)
        : ble.txChar.writeValue(bytes);
      return Promise.resolve(write).then(function () { return true; }).catch(function (e) { __sxErrLog("ble-write", e); return false; });
    } catch (e) { __sxErrLog("ble-write", e); return Promise.resolve(false); }
  }
  function bleMaybeReconnect() {
    /* Silent re-entry while a scene is active: if Chrome still holds a
       permission grant for the watch (getDevices), reconnect without a
       chooser. No grant or no API: nothing happens — the connect button
       (a user gesture) is the way in, exactly as Web Bluetooth requires. */
    if (!bleSupported() || ble.on || ble.busy || !ble.want) return;
    if (!bleSceneActive()) return;
    try {
      if (typeof navigator.bluetooth.getDevices !== "function") return;
      navigator.bluetooth.getDevices().then(function (devices) {
        if (!devices || !devices.length || ble.on || ble.busy) return;
        var dev = ble.device || devices[0];
        if (!ble.device) bleWireDevice(dev);
        bleAttach(dev).then(function (ok) { if (!ok) bleScheduleReconnect(); });
      }).catch(function (e) { __sxErrLog("ble-getdevices", e); });
    } catch (e) { __sxErrLog("ble-getdevices", e); }
  }
  if (gwBleBtn) gwBleBtn.addEventListener("click", function () {
    if (!bleSupported()) {
      bleSetStatus("Watch link: Bluetooth is not available in this browser (iPhone Safari has no Web Bluetooth) — GGWave chirps are the transport, no action needed.");
      return;
    }
    if (ble.on) {
      ble.want = false; bleForgetWiring();
      try { if (ble.device && ble.device.gatt && ble.device.gatt.connected) ble.device.gatt.disconnect(); } catch (e) { __sxErrLog("ble-disconnect", e); }
      ble.on = false; ble.txChar = null; ble.rxChar = null; ble.device = null;
      bleSetStatus("Watch link: Bluetooth disconnected — GGWave chirps are the active transport.");
      bleUpdateBtn();
      return;
    }
    ble.want = true;
    bleSetStatus("Watch link: pick the GibberWear watch in the Bluetooth chooser…");
    navigator.bluetooth.requestDevice({ filters: [{ services: [GIBBERLINK_SERVICE_UUID] }] }).then(function (device) {
      bleWireDevice(device);
      return bleAttach(device);
    }).then(function (ok) {
      if (ok === false) {
        ble.want = false;
        bleSetStatus("Watch link: the watch was picked but the GibberLink service did not answer — staying on GGWave chirps. Check the watch app is advertising the GibberLink service, then try Connect again.");
      }
    }).catch(function (e) {
      /* NotFoundError = chooser closed / no device picked; anything else
         (SecurityError, permission) lands here too. Either way the
         fallback is automatic: GGWave carries the scene, nothing to fix. */
      __sxErrLog("ble-request", e);
      ble.want = false;
      bleSetStatus("Watch link: no Bluetooth watch connected (" + (e && e.name ? e.name : "unavailable") + ") — GGWave chirps are the transport, no action needed.");
      bleUpdateBtn();
    });
  });
  if (!bleSupported()) {
    bleSetStatus("Watch link: Bluetooth is not available in this browser (iPhone Safari has no Web Bluetooth) — GGWave chirps are the transport, no action needed.");
  } else {
    bleSetStatus("Watch link: Bluetooth available but not connected — tap Connect to pair the watch for this scene; until then GGWave chirps are the transport.");
  }
  bleUpdateBtn();

  /* ---------------- GibberLink setup + check-in sender (gibberlink-1108-1400) ----------------
     The phone side of the GibberLink spec as ruled by Jason: the profile
     KEY is the identifier (no provisioned numeric UID; the display name
     is the key for now). Setup sends CFG:<key>:<timer> over ultrasound
     and BLE and waits for the watch's ACK:<key>:CFG (see gwOnAck).
     Check-ins send CHK:<key>:<P|T> to one watch, or CHK:ALL:<P|T> as
     a broadcast every watch answers (explicit ALL signifier on send;
     incoming unkeyed messages still count as broadcast, so older
     unkeyed watches keep working). The same
     setup send is offered from the heat slider for a saved profile
     (a shortcut for those in the know); Scene Sentinel stays its home. */
  var gwCfgKeyEl = SexcapadesRuntime.DOM.byId("gwCfgKey"), gwCfgTimerEl = SexcapadesRuntime.DOM.byId("gwCfgTimer"),
      gwCfgSendBtn = SexcapadesRuntime.DOM.byId("gwCfgSend"), gwCfgStatusEl = SexcapadesRuntime.DOM.byId("gwCfgStatus"),
      gwChkTargetEl = SexcapadesRuntime.DOM.byId("gwChkTarget"), gwChkTypeEl = SexcapadesRuntime.DOM.byId("gwChkType"),
      gwChkSendBtn = SexcapadesRuntime.DOM.byId("gwChkSend"), gwChkStatusEl = SexcapadesRuntime.DOM.byId("gwChkStatus"),
      gwLinkLogEl = SexcapadesRuntime.DOM.byId("gwLinkLog"), gwLinkLogEmptyEl = SexcapadesRuntime.DOM.byId("gwLinkLogEmpty");
  var gwHeatStatusEl = null;
  function gwCfgSetStatus(msg) { if (gwCfgStatusEl) gwCfgStatusEl.textContent = msg; if (gwHeatStatusEl) gwHeatStatusEl.textContent = msg; }
  function gwChkSetStatus(msg) { if (gwChkStatusEl) gwChkStatusEl.textContent = msg; }
  function gwSectionsScrollEl() { try { return document.querySelector("#safetyDialog .safety-sections"); } catch (e) { return null; } }
  function gwLinkLog(dir, payload, via) {
    if (!gwLinkLogEl) return;
    /* sentinel-density-1108-1545: appending to the log must never move the
       dialog's scroll position — only the user's own scrolling does. */
    var sec = gwSectionsScrollEl(); var secTop = sec ? sec.scrollTop : 0;
    var li = document.createElement("li");
    li.textContent = dir + " " + payload + " · " + fmtCT(nowMs()) + (via ? " · " + via : "");
    gwLinkLogEl.insertBefore(li, gwLinkLogEl.firstChild);
    while (gwLinkLogEl.children.length > 50) gwLinkLogEl.removeChild(gwLinkLogEl.lastChild);
    if (gwLinkLogEmptyEl) gwLinkLogEmptyEl.hidden = true;
    if (sec && sec.scrollTop !== secTop) sec.scrollTop = secTop;
  }
  function gwValidKey(k) { return /^[A-Za-z0-9][A-Za-z0-9_-]{0,31}$/.test(String(k || "")); }
  /* bigbuild-1108-1615 key-name fix: the watch identifier IS the profile
     key (adam, eve) — never the internal "profile-<key>-<surname>" slug.
     Any id or typed value is reduced to the key before it is displayed
     or sent: "profile-eve-vale" -> "eve". */
  function gwKeyFromId(id) {
    var s = String(id || "").trim();
    if (!s) return "";
    var m = /^profile-([A-Za-z0-9]+)(?:-|$)/i.exec(s);
    if (m) return m[1].toLowerCase();
    return s;
  }
  function gwKeyLabel(key) { return key ? key.charAt(0).toUpperCase() + key.slice(1) : key; }
  function gwEnsureChkOption(key) {
    key = gwKeyFromId(key);
    if (!gwChkTargetEl || !gwValidKey(key)) return;
    for (var i = 0; i < gwChkTargetEl.options.length; i++) { if (gwChkTargetEl.options[i].value === key) return; }
    var opt = document.createElement("option"); opt.value = key; opt.textContent = gwKeyLabel(key);
    gwChkTargetEl.appendChild(opt);
  }
  function gwPopulateChkTargets() {
    try { var api = window.Sexcapades2xProfiles; if (api && typeof api.getIds === "function") api.getIds().forEach(function (id) { gwEnsureChkOption(id); }); } catch (e) { __sxErrLog("gw-targets", e); }
    if (gwCfgKeyEl) gwEnsureChkOption(gwCfgKeyEl.value.trim());
  }
  function gwSendBoth(payload) {
    return Promise.all([gwSendPayload(payload), bleSendText(payload)]).then(function (r) { return { chirp: !!r[0], ble: r[1] }; });
  }
  function gwSendCfg(key, timer, heatStatusEl, heatValue) {
    key = gwKeyFromId(key);
    if (!gwValidKey(key)) { gwCfgSetStatus("Enter the watch's profile key first — the short key from the profile (e.g. adam, eve). Letters and digits, no spaces."); return; }
    timer = parseInt(timer, 10); if (isNaN(timer) || timer < 0) timer = 0;
    var payload = "CFG:" + key + ":" + timer;
    gwHeatStatusEl = heatStatusEl || null;
    gwPendingCfgKey = key;
    gwPendingHeatValue = (typeof heatValue === "number" && isFinite(heatValue)) ? heatValue : null;
    if (gwPendingCfgTimer) { try { SexcapadesRuntime.TimerManager.clear(gwPendingCfgTimer); } catch (e) {} gwPendingCfgTimer = null; }

    /* Transmit outgoing CFG first; do NOT arm mic until outgoing sound finishes to avoid acoustic collision */
    gwSendBoth(payload).then(function (res) {
      var via = res.ble === true ? "Bluetooth" : "ultrasound";
      gwLinkLog("OUT", payload, via);
      var msg = "Setup sent (" + payload + ") on " + via + ". Waiting for ACK:" + key + ":CFG…";
      if (!res.chirp && res.ble !== true) msg += " The chirp could not be encoded on this device (" + (gwTxDiag || "unknown reason") + "), so the watch may not have heard it — start the listener or connect Bluetooth, then send again.";
      gwCfgSetStatus(msg);

      /* Arm microphone listener after playback finishes (with a brief 50ms guard) */
      if (!gwAudio.on && (!ble.on || !ble.rxChar)) {
        setTimeout(function () {
          if (gwPendingCfgKey === key) gwStartListening(true);
        }, 50);
      }
    });

    gwPendingCfgTimer = SexcapadesRuntime.TimerManager.setTimeout(function () {
      if (gwPendingCfgKey === key) {
        gwPendingCfgKey = "";
        gwPendingHeatValue = null;
        gwCfgSetStatus("Watch " + key + " didn't acknowledge — check that GibberWear is open, listening, and nearby.");
        if (gwTransientListen) gwStopListening("", true);
      }
    }, 4500);
  }
  if (gwCfgSendBtn) gwCfgSendBtn.addEventListener("click", function () {
    gwSendCfg(gwCfgKeyEl ? gwCfgKeyEl.value : "", gwCfgTimerEl ? gwCfgTimerEl.value : 0, null);
  });
  if (gwCfgKeyEl) gwCfgKeyEl.addEventListener("input", function () { gwEnsureChkOption(gwCfgKeyEl.value.trim()); });
  if (gwChkSendBtn) gwChkSendBtn.addEventListener("click", function () {
    var target = gwKeyFromId(gwChkTargetEl ? gwChkTargetEl.value : "");
    var type = gwChkTypeEl ? gwChkTypeEl.value : "P"; if (type !== "T") type = "P";
    /* bigbuild-1108-1615: broadcast sends carry the explicit ALL signifier
       (CHK:ALL:P / CHK:ALL:T); targeted sends use the key only. Incoming
       unkeyed messages are still treated as broadcast (see gwHandlePayload). */
    var payload = target ? "CHK:" + target + ":" + type : "CHK:ALL:" + type;
    gwSendBoth(payload).then(function (res) {
      gwLinkLog("OUT", payload, res.ble === true ? "Bluetooth" : "ultrasound");
      if (target) gwChkSetStatus("Check-in sent: " + payload + " — only watch " + target + " should answer");
      else gwChkSetStatus("Check-in sent: " + payload + " — broadcast to ALL watches, so every watch in the room should answer.");
    });
  });
  gwPopulateChkTargets();

  /* Heat-slider setup offer (gibberlink-1108-1400): the same CFG send,
     offered inside the heat popover for the profile whose heat is being
     set — but ONLY for a saved profile. The guard: the tab's profile key
     must resolve in the profile store AND be a sample profile, a
     remembered (saved-on-device) profile, or a profile with no unsaved
     changes, and its name must not be the unsaved "New profile" draft.
     When the guard fails the offer stays hidden and nothing is sent. */
  var gwHeatLastKey = "";
  function gwHeatResolveKey() {
    var k = gwHeatLastKey;
    if (!k || !gwValidKey(k)) return "";
    var rawId = k;
    try {
      var api = window.Sexcapades2xProfiles;
      if (!api || typeof api.has !== "function" || !api.has(k)) return "";
      var nm = SexcapadesRuntime.DOM.byId("heatProfileName");
      if (nm && nm.textContent.trim() === "New profile") return "";
      var saved = false;
      if (typeof api.isSample === "function" && api.isSample(k)) saved = true;
      if (!saved && typeof api.isDirty === "function" && !api.isDirty(k)) saved = true;
      if (!saved) { try { var stored = JSON.parse(window.localStorage.getItem("sexcapades_2x_remembered_profiles") || "{}"); if (stored && stored.profiles && stored.profiles[k]) saved = true; } catch (e) {} }
      return saved ? gwKeyFromId(rawId) : "";
    } catch (e) { __sxErrLog("heat-watch-guard", e); return ""; }
  }
  function gwHeatSyncOffer() {
    var offer = SexcapadesRuntime.DOM.byId("heatWatchOffer"); if (!offer) return;
    var pop = SexcapadesRuntime.DOM.byId("heatPopover");
    if (!pop || pop.hidden) { offer.hidden = true; return; }
    var k = gwHeatResolveKey();
    offer.hidden = !k;
    if (k) { var kel = SexcapadesRuntime.DOM.byId("heatWatchKey"); if (kel) kel.textContent = gwKeyLabel(k); offer.setAttribute("data-watch-key", k); }
  }
  document.addEventListener("click", function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest("[data-profile-heat]") : null;
    if (t) { gwHeatLastKey = t.getAttribute("data-profile-heat") || ""; try { SexcapadesRuntime.TimerManager.setTimeout(gwHeatSyncOffer, 80); } catch (e) {} }
  }, true);
  var gwHeatPopEl = SexcapadesRuntime.DOM.byId("heatPopover");
  if (gwHeatPopEl && typeof window.MutationObserver === "function") { try { new MutationObserver(function () { gwHeatSyncOffer(); }).observe(gwHeatPopEl, { attributes: true, attributeFilter: ["hidden"] }); } catch (e) { __sxErrLog("heat-watch-observe", e); } }
  var gwHeatSetupBtn = SexcapadesRuntime.DOM.byId("heatWatchSetupBtn");
  if (gwHeatSetupBtn) gwHeatSetupBtn.addEventListener("click", function () {
    var offer = SexcapadesRuntime.DOM.byId("heatWatchOffer");
    var k = offer ? (offer.getAttribute("data-watch-key") || "") : "";
    if (!k) return;
    if (gwCfgKeyEl) gwCfgKeyEl.value = k;
    /* bigbuild-1108-1615 heat-copying: the sync sends the profile's current
       Heat (the slider's live value for this profile) with the setup. */
    var heatEl = SexcapadesRuntime.DOM.byId("heatSlider");
    var heatVal = heatEl ? Number(heatEl.value) : NaN;
    gwSendCfg(k, gwCfgTimerEl ? gwCfgTimerEl.value : 300, SexcapadesRuntime.DOM.byId("heatWatchStatus"), isFinite(heatVal) ? heatVal : null);
  });

  /* ---------------- Play guide Way B: paste-back, Dom playback, GibberLink check-in pulse (guide-1106-0847) ----------------
     The Scene Setter play-guide prompt now requires ONE structured format
     from every AI (see STRUCTURED PLAY GUIDE FORMAT in the Setter prompt):
       [MM:SS-MM:SS] Activity name — guidance for the Dom
     Time codes are elapsed time from scene start (MM:SS or H:MM:SS).
     Activity names come from the fixed set the Setter prompt lists, so
     this parser reads any AI's guide the same way. Queueing a guide builds
     the step timers; while playback runs, the APP holds the clock and
     fires the check-in pulse — the watch is never asked to run a timer
     over GibberLink. Each pulse tries a real GGWave transmit of "CHK"
     (p=4, the same protocol the listener decodes) and always also pulses
     on this device (vibrate + tone + panel flash), and every watch tap or
     metric that lands is stamped with the step scheduled at that moment
     (entry.sched), which is how the journal fills in what was supposed to
     be happening. Playback state is session-only; the queued guide itself
     is saved with the rest of Sentinel's local state. */
  var GUIDE_ACTIVITIES = ["Warm-up","Negotiation check","Bondage","Impact play","Sensation play","Teasing & denial","Oral","Manual stimulation","Penetrative sex","Orgasm control","Roleplay","Service","Worship","Free play","Aftercare","Other"];
  function guideParseClock(tok) {
    var parts = String(tok || "").trim().split(":");
    if (parts.length < 2 || parts.length > 3) return null;
    var nums = [];
    for (var i = 0; i < parts.length; i++) { if (!/^\d{1,3}$/.test(parts[i])) return null; nums.push(parseInt(parts[i], 10)); }
    if (nums.length === 2) return nums[0] * 60 + nums[1];
    return nums[0] * 3600 + nums[1] * 60 + nums[2];
  }
  function guideFmtClock(sec) {
    sec = Math.max(0, Math.round(sec));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), r = sec % 60;
    var mm = (h > 0 && m < 10) ? "0" + m : String(m), ss = r < 10 ? "0" + r : String(r);
    return (h > 0 ? h + ":" : "") + mm + ":" + ss;
  }
  function parsePlayGuide(text) {
    var steps = [], skipped = 0, pulseMin = null;
    String(text || "").split(/\r?\n/).forEach(function (raw) {
      var line = raw.trim();
      if (!line) return;
      var cm = /^CHECK-IN\s+EVERY:\s*(\d{1,2})\s*MIN/i.exec(line);
      if (cm) { var pv = parseInt(cm[1], 10); if (pv >= 1 && pv <= 15) pulseMin = pv; return; }
      var m = /^\[?\s*(?:T\s*\+?\s*)?(\d{1,3}:\d{2}(?::\d{2})?)(?:\s*(?:[-–—]|to)\s*(\d{1,3}:\d{2}(?::\d{2})?))?\s*\]?\s*[:\-–—]?\s*(.+)$/i.exec(line);
      if (!m) { skipped++; return; }
      var start = guideParseClock(m[1]), end = m[2] ? guideParseClock(m[2]) : null;
      if (start === null) { skipped++; return; }
      var rest = m[3].trim();
      var activity = rest, note = "";
      var dash = rest.indexOf(" — ");
      if (dash < 0) dash = rest.indexOf(" - ");
      if (dash > 0) { activity = rest.slice(0, dash).trim(); note = rest.slice(dash + 3).trim(); }
      else { var pipe = rest.indexOf("|"); if (pipe > 0) { activity = rest.slice(0, pipe).trim(); note = rest.slice(pipe + 1).trim(); } }
      if (!activity) { skipped++; return; }
      if (end !== null && end <= start) end = null;
      steps.push({ start: start, end: end, activity: activity.slice(0, 80), note: note.slice(0, 300) });
    });
    steps.sort(function (a, b) { return a.start - b.start; });
    for (var i = 0; i < steps.length; i++) { if (steps[i].end === null) steps[i].end = (i + 1 < steps.length) ? steps[i + 1].start : steps[i].start + 300; }
    return { steps: steps, skipped: skipped, pulseMin: pulseMin };
  }
  window.__sxParsePlayGuide = parsePlayGuide;
  var gwGuideInput = SexcapadesRuntime.DOM.byId("gwGuideInput"), gwGuideStatus = SexcapadesRuntime.DOM.byId("gwGuideStatus"),
      gwGuideSteps = SexcapadesRuntime.DOM.byId("gwGuideSteps"), gwGuidePulseSel = SexcapadesRuntime.DOM.byId("gwGuidePulseMin"),
      gwDomPanel = SexcapadesRuntime.DOM.byId("gwDomPanel"),
      gwNowActivity = SexcapadesRuntime.DOM.byId("gwNowActivity"), gwNowNote = SexcapadesRuntime.DOM.byId("gwNowNote"),
      gwNowCount = SexcapadesRuntime.DOM.byId("gwNowCount"), gwNowProgress = SexcapadesRuntime.DOM.byId("gwNowProgress"),
      gwNextActivity = SexcapadesRuntime.DOM.byId("gwNextActivity"), gwNextNote = SexcapadesRuntime.DOM.byId("gwNextNote"),
      gwSceneClock = SexcapadesRuntime.DOM.byId("gwSceneClock"), gwPulseStatus = SexcapadesRuntime.DOM.byId("gwPulseStatus"),
      gwDomList = SexcapadesRuntime.DOM.byId("gwDomList"),
      gwPlayBtn = SexcapadesRuntime.DOM.byId("gwPlayBtn"), gwPauseBtn = SexcapadesRuntime.DOM.byId("gwPauseBtn"), gwStopBtn = SexcapadesRuntime.DOM.byId("gwStopBtn");
  var guidePlay = { on: false, paused: false, startedAt: 0, pausedAt: 0, pausedAccum: 0, stepIdx: -1, nextPulseAt: 0, pulses: 0 };
  function guideElapsedSec() {
    if (!guidePlay.on) return 0;
    var end = guidePlay.paused ? guidePlay.pausedAt : nowMs();
    return Math.max(0, (end - guidePlay.startedAt - guidePlay.pausedAccum) / 1000);
  }
  function guideStepAt(sec) {
    var steps = state.guide.steps;
    for (var i = steps.length - 1; i >= 0; i--) { if (sec >= steps[i].start && sec < steps[i].end) return steps[i]; }
    return null;
  }
  function guideCurrentSched() {
    if (!guidePlay.on || !state.guide.steps.length) return "";
    var st = guideStepAt(guideElapsedSec());
    return st ? st.activity : "";
  }
  var gwTxDiag = "";
  function gwTxText(payload) {
    /* Best-effort real GibberLink transmit: reuse the loaded ggwave lib to
       encode the payload at p=4 and play it. Returns a Promise resolving true
       only when samples have actually finished playing to the audio output;
       anything else resolves false so a status line never claims a chirp
       that did not happen. The stage that failed is kept in gwTxDiag so the
       sender status can name it. */
    return new Promise(function (resolve) {
      try {
        if (!gwLib || typeof gwLib.encode !== "function") { gwTxDiag = "decoder not loaded"; return resolve(false); }
        var AC = window.AudioContext || window.webkitAudioContext; if (!AC) { gwTxDiag = "Web Audio not available in this browser"; return resolve(false); }
        if (!gwTxText.ctx) gwTxText.ctx = new AC();
        var ctx = gwTxText.ctx;
        if (ctx.state === "suspended") ctx.resume();
        var inst = gwInstance;
        var ownInst = null;
        if (inst === null || inst === undefined) {
          var params = gwLib.getDefaultParameters();
          params.sampleRateInp = ctx.sampleRate; params.sampleRateOut = ctx.sampleRate;
          ownInst = gwLib.init(params); inst = ownInst;
        }
        var samples = gwLib.encode(inst, String(payload), 4, 20);
        if (ownInst !== null && ownInst !== undefined) { try { gwLib.free(ownInst); } catch (e) {} }
        if (!samples || !samples.length) { gwTxDiag = "encode returned no samples"; return resolve(false); }
        /* This ggwave build returns the waveform as an Int8Array of raw
           float32 bytes (a view into the WASM heap), not a Float32Array —
           reinterpret the bytes, or copyToChannel rejects it. */
        var f32;
        if (samples instanceof Float32Array) f32 = samples;
        else if (samples.buffer) f32 = new Float32Array(samples.buffer, samples.byteOffset || 0, Math.floor((samples.byteLength || 0) / 4));
        else f32 = Float32Array.from(samples);
        if (!f32.length) { gwTxDiag = "encode returned no samples"; return resolve(false); }
        var buf = ctx.createBuffer(1, f32.length, ctx.sampleRate);
        buf.copyToChannel(f32, 0);
        var srcNode = ctx.createBufferSource();
        srcNode.buffer = buf;
        srcNode.connect(ctx.destination);
        var durationSec = f32.length / ctx.sampleRate;
        var ended = false;
        function finish() {
          if (ended) return;
          ended = true;
          gwTxDiag = "";
          resolve(true);
        }
        srcNode.onended = finish;
        setTimeout(finish, Math.ceil(durationSec * 1000) + 150);
        srcNode.start();
      } catch (e) {
        __sxErrLog("guide-tx", e);
        gwTxDiag = "error: " + (e && e.message ? e.message : String(e));
        resolve(false);
      }
    });
  }
  function gwSendPayload(payload) {
    /* Ultrasound send for the setup / check-in sender: unlike the guide
       pulse (which only reports a chirp when the listener already loaded
       the decoder), this loads the ggwave lib on demand so a setup can be
       sent without starting the microphone listener first. Resolves true
       only when samples were actually played. */
    if (gwLib) return Promise.resolve(gwTxText(payload));
    var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return Promise.resolve(false);
    try { if (!gwTxText.ctx) gwTxText.ctx = new AC(); } catch (e) { __sxErrLog("gw-tx-ctx", e); }
    var rate = gwTxText.ctx ? gwTxText.ctx.sampleRate : 48000;
    return gwEnsureDecoder(rate).then(function (ok) { return ok ? gwTxText(payload) : false; });
  }
  function guideTxPulse() {
    return gwTxText("CHK");
  }
  function guideFirePulse(reason) {
    guidePlay.pulses++;
    vibrate([160, 70, 160]);
    gwBeep();
    var sent = false;
    var bleStateVal = null;
    var sched = guideCurrentSched();
    var pulseNo = guidePlay.pulses, firedAt = fmtCT(nowMs());
    function showPulse() {
      if (!gwPulseStatus) return;
      gwPulseStatus.textContent = "Check-in pulse #" + pulseNo + " fired " + firedAt + (reason ? " (" + reason + ")" : "") + (sched ? " — scheduled now: " + sched + "." : ".") + (sent ? " GibberLink chirp \u201CCHK\u201D sent over GGWave p=4." : " Watch chirp not sent (decoder not loaded — Start listening first); this device pulsed instead, and the watch's next tap will be matched to the schedule.") + (bleStateVal === true ? " Check-in pulse \u201CCHK\u201D also written over Bluetooth (GibberLink BLE)." : (bleStateVal === false ? " Bluetooth write failed — the watch may have dropped; reconnect runs automatically and GGWave carries the scene meanwhile." : ""));
    }
    showPulse();
    guideTxPulse().then(function (ok) {
      if (ok) { sent = true; showPulse(); }
    });
    /* Same pulse over BLE when connected (ble-1106-1405): bleSendText
       resolves null when Bluetooth is not connected, so the status line
       only ever claims a Bluetooth send that actually completed. */
    bleSendText("CHK").then(function (bleState) { if (bleState !== null) { bleStateVal = bleState; showPulse(); } });
    if (gwDomPanel) { gwDomPanel.classList.remove("gw-guide-pulse-flash"); void gwDomPanel.offsetWidth; gwDomPanel.classList.add("gw-guide-pulse-flash"); }
  }
  function renderGuide() {
    var g = state.guide;
    if (gwGuideInput && document.activeElement !== gwGuideInput) gwGuideInput.value = g.text || "";
    if (gwGuidePulseSel && document.activeElement !== gwGuidePulseSel) gwGuidePulseSel.value = String(g.pulseMin || 5);
    if (gwGuideSteps) {
      gwGuideSteps.innerHTML = "";
      g.steps.forEach(function (st) {
        var row = document.createElement("div"); row.className = "gw-guide-step";
        var tm = document.createElement("time"); tm.textContent = guideFmtClock(st.start) + "–" + guideFmtClock(st.end);
        var act = document.createElement("strong"); act.textContent = st.activity;
        var nt = document.createElement("span"); nt.textContent = st.note || "";
        row.appendChild(tm); row.appendChild(act); if (st.note) row.appendChild(nt);
        gwGuideSteps.appendChild(row);
      });
      gwGuideSteps.hidden = !g.steps.length;
    }
    if (gwGuideStatus && !guidePlay.on) {
      gwGuideStatus.textContent = g.steps.length
        ? "Play guide queued: " + g.steps.length + " timed step" + (g.steps.length === 1 ? "" : "s") + ", " + guideFmtClock(g.steps[g.steps.length - 1].end) + " total, check-in pulse every " + g.pulseMin + " min. Press Start playback in the Dom panel when the scene begins."
        : "No play guide queued.";
    }
    if (gwDomPanel) gwDomPanel.hidden = !g.steps.length;
    renderGuidePlayback();
  }
  function renderGuidePlayback() {
    var g = state.guide, steps = g.steps;
    if (!steps.length) return;
    var elapsed = guideElapsedSec();
    var idx = -1;
    for (var i = steps.length - 1; i >= 0; i--) { if (elapsed >= steps[i].start && elapsed < steps[i].end) { idx = i; break; } }
    var cur = idx >= 0 ? steps[idx] : null, nxt = idx + 1 < steps.length ? steps[idx + 1] : null;
    if (gwSceneClock) gwSceneClock.textContent = guideFmtClock(elapsed) + (guidePlay.on ? (guidePlay.paused ? " · paused" : " · playing") : " · not started");
    if (gwNowActivity) gwNowActivity.textContent = !guidePlay.on ? "Queued — press Start playback" : (cur ? cur.activity : (elapsed < steps[0].start ? "Scene starts at " + guideFmtClock(steps[0].start) : "Guide finished"));
    if (gwNowNote) gwNowNote.textContent = cur ? (cur.note || "") : "";
    if (gwNowCount) gwNowCount.textContent = cur && guidePlay.on ? guideFmtClock(cur.end - elapsed) + " left in this step" : "";
    if (gwNowProgress) gwNowProgress.style.width = cur ? Math.min(100, Math.max(0, (elapsed - cur.start) / Math.max(1, cur.end - cur.start) * 100)) + "%" : "0%";
    if (gwNextActivity) gwNextActivity.textContent = nxt ? (guideFmtClock(nxt.start) + " — " + nxt.activity) : "Nothing after this step";
    if (gwNextNote) gwNextNote.textContent = nxt ? (nxt.note || "") : "";
    if (gwPulseStatus && !guidePlay.on) gwPulseStatus.textContent = "Check-in pulse: armed when playback starts — every " + g.pulseMin + " min, plus at every step change. The app holds the timer; the watch holds none.";
    if (gwDomList) {
      gwDomList.innerHTML = "";
      steps.forEach(function (st, i2) {
        var li = document.createElement("li");
        li.textContent = guideFmtClock(st.start) + " " + st.activity;
        if (i2 === idx) li.setAttribute("data-active", "true");
        else if (guidePlay.on && elapsed >= st.end) li.setAttribute("data-done", "true");
        gwDomList.appendChild(li);
      });
    }
    if (gwPlayBtn) gwPlayBtn.disabled = guidePlay.on && !guidePlay.paused;
    if (gwPlayBtn) gwPlayBtn.textContent = guidePlay.paused ? "Resume playback" : "Start playback";
    if (gwPauseBtn) gwPauseBtn.disabled = !guidePlay.on || guidePlay.paused;
    if (gwStopBtn) gwStopBtn.disabled = !guidePlay.on;
  }
  function guideTick() {
    if (!guidePlay.on || guidePlay.paused) return;
    var elapsed = guideElapsedSec();
    var st = guideStepAt(elapsed);
    var idx = st ? state.guide.steps.indexOf(st) : -1;
    if (idx !== guidePlay.stepIdx) {
      var first = guidePlay.stepIdx === -1;
      guidePlay.stepIdx = idx;
      if (!first && st) guideFirePulse("step change — now: " + st.activity);
    }
    if (guidePlay.nextPulseAt && nowMs() >= guidePlay.nextPulseAt) {
      guideFirePulse("scheduled check-in");
      guidePlay.nextPulseAt = nowMs() + state.guide.pulseMin * 60000;
    }
    var last = state.guide.steps[state.guide.steps.length - 1];
    if (last && elapsed >= last.end) {
      guidePlay.on = false; guidePlay.paused = false;
      if (gwGuideStatus) gwGuideStatus.textContent = "Play guide finished — " + state.guide.steps.length + " steps played, " + guidePlay.pulses + " check-in pulses fired. The journal below carries the scheduled activity for every tap.";
      vibrate([200, 80, 200]);
    }
    if (safetyDlg && safetyDlg.open) renderGuidePlayback();
  }
  var gwGuideQueueBtn = SexcapadesRuntime.DOM.byId("gwGuideQueueBtn"), gwGuideClearBtn = SexcapadesRuntime.DOM.byId("gwGuideClearBtn");
  if (gwGuideQueueBtn) gwGuideQueueBtn.addEventListener("click", function () {
    var text = gwGuideInput ? gwGuideInput.value : "";
    var parsed = parsePlayGuide(text);
    if (!parsed.steps.length) {
      if (gwGuideStatus) gwGuideStatus.textContent = "No timed steps found. Each step needs a time code first, like [00:00-05:00] Warm-up — … (Scene Setter's play-guide prompt now asks every AI for exactly this format.)";
      return;
    }
    state.guide.text = text;
    state.guide.steps = parsed.steps;
    state.guide.pulseMin = gwGuidePulseSel ? (+gwGuidePulseSel.value || 5) : 5;
    if (parsed.pulseMin) { var opts = [1, 2, 5, 10, 15], snap = opts[0]; opts.forEach(function (o) { if (Math.abs(o - parsed.pulseMin) < Math.abs(snap - parsed.pulseMin)) snap = o; }); state.guide.pulseMin = snap; if (gwGuidePulseSel) gwGuidePulseSel.value = String(snap); }
    state.guide.queuedAt = nowMs();
    guidePlay.on = false; guidePlay.paused = false; guidePlay.stepIdx = -1; guidePlay.pulses = 0;
    save(); renderGuide();
    if (gwGuideStatus) gwGuideStatus.textContent = "Play guide queued: " + parsed.steps.length + " timed steps" + (parsed.skipped ? " (" + parsed.skipped + " line" + (parsed.skipped === 1 ? "" : "s") + " without a time code skipped)" : "") + ". The Dom play-by-play panel is open below the listener — press Start playback when the scene begins.";
    /* sentinel-density-1108-1545: no scrollIntoView here — queuing a guide must not yank the dialog's scroll position. */
  });
  if (gwGuideClearBtn) gwGuideClearBtn.addEventListener("click", function () {
    state.guide = { text: "", steps: [], pulseMin: state.guide.pulseMin || 5, queuedAt: 0 };
    guidePlay.on = false; guidePlay.paused = false; guidePlay.stepIdx = -1; guidePlay.pulses = 0;
    save(); renderGuide();
  });
  if (gwGuidePulseSel) gwGuidePulseSel.addEventListener("change", function () {
    state.guide.pulseMin = +gwGuidePulseSel.value || 5;
    if (guidePlay.on) guidePlay.nextPulseAt = nowMs() + state.guide.pulseMin * 60000;
    save(); renderGuidePlayback();
  });
  if (gwPlayBtn) gwPlayBtn.addEventListener("click", function () {
    if (guidePlay.paused) {
      guidePlay.pausedAccum += nowMs() - guidePlay.pausedAt;
      guidePlay.paused = false;
      guidePlay.nextPulseAt = nowMs() + state.guide.pulseMin * 60000;
    } else if (!guidePlay.on) {
      guidePlay.on = true; guidePlay.startedAt = nowMs(); guidePlay.pausedAccum = 0; guidePlay.stepIdx = -1; guidePlay.pulses = 0;
      guidePlay.nextPulseAt = nowMs() + state.guide.pulseMin * 60000;
      guideFirePulse("scene start");
    }
    renderGuidePlayback();
  });
  if (gwPauseBtn) gwPauseBtn.addEventListener("click", function () {
    if (!guidePlay.on || guidePlay.paused) return;
    guidePlay.paused = true; guidePlay.pausedAt = nowMs();
    renderGuidePlayback();
  });
  if (gwStopBtn) gwStopBtn.addEventListener("click", function () {
    guidePlay.on = false; guidePlay.paused = false; guidePlay.stepIdx = -1;
    if (gwGuideStatus) gwGuideStatus.textContent = "Playback stopped. The guide stays queued — press Start playback to run it from the top.";
    renderGuidePlayback();
  });


  /* ---------------- Close button + timers ---------------- */
  var closeSafety = SexcapadesRuntime.DOM.byId("closeSafetyButton");
  if (closeSafety) closeSafety.addEventListener("click", function () { closeDialog(safetyDlg); syncBtn(); });

  var lastMissBuzz = 0;
  SexcapadesRuntime.TimerManager.setInterval(function () {
    var ci = state.checkin, n = nowMs(), changed = false;
    if (ci.phase === "running" && ci.nextDue && n >= ci.nextDue) {
      ci.phase = "due"; ci.dueAt = n; changed = true;
      vibrate([180, 80, 180, 80, 180]);
      sentinelNotify('due');
    } else if (ci.phase === "due" && n > ci.dueAt + GRACE_MS) {
      ci.phase = "missed"; changed = true; lastMissBuzz = n;
      vibrate([300, 80, 300]);
      sentinelNotify('missed');
    } else if (ci.phase === "missed" && n - lastMissBuzz > 30000) {
      lastMissBuzz = n; vibrate([200, 60, 200]);
    }
    if (state.post.dueAt && n >= state.post.dueAt && safetyDlg && safetyDlg.open) renderPost();
    guideTick();
    if (changed) save();
    if (safetyDlg && safetyDlg.open && (ci.phase === "running" || ci.phase === "due" || ci.phase === "missed")) renderCheckin();
  }, 500);

  function renderAll() {
    renderSignals(); renderContacts(); hydratePre(); renderCheckin(); renderPost(); renderNotifHint(); renderJournal(); renderGuide();
    gwPopulateChkTargets();
    bleMaybeReconnect();
  }
  window.__sxSentinelRenderAll = renderAll;
  load();
  hydratePre();
  renderSignals();
  renderContacts();
  renderCheckin();
  renderPost();
  renderJournal();
  renderGuide();
  }
  boot();
})();
});
