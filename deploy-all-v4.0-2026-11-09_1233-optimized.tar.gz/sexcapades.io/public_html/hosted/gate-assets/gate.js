/* ---- inline block 1 (document order) ---- */

      (function () {
        var funnelEndpoint = 'https://sexcapades.io/hosted/api/collect.php';
        var incomingSearchParams = new URLSearchParams(window.location.search);
        var incomingUtmSource = incomingSearchParams.get('utm_source') || '';
        var isFlyerReferral = incomingSearchParams.get('src') === 'flyer';
        var ageGate = document.getElementById('ageGate');
        var destinationMenu = document.getElementById('destinationMenu');
        var enterButton = document.getElementById('enterButton');
        var appViewTrigger = document.getElementById('appViewTrigger');
        var appViewMenu = document.getElementById('appViewMenu');

        try {
          window.sessionStorage.setItem('sexcapades_utm_source', incomingUtmSource);
        } catch (storageError) {
          // Continue without persistence when browser storage is unavailable.
        }

        function createBrowserUuid() {
          if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            return window.crypto.randomUUID();
          }

          return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (character) {
            var randomValue = Math.random() * 16 | 0;
            var replacement = character === 'x' ? randomValue : (randomValue & 3 | 8);
            return replacement.toString(16);
          });
        }

        function getBrowserUuid() {
          var browserUuid = '';

          try {
            browserUuid = window.localStorage.getItem('sexcapades_uuid') || '';
            if (!browserUuid) {
              browserUuid = createBrowserUuid();
              window.localStorage.setItem('sexcapades_uuid', browserUuid);
            }
          } catch (storageError) {
            browserUuid = createBrowserUuid();
          }

          return browserUuid;
        }

        function getStoredUtmSource() {
          try {
            return window.sessionStorage.getItem('sexcapades_utm_source') || '';
          } catch (storageError) {
            return incomingUtmSource;
          }
        }

        function sendGatePassedEvent() {
          var payload = JSON.stringify({
            action: 'event',
            uuid: getBrowserUuid(),
            event_type: 'gate_passed',
            utm_source: getStoredUtmSource()
          });

          if (navigator.sendBeacon) {
            try {
              if (navigator.sendBeacon(funnelEndpoint, new Blob([payload], { type: 'application/json' }))) return;
            } catch (beaconError) {
              // Fall through to a keepalive fetch.
            }
          }

          fetch(funnelEndpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payload,
            keepalive: true
          }).catch(function () {
            // Tracking must never interrupt navigation.
          });
        }

        var destinationUrls = {
          app: '/hosted/app.html',
          guide: '/hosted/guide.html',
          flyer: '/hosted/flyer.html',
          faq: '/hosted/faq.html',
          quickstart: '/hosted/quickstart.html',
          'how-it-works': '/hosted/how-it-works.html',
          examples: '/hosted/examples.html'
        };

        // Guide sections: a guide deep link may name a section after the
        // page (guide/scene-sentinel), and a bare section hashtag
        // (scene-sentinel) is a guide section too. The section is a single
        // safe anchor (letters, digits, hyphens); guide.html itself ignores
        // unknown anchors and shows the contents page, so this cannot
        // misdirect — the URL stays on sexcapades.io, and the gate still
        // runs first before any of these destinations are followed.
        var guideSectionPattern = /^[a-z0-9][a-z0-9_-]*$/i;

        function getDeepLinkDestination() {
          var fragment = window.location.hash.slice(1);
          var segments;
          var page;
          var subroute;

          if (!fragment || fragment.indexOf('#') !== -1) return '';

          segments = fragment.split('/');
          page = segments.shift().toLowerCase();

          // A bare section hashtag is a guide section (e.g. #scene-sentinel
          // opens the Sentinel section of the guide after the gate passes).
          if (!Object.prototype.hasOwnProperty.call(destinationUrls, page)) {
            if (segments.length) return '';
            if (!guideSectionPattern.test(page)) return '';
            return destinationUrls.guide + '#' + page;
          }
          if (!segments.length) return destinationUrls[page];

          if (page === 'guide') {
            subroute = segments.join('/');
            if (!guideSectionPattern.test(subroute)) return '';
            return destinationUrls.guide + '#' + subroute;
          }

          if (page !== 'app') return '';

          subroute = segments.join('/');
          if (!/^[a-z0-9][a-z0-9/_-]*$/i.test(subroute)) return '';

          return destinationUrls.app + '#app/' + subroute;
        }

        // The app bounces unverified visitors here with ?return=<the app URL
        // they came from>. Honor it after verification, but only for same-site
        // HTTPS URLs and never back to this gate page itself, so the parameter
        // can't be abused as an open redirect or restart the loop.
        function getReturnDestination() {
          var raw;
          var parsed;

          try {
            raw = new URLSearchParams(window.location.search).get('return');
          } catch (searchError) {
            return '';
          }

          if (!raw) return '';

          try {
            parsed = new URL(raw);
          } catch (parseError) {
            return '';
          }

          if (parsed.protocol !== 'https:') return '';
          if (parsed.hostname !== 'sexcapades.io' && parsed.hostname !== 'www.sexcapades.io') return '';
          if (parsed.username || parsed.password) return '';
          if (/\/gate\.html$/i.test(parsed.pathname) || parsed.pathname === '/hosted/gate.html') return '';

          return parsed.href;
        }

        function markAgeVerified() {
          try {
            window.localStorage.setItem('sexcapades_age_verified', 'true');
            window.localStorage.setItem('sexcapades_age_verified_at', new Date().toISOString());
          } catch (storageError) {
            // Storage can be unavailable (private mode); the cookie below still remembers this visit's pass.
          }

          try {
            // Both an Expires date and Max-Age: some browsers/webviews drop a
            // cookie that carries only one of the two lifetime attributes.
            var cookieValue = 'sexcapades_age_verified=1' +
              '; Expires=' + new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toUTCString() +
              '; Max-Age=31536000; Path=/; SameSite=Lax';
            // Share the pass between the apex domain and www (and any other
            // subdomain): a host-only cookie set on one is invisible to the other.
            if (/(^|\.)sexcapades\.io$/i.test(window.location.hostname)) {
              cookieValue += '; Domain=sexcapades.io';
            }
            if (window.location.protocol === 'https:') cookieValue += '; Secure';
            document.cookie = cookieValue;
          } catch (cookieError) {
            // Cookies can be unavailable too; the gate still works for this visit.
          }
        }

        function hasAgeVerifiedCookie() {
          try {
            return document.cookie.split(';').some(function (part) {
              return part.trim() === 'sexcapades_age_verified=1';
            });
          } catch (cookieError) {
            return false;
          }
        }

        function hasPreviousGatePass() {
          if (hasAgeVerifiedCookie()) return true;

          try {
            return window.localStorage.getItem('sexcapades_age_verified') === 'true' ||
              Boolean(window.localStorage.getItem('sexcapades_uuid'));
          } catch (storageError) {
            return false;
          }
        }

        function revealDestinations() {
          ageGate.classList.add('is-confirmed');
          ageGate.removeAttribute('aria-labelledby');
          ageGate.setAttribute('aria-label', 'Sexcapades destinations');
          destinationMenu.classList.add('is-visible');
          destinationMenu.setAttribute('aria-hidden', 'false');
          enterButton.setAttribute('aria-expanded', 'true');
        }


        var initialDeepLinkDestination = getDeepLinkDestination();
        var previousGatePass = hasPreviousGatePass();

        // Self-heal: if either store kept the pass, rewrite both. A returning
        // visitor whose cookie survived but whose localStorage was cleared (or
        // the reverse) would otherwise lose the gate skip the next time the
        // surviving store is cleared too.
        if (previousGatePass) markAgeVerified();

        // A returning visitor bounced here by the app carries a return URL
        // with verified=1: send them straight back before any other branch.
        if (previousGatePass) {
          var returnDestination = getReturnDestination();
          if (returnDestination) {
            window.location.replace(returnDestination);
            return;
          }
        }

        if (initialDeepLinkDestination && previousGatePass) {
          window.location.replace(initialDeepLinkDestination);
          return;
        }

        // Returning verified visitors skip the confirmation panel entirely:
        // flyer referrals go straight to Quick Start (same as clicking Enter),
        // everyone else lands on the destination menu.
        if (previousGatePass) {
          if (isFlyerReferral) {
            window.location.replace(destinationUrls.quickstart);
            return;
          }

          revealDestinations();
        }

        enterButton.addEventListener('click', function () {
          var deepLinkDestination = getDeepLinkDestination();

          markAgeVerified();
          sendGatePassedEvent();

          var returnDestination = getReturnDestination();
          if (returnDestination) {
            window.location.assign(returnDestination);
            return;
          }

          if (deepLinkDestination) {
            window.location.assign(deepLinkDestination);
            return;
          }

          if (isFlyerReferral) {
            window.location.assign(destinationUrls.quickstart);
            return;
          }

          revealDestinations();
          destinationMenu.querySelector('.quick-start-link').focus();
        });

        // App view pull-down menu: anchored to the "App" button, drops
        // down from it, closes on outside click and on Escape. Entries are
        // plain links, so choosing one navigates exactly as before.
        if (appViewTrigger && appViewMenu) {
          var appViewItems = Array.prototype.slice.call(appViewMenu.querySelectorAll('a'));

          function closeAppViewMenu() {
            appViewMenu.hidden = true;
            appViewTrigger.setAttribute('aria-expanded', 'false');
          }

          function openAppViewMenu() {
            appViewMenu.hidden = false;
            appViewTrigger.setAttribute('aria-expanded', 'true');
          }

          appViewTrigger.addEventListener('click', function () {
            if (appViewMenu.hidden) openAppViewMenu();
            else closeAppViewMenu();
          });

          // Keyboard: ArrowDown/ArrowUp on the trigger opens the menu and
          // moves focus into it; arrows then move between items (wrapping),
          // and Escape closes the menu and returns focus to the trigger.
          appViewTrigger.addEventListener('keydown', function (event) {
            if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
            event.preventDefault();
            if (appViewMenu.hidden) openAppViewMenu();
            var item = event.key === 'ArrowDown' ? appViewItems[0] : appViewItems[appViewItems.length - 1];
            if (item) item.focus();
          });

          appViewMenu.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
              closeAppViewMenu();
              appViewTrigger.focus();
              return;
            }
            if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
            event.preventDefault();
            var index = appViewItems.indexOf(document.activeElement);
            if (event.key === 'ArrowDown') {
              index = index < 0 ? 0 : (index + 1) % appViewItems.length;
            } else {
              index = index < 0 ? appViewItems.length - 1 : (index - 1 + appViewItems.length) % appViewItems.length;
            }
            if (appViewItems[index]) appViewItems[index].focus();
          });

          document.addEventListener('click', function (event) {
            if (!appViewMenu.hidden &&
                !appViewMenu.contains(event.target) &&
                !appViewTrigger.contains(event.target)) {
              closeAppViewMenu();
            }
          });

          document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !appViewMenu.hidden) {
              closeAppViewMenu();
              appViewTrigger.focus();
            }
          });
        }

        // Footer sitemap: pull-up dropdown menus (App, Guide, FAQ, Glossary).
        // Everything here is looked up defensively and wired independently, so a
        // missing element can never break the gate itself.
        var openSitemapMenu = null;
        var openSitemapTrigger = null;

        function closeSitemapMenu() {
          if (openSitemapMenu) openSitemapMenu.hidden = true;
          if (openSitemapTrigger) openSitemapTrigger.setAttribute('aria-expanded', 'false');
          openSitemapMenu = null;
          openSitemapTrigger = null;
        }

        function wireSitemapMenu(triggerId, menuId) {
          var trigger = document.getElementById(triggerId);
          var menu = document.getElementById(menuId);
          if (!trigger || !menu) return;

          var items = Array.prototype.slice.call(menu.querySelectorAll('a'));

          function openMenu() {
            closeSitemapMenu();
            menu.hidden = false;
            trigger.setAttribute('aria-expanded', 'true');
            openSitemapMenu = menu;
            openSitemapTrigger = trigger;
          }

          trigger.addEventListener('click', function () {
            if (menu.hidden) openMenu();
            else closeSitemapMenu();
          });

          // Keyboard: ArrowDown/ArrowUp on the trigger opens the menu and
          // moves focus into it; arrows then move between items (wrapping),
          // Enter follows the focused link natively, and Escape closes the
          // menu and returns focus to the trigger.
          trigger.addEventListener('keydown', function (event) {
            if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
            event.preventDefault();
            if (menu.hidden) openMenu();
            var item = event.key === 'ArrowDown' ? items[0] : items[items.length - 1];
            if (item) item.focus();
          });

          menu.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
              closeSitemapMenu();
              trigger.focus();
              return;
            }
            if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
            event.preventDefault();
            var index = items.indexOf(document.activeElement);
            if (event.key === 'ArrowDown') {
              index = index < 0 ? 0 : (index + 1) % items.length;
            } else {
              index = index < 0 ? items.length - 1 : (index - 1 + items.length) % items.length;
            }
            if (items[index]) items[index].focus();
          });
        }

        wireSitemapMenu('appMenuTrigger', 'appMenu');
        wireSitemapMenu('guideMenuTrigger', 'guideMenu');
        wireSitemapMenu('faqMenuTrigger', 'faqMenu');
        wireSitemapMenu('glossaryMenuTrigger', 'glossaryMenu');

        document.addEventListener('click', function (event) {
          if (openSitemapMenu && !openSitemapMenu.contains(event.target) &&
              openSitemapTrigger && !openSitemapTrigger.contains(event.target)) {
            closeSitemapMenu();
          }
        });

        document.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') closeSitemapMenu();
        });

      }());
    
/* ---- inline block 2 (document order) ---- */

(function(){var c=document.getElementById('odometer-digits-GATE');if(!c)return;
function render(n){try{var s=String(n).padStart(6,'0');c.innerHTML='';for(var i=0;i<s.length;i++){var d=document.createElement('div');d.className='odometer-digit';d.textContent=s[i];c.appendChild(d);}}catch(e){}}
try{
fetch('https://sexcapades.io/hosted/api/collect.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'get_stats'})}).then(function(r){return r.json();}).then(function(d){render((d&&d.unique_visitors)||0);}).catch(function(){render(0);});
}catch(e){render(0);}})();
